-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : weiphp3
-- 
-- Part : #1
-- Date : 2016-07-08 11:21:53
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `wp_action`
-- -----------------------------
DROP TABLE IF EXISTS `wp_action`;
;

-- -----------------------------
-- Records of `wp_action`
-- -----------------------------
INSERT INTO `wp_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了管理中心', '1', '0', '1393685660');
INSERT INTO `wp_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '0', '1380173180');
INSERT INTO `wp_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '0', '1383285646');
INSERT INTO `wp_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章。\r\n表[model]，记录编号[record]。', '2', '0', '1386139726');
INSERT INTO `wp_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '0', '1383285551');
INSERT INTO `wp_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '1', '1383294988');
INSERT INTO `wp_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `wp_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `wp_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301');
INSERT INTO `wp_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `wp_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '1', '1383296765');
INSERT INTO `wp_action` VALUES ('12', 'admin_login', '登录后台', '管理员登录后台', '', '[user|get_nickname]在[time|time_format]登录了后台', '2', '1', '1393685618');

-- -----------------------------
-- Table structure for `wp_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_action_log`;
;

-- -----------------------------
-- Records of `wp_action_log`
-- -----------------------------
INSERT INTO `wp_action_log` VALUES ('1', '12', '1', '1988415560', 'user', '1', 'Administrator在2016-06-27 13:30登录了后台', '1', '1467005410');
INSERT INTO `wp_action_log` VALUES ('2', '12', '1', '1988415560', 'user', '1', 'Administrator在2016-06-28 15:51登录了后台', '1', '1467100305');
INSERT INTO `wp_action_log` VALUES ('3', '12', '1', '1988415560', 'user', '1', 'l翎晨在2016-06-29 11:41登录了后台', '1', '1467171689');
INSERT INTO `wp_action_log` VALUES ('4', '8', '1', '1988415560', 'attribute', '5', '操作url：/php/weiphp3/index.php?s=/Admin/Attribute/update.html', '1', '1467174196');
INSERT INTO `wp_action_log` VALUES ('5', '12', '1', '1988393013', 'user', '1', '阿追(J)在2016-06-30 12:23登录了后台', '1', '1467260596');
INSERT INTO `wp_action_log` VALUES ('6', '12', '1', '1988370232', 'user', '1', '阿追(J)在2016-07-04 19:34登录了后台', '1', '1467632075');
INSERT INTO `wp_action_log` VALUES ('7', '12', '1', '1988370232', 'user', '1', '阿追(J)在2016-07-05 09:18登录了后台', '1', '1467681495');
INSERT INTO `wp_action_log` VALUES ('8', '12', '1', '1988370232', 'user', '1', '阿追(J)在2016-07-05 12:12登录了后台', '1', '1467691941');
INSERT INTO `wp_action_log` VALUES ('9', '12', '1', '1988370232', 'user', '1', '阿追(J)在2016-07-06 17:50登录了后台', '1', '1467798630');
INSERT INTO `wp_action_log` VALUES ('10', '12', '11', '1988370232', 'user', '11', 'Administrator在2016-07-08 10:16登录了后台', '1', '1467944210');

-- -----------------------------
-- Table structure for `wp_addon_category`
-- -----------------------------
DROP TABLE IF EXISTS `wp_addon_category`;
;

-- -----------------------------
-- Records of `wp_addon_category`
-- -----------------------------
INSERT INTO `wp_addon_category` VALUES ('1', '', '奖励功能', '4');
INSERT INTO `wp_addon_category` VALUES ('2', '', '互动功能', '3');
INSERT INTO `wp_addon_category` VALUES ('7', '0', '高级功能', '10');
INSERT INTO `wp_addon_category` VALUES ('4', '', '公众号管理', '20');
INSERT INTO `wp_addon_category` VALUES ('8', '0', '用户管理', '1');

-- -----------------------------
-- Table structure for `wp_addons`
-- -----------------------------
DROP TABLE IF EXISTS `wp_addons`;
;

-- -----------------------------
-- Records of `wp_addons`
-- -----------------------------
INSERT INTO `wp_addons` VALUES ('18', 'Wecome', '欢迎语', '用户关注公众号时发送的欢迎信息，支持文本，图片，图文的信息', '1', '{\"type\":\"1\",\"title\":\"\",\"description\":\"欢迎关注，请<a href=\"[follow]\">绑定帐号</a>后体验更多功能\",\"pic_url\":\"\",\"url\":\"\"}', '地下凡星', '0.1', '1389620372', '0', '0', '4', '1');
INSERT INTO `wp_addons` VALUES ('19', 'UserCenter', '微信用户中心', '实现3G首页、微信登录，微信用户绑定，微信用户信息初始化等基本功能', '1', '{\"score\":\"100\",\"experience\":\"100\",\"need_bind\":\"1\",\"bind_start\":\"0\",\"jumpurl\":\"\"}', '地下凡星', '0.1', '1390660425', '1', '0', '8', '1');
INSERT INTO `wp_addons` VALUES ('56', 'CustomMenu', '自定义菜单', '自定义菜单能够帮助公众号丰富界面，让用户更好更快地理解公众号的功能', '1', 'null', '凡星', '0.1', '1398264735', '1', '0', '4', '1');
INSERT INTO `wp_addons` VALUES ('111', 'ConfigureAccount', '帐号配置', '配置共众帐号的信息', '1', 'null', 'manx', '0.1', '1430730412', '1', '0', '4', '0');
INSERT INTO `wp_addons` VALUES ('101', 'CardVouchers', '微信卡券', '在微信平台创建卡券后，可配置到这里生成素材提供用户领取，它既支持电视台自己公众号发布的卡券，也支持由商家公众号发布的卡券', '1', 'null', '凡星', '0.1', '1421981659', '1', '0', '1', '1');
INSERT INTO `wp_addons` VALUES ('39', 'WeiSite', '微官网', '微官网', '1', '{\"title\":\"\\u70b9\\u51fb\\u8fdb\\u5165\\u9996\\u9875\",\"info\":\"\",\"show_background\":\"1\",\"code\":\"\",\"template_index\":\"ColorV1\",\"template_footer\":\"V1\",\"template_lists\":\"V1\",\"template_detail\":\"V1\",\"share_limit\":\"1\"}', '凡星', '0.1', '1395326578', '0', '0', '7', '1');
INSERT INTO `wp_addons` VALUES ('42', 'Leaflets', '微信宣传页', '微信公众号二维码推广页面，用作推广或者制作广告易拉宝，可以发布到QQ群微博博客论坛等等...', '1', '{\"random\":\"1\"}', '凡星', '0.1', '1396056935', '0', '0', '4', '1');
INSERT INTO `wp_addons` VALUES ('48', 'CustomReply', '自定义回复', '这是一个临时描述', '1', 'null', '凡星', '0.1', '1396578089', '1', '0', '4', '1');
INSERT INTO `wp_addons` VALUES ('50', 'Survey', '微调研', '这是一个临时描述', '1', 'null', '凡星', '0.1', '1396883644', '1', '0', '2', '1');
INSERT INTO `wp_addons` VALUES ('91', 'Invite', '微邀约', '微邀约用于邀约朋友一起消费优惠券,一起参加活动', '1', 'null', '无名', '0.1', '1418047849', '1', '0', '2', '1');
INSERT INTO `wp_addons` VALUES ('93', 'Game', '互动游戏', '互动游管理中心，用于微游戏接入，管理绑定等', '1', 'null', '凡星', '0.1', '1418526180', '0', '0', '2', '0');
INSERT INTO `wp_addons` VALUES ('97', 'Ask', '微抢答', '用于电视互动答题', '1', '{\"random\":\"1\"}', '凡星', '0.1', '1420680633', '1', '0', '2', '1');
INSERT INTO `wp_addons` VALUES ('100', 'Forms', '通用表单', '管理员可以轻松地增加一个表单用于收集用户的信息，如活动报名、调查反馈、预约填单等', '1', 'null', '凡星', '0.1', '1421981648', '1', '0', '2', '1');
INSERT INTO `wp_addons` VALUES ('106', 'RedBag', '微信红包', '实现微信红包的金额设置，红包领取，红包素材下载等', '1', 'null', '凡星', '0.1', '1427683711', '1', '0', '1', '1');
INSERT INTO `wp_addons` VALUES ('107', 'Guess', '竞猜', '节目竞猜 有奖竞猜 竞猜项目配置', '1', 'null', '无名', '0.1', '1428648367', '1', '0', '2', '1');
INSERT INTO `wp_addons` VALUES ('108', 'WishCard', '微贺卡', 'Diy贺卡 自定贺卡内容 发给好友 后台编辑', '1', 'null', '凡星', '0.1', '1429344990', '1', '0', '2', '1');
INSERT INTO `wp_addons` VALUES ('110', 'RealPrize', '实物奖励', '实物奖励设置', '1', 'null', 'aManx', '0.1', '1429514311', '1', '0', '1', '1');
INSERT INTO `wp_addons` VALUES ('126', 'DeveloperTool', '开发者工具箱', '开发者可以用来调试，监控运营系统的参数', '1', 'null', '凡星', '0.1', '1438830685', '1', '0', '7', '1');
INSERT INTO `wp_addons` VALUES ('128', 'BusinessCard', '微名片', '', '1', '{\"random\":\"1\"}', '凡星', '0.1', '1438914856', '1', '0', '7', '1');
INSERT INTO `wp_addons` VALUES ('130', 'AutoReply', '自动回复', 'WeiPHP基础功能，能实现配置关键词，用户回复此关键词后自动回复对应的文件，图文，图片信息', '1', 'null', '凡星', '0.1', '1439194276', '1', '0', '4', '1');
INSERT INTO `wp_addons` VALUES ('133', 'Payment', '支付通', '微信支付,财付通,支付宝', '1', '{\"isopen\":\"1\",\"isopenwx\":\"1\",\"isopenzfb\":\"0\",\"isopencftwap\":\"0\",\"isopencft\":\"0\",\"isopenyl\":\"0\",\"isopenload\":\"1\"}', '拉帮姐派(陌路生人)', '0.1', '1439364373', '1', '0', '', '1');
INSERT INTO `wp_addons` VALUES ('134', 'Vote', '投票', '支持文本和图片两类的投票功能', '1', '{\"random\":\"1\"}', '凡星', '0.1', '1439433311', '1', '0', '2', '1');
INSERT INTO `wp_addons` VALUES ('137', 'Comment', '评论互动', '可放到手机界面里进行评论，显示支持弹屏方式', '1', '{\"min_time\":\"30\",\"limit\":\"15\"}', '凡星', '0.1', '1441593187', '1', '0', '', '1');
INSERT INTO `wp_addons` VALUES ('140', 'NoAnswer', '没回答的回复', '当用户提供的内容或者关键词系统无关识别回复时，自动把当前配置的内容回复给用户', '1', '{\"random\":\"1\"}', '凡星', '0.1', '1442905427', '0', '0', '4', '1');
INSERT INTO `wp_addons` VALUES ('141', 'Servicer', '工作授权', '关注公众号后，扫描授权二维码，获取工作权限', '1', 'null', 'jacy', '0.1', '1443079386', '1', '0', '8', '1');
INSERT INTO `wp_addons` VALUES ('142', 'Coupon', '优惠券', '配合粉丝圈子，打造粉丝互动的运营激励基础', '1', 'null', '凡星', '0.1', '1443094791', '1', '0', '', '1');
INSERT INTO `wp_addons` VALUES ('143', 'HelpOpen', '帮拆礼包', '可创建一个帮拆活动，指定需要多个好友帮拆开才能得到礼包里的礼品', '1', 'null', '凡星', '0.1', '1443108219', '1', '0', '', '1');
INSERT INTO `wp_addons` VALUES ('144', 'Card', '会员卡', '提供会员卡基本功能：会员卡制作、会员管理、通知发布、优惠券发布等功能，用户可在此基础上扩展自己的具体业务需求，如积分、充值、签到等', '1', '{\"background\":\"1\",\"title\":\"\\u65f6\\u5c1a\\u7f8e\\u5bb9\\u7f8e\\u53d1\\u5e97VIP\\u4f1a\\u5458\\u5361\",\"length\":\"80001\",\"instruction\":\"1\\u3001\\u606d\\u559c\\u60a8\\u6210\\u4e3a\\u65f6\\u5c1a\\u7f8e\\u5bb9\\u7f8e\\u53d1\\u5e97VIP\\u4f1a\\u5458;\\r\\n2\\u3001\\u7ed3\\u5e10\\u65f6\\u8bf7\\u51fa\\u793a\\u6b64\\u5361\\uff0c\\u51ed\\u6b64\\u5361\\u53ef\\u4eab\\u53d7\\u4f1a\\u5458\\u4f18\\u60e0;\\r\\n3\\u3001\\u6b64\\u5361\\u6700\\u7ec8\\u89e3\\u91ca\\u6743\\u5f52\\u65f6\\u5c1a\\u7f8e\\u5bb9\\u7f8e\\u53d1\\u5e97\\u6240\\u6709\",\"address\":\"\",\"phone\":\"\",\"url\":\"\",\"background_custom\":null}', '凡星', '0.1', '1443144735', '0', '0', '1', '1');
INSERT INTO `wp_addons` VALUES ('145', 'SingIn', '签到', '粉丝每天签到可以获得积分。', '1', '{\"random\":\"1\",\"score\":\"1\",\"score1\":\"1\",\"score2\":\"2\",\"hour\":\"0\",\"minute\":\"0\",\"continue_day\":\"3\",\"continue_score\":\"5\",\"share_score\":\"1\",\"share_limit\":\"1\",\"notstart\":\"\\u4eb2\\uff0c\\u4f60\\u8d77\\u5f97\\u592a\\u65e9\\u4e86,\\u7b7e\\u5230\\u4ece[\\u5f00\\u59cb\\u65f6\\u95f4]\\u5f00\\u59cb,\\u73b0\\u5728\\u624d[\\u5f53\\u524d\\u65f6\\u95f4]\\uff01\",\"done\":\"\\u4eb2\\uff0c\\u4eca\\u5929\\u5df2\\u7ecf\\u7b7e\\u5230\\u8fc7\\u4e86\\uff0c\\u8bf7\\u660e\\u5929\\u518d\\u6765\\u54e6\\uff0c\\u8c22\\u8c22\\uff01\",\"reply\":\"\\u606d\\u559c\\u60a8,\\u7b7e\\u5230\\u6210\\u529f\\r\\n\\r\\n\\u672c\\u6b21\\u7b7e\\u5230\\u83b7\\u5f97[\\u672c\\u6b21\\u79ef\\u5206]\\u79ef\\u5206\\r\\n\\r\\n\\u5f53\\u524d\\u603b\\u79ef\\u5206[\\u79ef\\u5206\\u4f59\\u989d]\\r\\n\\r\\n[\\u7b7e\\u5230\\u65f6\\u95f4]\\r\\n\\r\\n\\u60a8\\u4eca\\u5929\\u662f\\u7b2c[\\u6392\\u540d]\\u4f4d\\u7b7e\\u5230\\r\\n\\r\\n\\u7b7e\\u5230\\u6392\\u884c\\u699c\\uff1a\\r\\n\\r\\n[\\u6392\\u884c\\u699c]\",\"content\":\"\"}', '淡然', '1.11', '1444304566', '1', '0', '2', '1');
INSERT INTO `wp_addons` VALUES ('146', 'Reserve', '微预约', '微预约是商家利用微营销平台实现在线预约的一种服务，可以运用于汽车、房产、酒店、医疗、餐饮等一系列行业，给用户的出行办事、购物、消费带来了极大的便利！且操作简单， 响应速度非常快，受到业界的一致好评！', '1', 'null', '凡星', '0.1', '1444909657', '1', '0', '', '1');
INSERT INTO `wp_addons` VALUES ('151', 'Sms', '短信服务', '短信服务，短信验证，短信发送', '1', '{\"random\":\"1\"}', 'jacy', '0.1', '1446103430', '0', '0', '', '1');
INSERT INTO `wp_addons` VALUES ('152', 'Exam', '微考试', '主要功能有试卷管理，题目录入管理，考生信息和考分汇总管理。', '1', 'null', '凡星', '0.1', '1447383107', '1', '0', '', '1');
INSERT INTO `wp_addons` VALUES ('153', 'Test', '微测试', '主要功能有问卷管理，题目录入管理，用户信息和得分汇总管理。', '1', 'null', '凡星', '0.1', '1447383593', '1', '0', '', '1');
INSERT INTO `wp_addons` VALUES ('162', 'Weiba', '微社区', '打造公众号粉丝之间沟通的社区，为粉丝运营提供更多服务', '1', '{\"random\":\"1\"}', '凡星', '0.1', '1463801487', '1', '0', '', '1');
INSERT INTO `wp_addons` VALUES ('163', 'QrAdmin', '扫码管理', '在服务号的情况下，可以自主创建一个二维码，并可指定扫码后用户自动分配到哪个用户组，绑定哪些标签', '1', 'null', '凡星', '0.1', '1463999217', '1', '0', '', '1');
INSERT INTO `wp_addons` VALUES ('156', 'Draw', '比赛抽奖', '功能主要有奖品设置，抽奖配置和抽奖统计', '1', 'null', '凡星', '0.1', '1447389122', '1', '0', '', '1');
INSERT INTO `wp_addons` VALUES ('164', 'PublicBind', '一键绑定公众号', '', '1', '{\"random\":\"1\"}', '凡星', '0.1', '1465981270', '0', '0', '', '1');

-- -----------------------------
-- Table structure for `wp_analysis`
-- -----------------------------
DROP TABLE IF EXISTS `wp_analysis`;
;


-- -----------------------------
-- Table structure for `wp_article_style`
-- -----------------------------
DROP TABLE IF EXISTS `wp_article_style`;
;

-- -----------------------------
-- Records of `wp_article_style`
-- -----------------------------
INSERT INTO `wp_article_style` VALUES ('1', '1', '<section style=\"border: 0px none; padding: 0px; box-sizing: border-box; margin: 0px; font-family: 微软雅黑;\"><section class=\"main\" style=\"border: none rgb(0,187,236); margin: 0.8em 5% 0.3em; box-sizing: border-box; padding: 0px;\"><section class=\"main2 wxqq-color wxqq-bordertopcolor wxqq-borderleftcolor wxqq-borderrightcolor wxqq-borderbottomcolor\" data-brushtype=\"text\" style=\"color: rgb(0,187,236); font-size: 20px; letter-spacing: 3px; padding: 9px 4px 14px; text-align: center; margin: 0px auto; border: 4px solid rgb(0,187,236); border-top-left-radius: 8px; border-top-right-radius: 8px; border-bottom-right-radius: 8px; border-bottom-left-radius: 8px; box-sizing: border-box;\">理念<span class=\"main3 wxqq-color\" data-brushtype=\"text\" style=\"display: block; font-size: 10px; line-height: 12px; border-color: rgb(0,187,236); color: inherit; box-sizing: border-box; padding: 0px; margin: 0px;\">PHILOSOPHY</span></section><section class=\"main4 wxqq-bordertopcolor wxqq-borderbottomcolor\" style=\"width: 0px; margin-right: auto; margin-left: auto; border-top-width: 0.6em; border-top-style: solid; border-bottom-color: rgb(0,187,236); border-top-color: rgb(0,187,236); height: 10px; color: inherit; border-left-width: 0.7em !important; border-left-style: solid !important; border-left-color: transparent !important; border-right-width: 0.7em !important; border-right-style: solid !important; border-right-color: transparent !important; box-sizing: border-box; padding: 0px;\" data-width=\"0px\"></section></section></section>');
INSERT INTO `wp_article_style` VALUES ('2', '3', '<section label=\"Copyright © 2015 playhudong All Rights Reserved.\" style=\"\r\nmargin:1em auto;\r\npadding: 1em 2em;\r\nborder-style: none;\" id=\"shifu_c_001\"><span style=\"\r\nfloat: left;\r\nmargin-left: 19px;\r\nmargin-top: -9px;\r\noverflow: hidden;\r\ndisplay:block;\"><img style=\"\r\nvertical-align: top;\r\ndisplay:inline-block;\" src=\"http://1251001145.cdn.myqcloud.com/1251001145/style/images/card-3.gif\"><section class=\"color\" style=\"\r\nmin-height: 30px;\r\ncolor: #fff;\r\ndisplay: inline-block;\r\ntext-align: center;\r\nbackground: #999999;\r\nfont-size: 15px;\r\npadding: 7px 5px;\r\nmin-width: 30px;\"><span style=\"font-size:15px;\"> 01 </span></section></span><section style=\"\r\npadding: 16px;\r\npadding-top: 28px;\r\nborder: 2px solid #999999;\r\nwidth: 100%;\r\nfont-size: 14px;\r\nline-height: 1.4;\"><span>星期一天气晴我离开你／不带任何行李／除了一本陪我放逐的日记／今天天晴／心情很低／突然决定离开你</span></section></section>');
INSERT INTO `wp_article_style` VALUES ('3', '1', '<section><section class=\"wxqq-borderleftcolor wxqq-borderRightcolor wxqq-bordertopcolor wxqq-borderbottomcolor\" style=\"border:5px solid #A50003;padding:5px;width:100%;\"><section class=\"wxqq-borderleftcolor wxqq-borderRightcolor wxqq-bordertopcolor wxqq-borderbottomcolor\" style=\"border:1px solid #A50003;padding:15px 20px;\"><p style=\"color:#A50003;text-align:center;border-bottom:1px solid #A50003\"><span class=\"wxqq-color\" data-brushtype=\"text\" style=\"font-size:48px\">情人节快乐</span></p><section data-style=\"color:#A50003;text-align:center;font-size:18px\" style=\"color:#A50003;text-align:center;width:96%;margin-left:5px;\"><p class=\"wxqq-color\" style=\"color:#A50003;text-align:center;font-size:18px\">happy valentine\'s day<span style=\"color:inherit; font-size:24px; line-height:1.6em; text-align:right; text-indent:2em\"></span><span style=\"color:rgb(227, 108, 9); font-size:24px; line-height:1.6em; text-align:right; text-indent:2em\"></span></p><section style=\"width:100%;\"><section><section><p style=\"color:#000;text-align:left;\">我们没有秘密，整天花前月下，别人以为我们不懂爱情，我们乐呵呵地笑大人们都太傻。</p></section></section></section></section></section></section></section>');
INSERT INTO `wp_article_style` VALUES ('4', '4', '<p><img src=\"http://www.wxbj.cn//ys/gz/gx2.gif\"></p>');
INSERT INTO `wp_article_style` VALUES ('5', '5', '<section class=\"tn-Powered-by-XIUMI\" style=\"margin-top: 0.5em; margin-bottom: 0.5em; border: none rgb(142, 201, 101); font-size: 14px; font-family: inherit; font-weight: inherit; text-decoration: inherit; color: rgb(142, 201, 101);\"><img data-src=\"http://mmbiz.qpic.cn/mmbiz/4HiaqFGEibVwaxcmNMU5abRHm7bkZ9icUxC3DrlItWpOnXSjEpZXIeIr2K0923xw43aKw8oibucqm8wkMYZvmibqDkg/0?wx_fmt=png\" class=\"tn-Powered-by-XIUMI\" data-type=\"png\" data-ratio=\"0.8055555555555556\" data-w=\"36\" _width=\"2.6em\" src=\"https://mmbiz.qlogo.cn/mmbiz/4HiaqFGEibVwaxcmNMU5abRHm7bkZ9icUxC3DrlItWpOnXSjEpZXIeIr2K0923xw43aKw8oibucqm8wkMYZvmibqDkg/640?wx_fmt=png\" style=\"float: right; width: 2.6em !important; visibility: visible !important; background-color: rgb(142, 201, 101);\"><section class=\"tn-Powered-by-XIUMI\" style=\"clear: both;\"></section><section class=\"tn-Powered-by-XIUMI\" style=\"padding-right: 10px; padding-left: 10px; text-align: center;\"><section class=\"tn-Powered-by-XIUMI\" style=\"text-align: left;\">炎热的夏季，应该吃点什么好呢！我们为您打造7月盛夏美食狂欢季，清暑解渴的热带水果之王【芒果下午茶】，海鲜盛宴上的【生蚝狂欢】，肉食者的天堂【澳洲之夜】，呼朋唤友，户外聚餐的最佳攻略【夏季BBQ】，消暑瘦身利器【迷你冬瓜盅】，清淡亦或重口味，总有一款是你所爱！</section></section><img data-src=\"http://mmbiz.qpic.cn/mmbiz/4HiaqFGEibVwaxcmNMU5abRHm7bkZ9icUxCkEmrfLmAXYYOXO0q4RGYsQqfzhO6SOdoFCTqYqwlS87ovGrQjCYmWw/0?wx_fmt=png\" class=\"tn-Powered-by-XIUMI\" data-type=\"png\" data-ratio=\"0.8055555555555556\" data-w=\"36\" _width=\"2.6em\" src=\"https://mmbiz.qlogo.cn/mmbiz/4HiaqFGEibVwaxcmNMU5abRHm7bkZ9icUxCkEmrfLmAXYYOXO0q4RGYsQqfzhO6SOdoFCTqYqwlS87ovGrQjCYmWw/640?wx_fmt=png\" style=\"width: 2.6em !important; visibility: visible !important; background-color: rgb(142, 201, 101);\"><p><br></p></section>');
INSERT INTO `wp_article_style` VALUES ('8', '6', '<blockquote class=\"wxqq-borderTopColor wxqq-borderRightColor wxqq-borderBottomColor wxqq-borderLeftColor\" style=\"border: 3px dotted rgb(230, 37, 191); padding: 10px; margin: 10px 0px; font-weight: normal; border-top-left-radius: 5px !important; border-top-right-radius: 5px !important; border-bottom-right-radius: 5px !important; border-bottom-left-radius: 5px !important;\"><h3 style=\"color:rgb(89,89,89);font-size:14px;margin:0;\"><span class=\"wxqq-bg\" style=\"background-color: rgb(230, 37, 191); color: rgb(255, 255, 255); padding: 2px 5px; font-size: 14px; margin-right: 15px; border-top-left-radius: 5px !important; border-top-right-radius: 5px !important; border-bottom-right-radius: 5px !important; border-bottom-left-radius: 5px !important;\">微信编辑器</span>微信号：<span class=\"wxqq-bg\" style=\"background-color: rgb(230, 37, 191); color: rgb(255, 255, 255); padding: 2px 5px; font-size: 14px; border-top-left-radius: 5px !important; border-top-right-radius: 5px !important; border-bottom-right-radius: 5px !important; border-bottom-left-radius: 5px !important;\">wxbj.cn</span></h3><p style=\"margin:10px 0 5px 0;\">微信公众号简介，欢迎使用微信在线图文排版编辑器助手！</p></blockquote>');
INSERT INTO `wp_article_style` VALUES ('9', '8', '<p><img src=\"http://www.wxbj.cn/ys/gz/yw1.gif\"></p>');
INSERT INTO `wp_article_style` VALUES ('7', '7', '<p><img src=\"https://mmbiz.qlogo.cn/mmbiz/cZV2hRpuAPhuxibIOsThcH7HF1lpQ0Yvkvh88U3ia9AbTPJSmriawnJ7W7S5iblSlSianbHLGO6IvD0N4g2y2JEFRoA/0/mmbizgif\"></p>');

-- -----------------------------
-- Table structure for `wp_article_style_group`
-- -----------------------------
DROP TABLE IF EXISTS `wp_article_style_group`;
;

-- -----------------------------
-- Records of `wp_article_style_group`
-- -----------------------------
INSERT INTO `wp_article_style_group` VALUES ('1', '标题', '标题样式');
INSERT INTO `wp_article_style_group` VALUES ('3', '卡片', '类卡片样式');
INSERT INTO `wp_article_style_group` VALUES ('4', '关注', '引导关注公众号的样式');
INSERT INTO `wp_article_style_group` VALUES ('5', '内容', '内容样式');
INSERT INTO `wp_article_style_group` VALUES ('6', '互推', '互推公众号的样式');
INSERT INTO `wp_article_style_group` VALUES ('7', '分割', '分割样式');
INSERT INTO `wp_article_style_group` VALUES ('8', '原文引导', '原文引导样式');

-- -----------------------------
-- Table structure for `wp_ask`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ask`;
;

-- -----------------------------
-- Records of `wp_ask`
-- -----------------------------
INSERT INTO `wp_ask` VALUES ('1', '没有良心', '0', '谁是没有良心的人', '谁是没有良心的人', '1467794945', '22', '1467794945', 'gh_89d5cf544493', '谢谢，请等待消息', '', '', '', '', '', '', 'default');

-- -----------------------------
-- Table structure for `wp_ask_answer`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ask_answer`;
;


-- -----------------------------
-- Table structure for `wp_ask_question`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ask_question`;
;


-- -----------------------------
-- Table structure for `wp_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `wp_attachment`;
;


-- -----------------------------
-- Table structure for `wp_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `wp_attribute`;
;

-- -----------------------------
-- Records of `wp_attribute`
-- -----------------------------
INSERT INTO `wp_attribute` VALUES ('5', 'nickname', '用户名', 'varchar(255) NULL', 'string', '', '', '0', '', '1', '1', '1', '1467174196', '1436929161', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('6', 'password', '登录密码', 'varchar(100) NULL', 'string', '', '', '0', '', '1', '0', '1', '1447302859', '1436929210', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('7', 'truename', '真实姓名', 'varchar(30) NULL', 'string', '', '', '0', '', '1', '0', '1', '1447302886', '1436929252', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('8', 'mobile', '联系电话', 'varchar(30) NULL', 'string', '', '', '0', '', '1', '0', '1', '1447302825', '1436929280', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('9', 'email', '邮箱地址', 'varchar(100) NULL', 'string', '', '', '0', '', '1', '0', '1', '1447302817', '1436929305', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('10', 'sex', '性别', 'tinyint(2) NULL', 'radio', '', '', '0', '0:保密\r\n1:男\r\n2:女', '1', '0', '1', '1447302800', '1436929397', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11', 'headimgurl', '头像地址', 'varchar(255) NULL', 'string', '', '', '0', '', '1', '0', '1', '1447302811', '1436929482', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('12', 'city', '城市', 'varchar(30) NULL', 'string', '', '', '0', '', '1', '0', '1', '1447302793', '1436929506', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('13', 'province', '省份', 'varchar(30) NULL', 'string', '', '', '0', '', '1', '0', '1', '1447302787', '1436929524', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('14', 'country', '国家', 'varchar(30) NULL', 'string', '', '', '0', '', '1', '0', '1', '1447302781', '1436929541', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('15', 'language', '语言', 'varchar(20) NULL', 'string', 'zh-cn', '', '0', '', '1', '0', '1', '1447302725', '1436929571', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('16', 'score', '金币值', 'int(10) NULL', 'num', '0', '', '0', '', '1', '0', '1', '1447302731', '1436929597', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('17', 'experience', '经验值', 'int(10) NULL', 'num', '0', '', '0', '', '1', '0', '1', '1447302738', '1436929619', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('18', 'unionid', '微信第三方ID', 'varchar(50) NULL', 'string', '', '', '0', '', '1', '0', '1', '1447302717', '1436929681', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('19', 'login_count', '登录次数', 'int(10) NULL', 'num', '0', '', '0', '', '1', '0', '1', '1447302710', '1436930011', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('20', 'reg_ip', '注册IP', 'varchar(30) NULL', 'string', '', '', '0', '', '1', '0', '1', '1447302746', '1436930035', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('21', 'reg_time', '注册时间', 'int(10) NULL', 'datetime', '', '', '0', '', '1', '0', '1', '1447302754', '1436930051', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('22', 'last_login_ip', '最近登录IP', 'varchar(30) NULL', 'string', '', '', '0', '', '1', '0', '1', '1447302761', '1436930072', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('23', 'last_login_time', '最近登录时间', 'int(10) NULL', 'datetime', '', '', '0', '', '1', '0', '1', '1447302770', '1436930087', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('24', 'status', '状态', 'tinyint(2) NULL', 'bool', '1', '', '0', '0:禁用\r\n1:启用', '1', '0', '1', '1447302703', '1436930138', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('25', 'is_init', '初始化状态', 'tinyint(2) NULL', 'bool', '0', '', '0', '0:未初始化\r\n1:已初始化', '1', '0', '1', '1447302696', '1436930184', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('26', 'is_audit', '审核状态', 'tinyint(2) NULL', 'bool', '0', '', '0', '0:未审核\r\n1:已审核', '1', '0', '1', '1447302688', '1436930216', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('27', 'subscribe_time', '用户关注公众号时间', 'int(10) NULL', 'datetime', '', '', '0', '', '1', '0', '1', '1437720655', '1437720655', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('28', 'remark', '微信用户备注', 'varchar(100) NULL', 'string', '', '', '0', '', '1', '0', '1', '1437720686', '1437720686', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('29', 'groupid', '微信端的分组ID', 'int(10) NULL', 'num', '', '', '0', '', '1', '0', '1', '1437720714', '1437720714', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('4', 'come_from', '来源', 'tinyint(1) NULL', 'select', '0', '', '0', '0:PC注册用户\r\n1:微信同步用户\r\n2:手机注册用户', '1', '0', '1', '1447302852', '1438331357', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('31', 'uid', '用户ID', 'int(10) NULL', 'num', '', '', '1', '', '2', '1', '1', '1436932588', '1436932588', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('32', 'has_public', '是否配置公众号', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:否\r\n1:是', '2', '0', '1', '1436933464', '1436933464', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('33', 'headface_url', '管理员头像', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '2', '0', '1', '1436933503', '1436933503', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('34', 'GammaAppId', '摇电视的AppId', 'varchar(30) NULL', 'string', '', '', '1', '', '2', '0', '1', '1436933562', '1436933562', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('35', 'GammaSecret', '摇电视的Secret', 'varchar(100) NULL', 'string', '', '', '1', '', '2', '0', '1', '1436933602', '1436933602', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('36', 'copy_right', '授权信息', 'varchar(255) NULL', 'string', '', '', '1', '', '2', '0', '1', '1436933690', '1436933690', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('37', 'tongji_code', '统计代码', 'text NULL', 'textarea', '', '', '1', '', '2', '0', '1', '1436933778', '1436933778', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('38', 'website_logo', '网站LOGO', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '2', '0', '1', '1436934006', '1436934006', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('39', 'menu_type', '菜单类型', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:顶级菜单|pid@hide\r\n1:侧栏菜单|pid@show', '3', '0', '1', '1435218508', '1435216049', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('40', 'pid', '上级菜单', 'varchar(50) NULL', 'cascade', '0', '', '1', 'type=db&table=manager_menu&menu_type=0&uid=[manager_id]', '3', '0', '1', '1438858450', '1435216147', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('41', 'title', '菜单名', 'varchar(50) NULL', 'string', '', '', '1', '', '3', '1', '1', '1435216185', '1435216185', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('42', 'url_type', '链接类型', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:插件|addon_name@show,url@hide\r\n1:外链|addon_name@hide,url@show', '3', '0', '1', '1435218596', '1435216291', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('43', 'addon_name', '插件名', 'varchar(30) NULL', 'dynamic_select', '', '', '1', 'table=addons&type=0&value_field=name&title_field=title&order=id asc', '3', '0', '1', '1439433250', '1435216373', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('44', 'url', '外链', 'varchar(255) NULL', 'string', '', '', '1', '', '3', '0', '1', '1435216436', '1435216436', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('45', 'target', '打开方式', 'char(50) NULL', 'select', '_self', '', '1', '_self:当前窗口打开\r\n_blank:在新窗口打开', '3', '0', '1', '1435216626', '1435216626', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('46', 'is_hide', '是否隐藏', 'tinyint(2) NULL', 'radio', '0', '', '1', '0:否\r\n1:是', '3', '0', '1', '1435216697', '1435216697', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('47', 'sort', '排序号', 'int(10) NULL', 'num', '0', '值越小越靠前', '1', '', '3', '0', '1', '1435217270', '1435217270', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('48', 'uid', '管理员ID', 'int(10) NULL', 'num', '', '', '4', '', '3', '0', '1', '1435224916', '1435223957', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('49', 'keyword', '关键词', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '4', '1', '1', '1388815953', '1388815953', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('50', 'addon', '关键词所属插件', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '4', '1', '1', '1388816207', '1388816207', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('51', 'aim_id', '插件表里的ID值', 'int(10) unsigned NOT NULL ', 'num', '', '', '1', '', '4', '1', '1', '1388816287', '1388816287', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('52', 'cTime', '创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '4', '0', '1', '1407251221', '1388816392', '', '1', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('53', 'token', 'Token', 'varchar(100) NULL ', 'string', '', '', '0', '', '4', '0', '1', '1408945788', '1391399528', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('54', 'keyword_length', '关键词长度', 'int(10) unsigned NULL ', 'num', '0', '', '1', '', '4', '0', '1', '1407251147', '1393918566', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('55', 'keyword_type', '匹配类型', 'tinyint(2) NULL ', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配\r\n4:正则匹配\r\n5:随机匹配', '4', '0', '1', '1417745067', '1393919686', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('56', 'extra_text', '文本扩展', 'text NULL ', 'textarea', '', '', '0', '', '4', '0', '1', '1407251248', '1393919736', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('57', 'extra_int', '数字扩展', 'int(10) NULL ', 'num', '', '', '0', '', '4', '0', '1', '1407251240', '1393919798', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('58', 'request_count', '请求数', 'int(10) NULL', 'num', '0', '用户回复的次数', '0', '', '4', '0', '1', '1401938983', '1401938983', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('59', 'qr_code', '二维码', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '5', '1', '1', '1406127577', '1388815953', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('60', 'addon', '二维码所属插件', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '5', '1', '1', '1406127594', '1388816207', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('61', 'aim_id', '插件表里的ID值', 'int(10) unsigned NOT NULL ', 'num', '', '', '1', '', '5', '1', '1', '1388816287', '1388816287', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('62', 'cTime', '创建时间', 'int(10) NULL', 'datetime', '', '', '1', '', '5', '0', '1', '1388816392', '1388816392', '', '1', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('63', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '5', '0', '1', '1391399528', '1391399528', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('64', 'action_name', '二维码类型', 'char(30) NULL', 'select', 'QR_SCENE', 'QR_SCENE为临时,QR_LIMIT_SCENE为永久 ', '1', 'QR_SCENE:临时二维码\r\nQR_LIMIT_SCENE:永久二维码', '5', '0', '1', '1406130162', '1393919686', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('65', 'extra_text', '文本扩展', 'text NULL ', 'textarea', '', '', '1', '', '5', '0', '1', '1393919736', '1393919736', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('66', 'extra_int', '数字扩展', 'int(10) NULL ', 'num', '', '', '1', '', '5', '0', '1', '1393919798', '1393919798', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('67', 'request_count', '请求数', 'int(10) NULL', 'num', '0', '用户回复的次数', '0', '', '5', '0', '1', '1402547625', '1401938983', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('68', 'scene_id', '场景ID', 'int(10) NULL', 'num', '0', '', '1', '', '5', '0', '1', '1406127542', '1406127542', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('69', 'is_use', '是否为当前公众号', 'tinyint(2) NULL', 'bool', '0', '', '0', '0:否\r\n1:是', '6', '0', '1', '1391682184', '1391682184', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('70', 'token', 'Token', 'varchar(100) NULL', 'string', '', '', '0', '', '6', '0', '1', '1402453598', '1391597344', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('71', 'uid', '用户ID', 'int(10) NULL ', 'num', '', '', '0', '', '6', '1', '1', '1391575873', '1391575210', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('72', 'public_name', '公众号名称', 'varchar(50) NOT NULL', 'string', '', '', '1', '', '6', '1', '1', '1391576452', '1391575955', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('73', 'public_id', '公众号原始id', 'varchar(100) NOT NULL', 'string', '', '请正确填写，保存后不能再修改，且无法接收到微信的信息', '1', '', '6', '1', '1', '1402453976', '1391576015', '', '1', '公众号原始ID已经存在，请不要重复增加', 'unique', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('74', 'wechat', '微信号', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '6', '1', '1', '1391576484', '1391576144', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('75', 'interface_url', '接口地址', 'varchar(255) NULL', 'string', '', '', '0', '', '6', '0', '1', '1392946881', '1391576234', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('76', 'headface_url', '公众号头像', 'varchar(255) NULL', 'picture', '', '', '1', '', '6', '0', '1', '1429847363', '1391576300', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('77', 'area', '地区', 'varchar(50) NULL', 'string', '', '', '0', '', '6', '0', '1', '1392946934', '1391576435', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('78', 'addon_config', '插件配置', 'text NULL', 'textarea', '', '', '0', '', '6', '0', '1', '1391576537', '1391576537', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('79', 'addon_status', '插件状态', 'text NULL', 'textarea', '', '', '0', '111:帐号配置\r\n93:互动游戏\r\n18:欢迎语\r\n19:微信用户中心\r\n56:自定义菜单\r\n101:微信卡券\r\n39:微官网\r\n42:微信宣传页\r\n48:自定义回复\r\n50:微调研\r\n91:微邀约\r\n97:微抢答\r\n100:通用表单\r\n106:微信红包\r\n107:竞猜\r\n108:微贺卡\r\n110:实物奖励\r\n126:开发者工具箱\r\n128:微名片\r\n130:自动回复\r\n133:支付通\r\n134:投票\r\n137:评论互动\r\n140:没回答的回复\r\n141:工作授权\r\n142:优惠券\r\n143:帮拆礼包\r\n144:会员卡\r\n145:签到\r\n146:微预约\r\n151:短信服务\r\n152:微考试\r\n153:微测试\r\n162:微社区\r\n163:扫码管理\r\n156:比赛抽奖\r\n164:一键绑定公众号\r\n', '6', '0', '1', '1391576571', '1391576571', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11363', 'truename', '收货人姓名', 'varchar(100) NULL', 'string', '', '', '1', '', '1154', '1', '1', '1423477690', '1423477548', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('80', 'type', '公众号类型', 'char(10) NULL', 'radio', '0', '', '1', '0:普通订阅号\r\n1:认证订阅号/普通服务号\r\n2:认证服务号', '6', '0', '1', '1416904702', '1393718575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('81', 'appid', 'AppID', 'varchar(255) NULL', 'string', '', '应用ID', '1', '', '6', '0', '1', '1416904750', '1393718735', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('82', 'secret', 'AppSecret', 'varchar(255) NULL', 'string', '', '应用密钥', '1', '', '6', '0', '1', '1416904771', '1393718806', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('83', 'group_id', '等级', 'int(10) unsigned NULL ', 'select', '0', '', '0', '', '6', '0', '1', '1393753499', '1393724468', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('84', 'is_audit', '是否审核', 'tinyint(2) NULL', 'bool', '0', '', '0', '0:否\r\n1:是', '6', '1', '1', '1430879018', '1430879007', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('85', 'is_init', '是否初始化', 'tinyint(2) NULL', 'bool', '0', '', '0', '0:否\r\n1:是', '6', '1', '1', '1430888244', '1430878899', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('86', 'encodingaeskey', 'EncodingAESKey', 'varchar(255) NULL', 'string', '', '安全模式下必填', '1', '', '6', '0', '1', '1419775850', '1419775850', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('87', 'tips_url', '提示关注公众号的文章地址', 'varchar(255) NULL', 'string', '', '', '1', '', '6', '0', '1', '1420789769', '1420789769', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('88', 'GammaAppId', 'GammaAppId', 'varchar(255) NULL', 'string', '', '', '1', '', '6', '0', '1', '1424529968', '1424529968', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('89', 'GammaSecret', 'GammaSecret', 'varchar(255) NULL', 'string', '', '', '1', '', '6', '0', '1', '1424529990', '1424529990', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('90', 'public_copy_right', '版权信息', 'varchar(255) NULL', 'string', '', '', '1', '', '6', '0', '1', '1431141576', '1431141576', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('91', 'domain', '自定义域名', 'varchar(30) NULL', 'string', '', '', '0', '', '6', '0', '1', '1439698931', '1439698931', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('92', 'title', '等级名', 'varchar(50) NULL', 'string', '', '', '1', '', '7', '0', '1', '1393724854', '1393724854', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('93', 'addon_status', '插件权限', 'text NULL', 'checkbox', '', '', '1', '111:帐号配置\r\n93:互动游戏\r\n18:欢迎语\r\n19:微信用户中心\r\n56:自定义菜单\r\n101:微信卡券\r\n39:微官网\r\n42:微信宣传页\r\n48:自定义回复\r\n50:微调研\r\n91:微邀约\r\n97:微抢答\r\n100:通用表单\r\n106:微信红包\r\n107:竞猜\r\n108:微贺卡\r\n110:实物奖励\r\n126:开发者工具箱\r\n128:微名片\r\n130:自动回复\r\n133:支付通\r\n134:投票\r\n137:评论互动\r\n140:没回答的回复\r\n141:工作授权\r\n142:优惠券\r\n143:帮拆礼包\r\n144:会员卡\r\n145:签到\r\n146:微预约\r\n151:短信服务\r\n152:微考试\r\n153:微测试\r\n162:微社区\r\n163:扫码管理\r\n156:比赛抽奖\r\n164:一键绑定公众号\r\n', '7', '0', '1', '1393731903', '1393725072', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('94', 'uid', '管理员UID', 'int(10) NULL ', 'admin', '', '', '1', '', '8', '1', '1', '1447215599', '1398933236', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('95', 'mp_id', '公众号ID', 'int(10) unsigned NOT NULL ', 'num', '', '', '4', '', '8', '1', '1', '1398933300', '1398933300', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('96', 'is_creator', '是否为创建者', 'tinyint(2) NULL', 'bool', '0', '', '0', '0:不是\r\n1:是', '8', '0', '1', '1398933380', '1398933380', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('97', 'addon_status', '插件权限', 'text NULL', 'checkbox', '', '', '1', '111:帐号配置\r\n93:互动游戏\r\n18:欢迎语\r\n19:微信用户中心\r\n56:自定义菜单\r\n101:微信卡券\r\n39:微官网\r\n42:微信宣传页\r\n48:自定义回复\r\n50:微调研\r\n91:微邀约\r\n97:微抢答\r\n100:通用表单\r\n106:微信红包\r\n107:竞猜\r\n108:微贺卡\r\n110:实物奖励\r\n126:开发者工具箱\r\n128:微名片\r\n130:自动回复\r\n133:支付通\r\n134:投票\r\n137:评论互动\r\n140:没回答的回复\r\n141:工作授权\r\n142:优惠券\r\n143:帮拆礼包\r\n144:会员卡\r\n145:签到\r\n146:微预约\r\n151:短信服务\r\n152:微考试\r\n153:微测试\r\n162:微社区\r\n163:扫码管理\r\n156:比赛抽奖\r\n164:一键绑定公众号\r\n', '8', '0', '1', '1398933475', '1398933475', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11362', 'uid', '用户ID', 'int(10) NULL', 'num', '', '', '0', '', '1154', '1', '1', '1429522999', '1423477509', '', '3', '', 'regex', 'get_mid', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('98', 'is_use', '是否为当前管理的公众号', 'tinyint(2) NULL', 'bool', '0', '', '0', '0:不是\r\n1:是', '8', '0', '1', '1398996982', '1398996975', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('99', 'attach', '上传文件', 'int(10) unsigned NOT NULL ', 'file', '', '支持xls,xlsx两种格式', '1', '', '9', '1', '1', '1407554177', '1407554177', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('100', 'icon', '分类图标', 'int(10) unsigned NULL ', 'picture', '', '', '1', '', '10', '0', '1', '1400047745', '1400047745', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('101', 'title', '分类名', 'varchar(255) NULL', 'string', '', '', '1', '', '10', '0', '1', '1400047764', '1400047764', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('102', 'sort', '排序号', 'int(10) NULL', 'num', '0', '值越小越靠前', '1', '', '10', '0', '1', '1400050453', '1400047786', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('103', 'keyword', '关键词', 'varchar(255) NULL', 'string', '', '多个关键词可以用空格分开，如“高富帅 白富美”', '1', '', '11', '1', '1', '1439194858', '1439194849', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('104', 'msg_type', '消息类型', 'char(50) NULL', 'select', 'text', '', '0', 'text:文本|content@show,group_id@hide,image_id@hide,voice_id@hide,video_id@hide\r\nnews:图文|content@hide,group_id@show,image_id@hide,voice_id@hide,video_id@hide\r\nimage:图片|content@hide,group_id@hide,image_id@show,voice_id@hide,video_id@hide\r\nvoice:语音|content@hide,group_id@hide,image_id@hide,voice_id@show,video_id@hide\r\nvideo:视频|content@hide,group_id@hide,image_id@hide,voice_id@hide,video_id@show\r\n', '11', '1', '1', '1464157324', '1439194979', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('105', 'content', '文本内容', 'text NULL', 'textarea', '', '', '1', '', '11', '0', '1', '1439195826', '1439195091', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('106', 'group_id', '图文', 'int(10) NULL', 'news', '', '', '1', '', '11', '0', '1', '1439204192', '1439195901', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('107', 'image_id', '上传图片', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '11', '0', '1', '1439195945', '1439195945', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('108', 'manager_id', '管理员ID', 'int(10) NULL', 'num', '', '', '0', '', '11', '0', '1', '1439203621', '1439203575', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('109', 'token', 'Token', 'varchar(50) NULL', 'string', '', '', '0', '', '11', '0', '1', '1439203612', '1439203612', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('110', 'name', '分类标识', 'varchar(255) NULL', 'string', '', '只能使用英文', '0', '', '12', '0', '1', '1403711345', '1397529355', '', '3', '只能输入由数字、26个英文字母或者下划线组成的标识名', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('111', 'title', '分类标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '12', '1', '1', '1397529407', '1397529407', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('112', 'icon', '分类图标', 'int(10) unsigned NULL ', 'picture', '', '', '1', '', '12', '0', '1', '1397529461', '1397529461', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('113', 'pid', '上一级分类', 'int(10) unsigned NULL ', 'select', '0', '如果你要增加一级分类，这里选择“无”即可', '1', '0:无', '12', '0', '1', '1398266132', '1397529555', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('114', 'path', '分类路径', 'varchar(255) NULL', 'string', '', '', '0', '', '12', '0', '1', '1397529604', '1397529604', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('115', 'module', '分类所属功能', 'varchar(255) NULL', 'string', '', '', '0', '', '12', '0', '1', '1397529671', '1397529671', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('116', 'sort', '排序号', 'int(10) unsigned NULL ', 'num', '0', '数值越小越靠前', '1', '', '12', '0', '1', '1397529705', '1397529705', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('117', 'is_show', '是否显示', 'tinyint(2) NULL', 'bool', '1', '', '1', '0:不显示\r\n1:显示', '12', '0', '1', '1397532496', '1397529809', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('118', 'intro', '分类描述', 'varchar(255) NULL', 'string', '', '', '1', '', '12', '0', '1', '1398414247', '1398414247', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('119', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '12', '0', '1', '1398593086', '1398523502', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('120', 'code', '分类扩展编号', 'varchar(255) NULL', 'string', '', '原分类或者导入分类的扩展编号', '0', '', '12', '0', '1', '1404182741', '1404182630', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('121', 'cTime', '发布时间', 'int(10) UNSIGNED NULL', 'datetime', '', '', '0', '', '13', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('122', 'name', '分组标识', 'varchar(100) NOT NULL', 'string', '', '英文字母或者下划线，长度不超过30', '1', '', '13', '1', '1', '1403624543', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('123', 'title', '分组标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '13', '1', '1', '1403624556', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('124', 'level', '最多级数', 'tinyint(1) unsigned NULL', 'select', '3', '', '1', '1:1级\r\n2:2级\r\n3:3级\r\n4:4级\r\n5:5级\r\n6:6级\r\n7:7级', '13', '0', '1', '1404193097', '1404192897', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('125', 'token', 'Token', 'varchar(100) NULL', 'string', '', '', '0', '', '13', '1', '1', '1408947244', '1396602859', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('126', 'title', '积分描述', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '14', '1', '1', '1438589622', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('127', 'name', '积分标识', 'varchar(50) NULL', 'string', '', '', '1', '', '14', '0', '1', '1438589601', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('128', 'mTime', '修改时间', 'int(10) NULL', 'datetime', '', '', '0', '', '14', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('129', 'experience', '经验值', 'int(10) NULL', 'num', '0', '可以是正数，也可以是负数，如 -10 表示减10个经验值', '1', '', '14', '0', '1', '1398564024', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('130', 'score', '金币值', 'int(10) NULL', 'num', '0', '可以是正数，也可以是负数，如 -10 表示减10个金币值', '1', '', '14', '0', '1', '1398564097', '1396062146', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('131', 'token', 'Token', 'varchar(255) NULL', 'string', '0', '', '0', '', '14', '0', '1', '1398564146', '1396602859', '', '3', '', 'regex', '', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('132', 'credit_name', '积分标识', 'varchar(50) NULL', 'string', '', '', '1', '', '15', '0', '1', '1398564405', '1398564405', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('133', 'uid', '用户ID', 'int(10) NULL', 'num', '0', '', '1', '', '15', '0', '1', '1398564351', '1398564351', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('134', 'experience', '经验值', 'int(10) NULL', 'num', '0', '', '1', '', '15', '0', '1', '1398564448', '1398564448', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('135', 'score', '金币值', 'int(10) NULL', 'num', '0', '', '1', '', '15', '0', '1', '1398564486', '1398564486', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('136', 'cTime', '记录时间', 'int(10) NULL', 'datetime', '', '', '0', '', '15', '0', '1', '1398564567', '1398564567', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('137', 'admin_uid', '操作者UID', 'int(10) NULL', 'num', '0', '', '0', '', '15', '0', '1', '1398564629', '1398564629', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('138', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '15', '0', '1', '1400603451', '1400603451', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('139', 'cover_id', '图片在本地的ID', 'int(10) NULL', 'num', '', '', '0', '', '16', '0', '1', '1438684652', '1438684652', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('140', 'cover_url', '本地URL', 'varchar(255) NULL', 'string', '', '', '0', '', '16', '0', '1', '1438684692', '1438684692', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('141', 'media_id', '微信端图文消息素材的media_id', 'varchar(100) NULL', 'string', '0', '', '0', '', '16', '0', '1', '1438744962', '1438684776', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('142', 'wechat_url', '微信端的图片地址', 'varchar(255) NULL', 'string', '', '', '0', '', '16', '0', '1', '1439973558', '1438684807', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('143', 'cTime', '创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '16', '0', '1', '1438684829', '1438684829', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('144', 'manager_id', '管理员ID', 'int(10) NULL', 'num', '', '', '0', '', '16', '0', '1', '1438684847', '1438684847', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('145', 'token', 'Token', 'varchar(100) NULL', 'string', '', '', '0', '', '16', '0', '1', '1438684865', '1438684865', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('146', 'title', '标题', 'varchar(100) NULL', 'string', '', '', '1', '', '17', '1', '1', '1438670933', '1438670933', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('147', 'author', '作者', 'varchar(30) NULL', 'string', '', '', '1', '', '17', '0', '1', '1438670961', '1438670961', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('148', 'cover_id', '封面', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '17', '0', '1', '1438674438', '1438670980', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('149', 'intro', '摘要', 'varchar(255) NULL', 'textarea', '', '', '1', '', '17', '0', '1', '1438671024', '1438671024', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('150', 'content', '内容', 'longtext  NULL', 'editor', '', '', '1', '', '17', '0', '1', '1440473839', '1438671049', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('151', 'link', '外链', 'varchar(255) NULL', 'string', '', '', '1', '', '17', '0', '1', '1438671066', '1438671066', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('152', 'group_id', '多图文组的ID', 'int(10) NULL', 'num', '0', '0 表示单图文，多于0 表示多图文中的第一个图文的ID值', '0', '', '17', '0', '1', '1438671163', '1438671163', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('153', 'thumb_media_id', '图文消息的封面图片素材id（必须是永久mediaID）', 'varchar(100) NULL', 'string', '', '', '0', '', '17', '0', '1', '1438671302', '1438671285', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('154', 'media_id', '微信端图文消息素材的media_id', 'varchar(100) NULL', 'string', '0', '', '1', '', '17', '0', '1', '1438744941', '1438671373', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('155', 'manager_id', '管理员ID', 'int(10) NULL', 'num', '', '', '0', '', '17', '0', '1', '1438683172', '1438683172', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('156', 'token', 'Token', 'varchar(100) NULL', 'string', '', '', '0', '', '17', '0', '1', '1438683194', '1438683194', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('157', 'cTime', '发布时间', 'int(10) NULL', 'datetime', '', '', '0', '', '17', '0', '1', '1438683499', '1438683499', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('158', 'bind_keyword', '关联关键词', 'varchar(50) NULL', 'string', '', '先在自定义回复里增加图文，多图文或者文本内容，再把它的关键词填写到这里', '1', '', '18', '0', '1', '1437984209', '1437984184', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('159', 'preview_openids', '预览人OPENID', 'text NULL', 'textarea', '', '选填，多个可用逗号或者换行分开，OpenID值可在微信用户的列表中找到', '1', '', '18', '0', '1', '1438049470', '1437985038', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('160', 'group_id', '群发对象', 'int(10) NULL', 'dynamic_select', '0', '全部用户或者某分组用户', '1', 'table=auth_group&manager_id=[manager_id]&token=[token]&value_field=id&title_field=title&first_option=全部用户', '18', '0', '1', '1438049058', '1437985498', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('161', 'type', '素材来源', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:站内关键词|bind_keyword@show,media_id@hide\r\n1:微信永久素材ID|bind_keyword@hide,media_id@show', '18', '0', '1', '1437988869', '1437988869', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('162', 'media_id', '微信素材ID', 'varchar(100) NULL', 'string', '', '微信后台的素材管理里永久素材的media_id值', '1', '', '18', '0', '1', '1437988973', '1437988973', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('163', 'send_type', '发送方式', 'tinyint(1) NULL', 'bool', '0', '', '1', '0:按用户组发送|group_id@show,send_openids@hide\r\n1:指定OpenID发送|group_id@hide,send_openids@show', '18', '0', '1', '1438049241', '1438049241', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('164', 'send_openids', '要发送的OpenID', 'text NULL', 'textarea', '', '多个可用逗号或者换行分开，OpenID值可在微信用户的列表中找到', '1', '', '18', '0', '1', '1438049362', '1438049362', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('165', 'msg_id', 'msg_id', 'varchar(255) NULL', 'string', '', '', '0', '', '18', '0', '1', '1439980539', '1438054616', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('166', 'publicid', '公众号ID', 'int(10) NULL', 'num', '0', '', '0', '', '19', '0', '1', '1439448400', '1439448400', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('167', 'module_name', '类型名', 'varchar(30) NULL', 'string', '', '', '0', '', '19', '0', '1', '1439448516', '1439448516', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('168', 'controller_name', '控制器名', 'varchar(30) NULL', 'string', '', '', '0', '', '19', '0', '1', '1439448567', '1439448567', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('169', 'action_name', '方法名', 'varchar(30) NULL', 'string', '', '', '0', '', '19', '0', '1', '1439448616', '1439448616', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('170', 'uid', '访问者ID', 'varchar(255) NULL', 'string', '0', '', '0', '', '19', '0', '1', '1439448654', '1439448654', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('171', 'ip', 'ip地址', 'varchar(30) NULL', 'string', '', '', '0', '', '19', '0', '1', '1439448742', '1439448742', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('172', 'brower', '浏览器', 'varchar(30) NULL', 'string', '', '', '0', '', '19', '0', '1', '1439448792', '1439448792', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('173', 'param', '其它GET参数', 'text NULL', 'textarea', '', '', '0', '', '19', '0', '1', '1439448834', '1439448834', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('174', 'referer', '访问的URL', 'varchar(255) NULL', 'string', '', '', '0', '', '19', '0', '1', '1439448886', '1439448874', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('175', 'cTime', '时间', 'int(10) NULL', 'datetime', '', '', '0', '', '19', '0', '1', '1439450668', '1439450668', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('176', 'wechat_group_name', '微信端的分组名', 'varchar(100) NULL', 'string', '', '', '0', '', '20', '0', '1', '1437635205', '1437635205', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('177', 'wechat_group_id', '微信端的分组ID', 'int(10) NULL', 'num', '-1', '', '0', '', '20', '0', '1', '1447659224', '1437635149', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('178', 'qr_code', '微信二维码', 'varchar(255) NULL', 'string', '', '', '0', '', '20', '0', '1', '1437635117', '1437635117', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('179', 'is_default', '是否默认自动加入', 'tinyint(1) NULL', 'radio', '0', '只有设置一个默认组，设置当前为默认组后之前的默认组将取消', '0', '0:否\r\n1:是', '20', '0', '1', '1437642358', '1437635042', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('180', 'token', 'Token', 'varchar(100) NULL', 'string', '', '', '0', '', '20', '0', '1', '1437634089', '1437634089', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('181', 'manager_id', '管理员ID', 'int(10) NULL', 'num', '0', '为0时表示系统用户组', '0', '', '20', '0', '1', '1437634309', '1437634062', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('182', 'rules', '权限', 'text NULL', 'textarea', '', '', '0', '', '20', '0', '1', '1437634022', '1437634022', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('183', 'type', '类型', 'tinyint(2) NULL', 'bool', '1', '', '0', '0:普通用户组\r\n1:微信用户组\r\n2:等级用户组\r\n3:认证用户组', '20', '0', '1', '1437633981', '1437633981', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('184', 'status', '状态', 'tinyint(2) NULL', 'bool', '1', '', '0', '1:正常\r\n0:禁用\r\n-1:删除', '20', '0', '1', '1437633826', '1437633826', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('185', 'description', '描述信息', 'text NULL', 'textarea', '', '', '1', '', '20', '0', '1', '1437633751', '1437633751', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('186', 'icon', '图标', 'int(10) UNSIGNED NULL', 'picture', '', '', '0', '', '20', '0', '1', '1437633711', '1437633711', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('187', 'title', '分组名称', 'varchar(30) NULL', 'string', '', '', '1', '', '20', '1', '1', '1437641907', '1437633598', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('188', 'wechat_group_count', '微信端用户数', 'int(10) NULL', 'num', '', '', '0', '', '20', '0', '1', '1437644061', '1437644061', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('189', 'is_del', '是否已删除', 'tinyint(1) NULL', 'bool', '0', '', '0', '0:否\r\n1:是', '20', '0', '1', '1437650054', '1437650044', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('190', 'sports_id', 'sports_id', 'int(10) NULL', 'num', '', '', '0', '', '21', '0', '1', '1432806979', '1432806979', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('191', 'type', 'type', 'varchar(30) NULL', 'string', '', '', '0', '', '21', '0', '1', '1432807001', '1432807001', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('192', 'time', 'time', 'varchar(50) NULL', 'string', '', '', '0', '', '21', '0', '1', '1432807028', '1432807028', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('193', 'total_count', 'total_count', 'int(10) NULL', 'num', '0', '', '0', '', '21', '0', '1', '1432807049', '1432807049', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('194', 'follow_count', 'follow_count', 'int(10) NULL', 'num', '0', '', '0', '', '21', '0', '1', '1432807063', '1432807063', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('195', 'aver_count', 'aver_count', 'int(10) NULL', 'num', '0', '', '0', '', '21', '0', '1', '1432807079', '1432807079', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('196', 'group_id', '分组样式', 'int(10) NULL', 'num', '0', '', '1', '', '22', '0', '1', '1436845570', '1436845570', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('197', 'style', '样式内容', 'text NULL', 'textarea', '', '请填写html', '1', '', '22', '1', '1', '1436846111', '1436846111', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('198', 'group_name', '分组名称', 'varchar(255) NULL', 'string', '', '', '1', '', '23', '1', '1', '1436845332', '1436845332', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('199', 'desc', '说明', 'text NULL', 'textarea', '', '', '1', '', '23', '0', '1', '1436845361', '1436845361', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('200', 'keyword', '关键词', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '24', '1', '1', '1396624337', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('201', 'keyword_type', '关键词类型', 'tinyint(2) NOT NULL', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配\r\n4:正则匹配\r\n5:随机匹配', '24', '1', '1', '1396624426', '1396061765', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('202', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '24', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('203', 'intro', '封面简介', 'text NULL', 'textarea', '', '', '1', '', '24', '1', '1', '1439367292', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('204', 'mTime', '修改时间', 'int(10) NULL', 'datetime', '', '', '0', '', '24', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('205', 'cover', '封面图片', 'int(10) unsigned NULL ', 'picture', '', '', '1', '', '24', '0', '1', '1396624534', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('206', 'cTime', '发布时间', 'int(10) unsigned NULL ', 'datetime', '', '', '0', '', '24', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('207', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '24', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('208', 'finish_tip', '结束语', 'text NULL', 'textarea', '', '为空默认为：抢答完成，谢谢参与', '1', '', '24', '1', '1', '1439367319', '1396953940', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('209', 'content', '活动介绍', 'text NULL', 'editor', '', '显示在用户进入的开始界面', '1', '', '24', '0', '1', '1420791982', '1420791908', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('210', 'shop_address', '商家地址', 'text NULL', 'textarea', '', '显示在马上开始的下面，多个地址用英文逗号或者换行分割', '1', '', '24', '0', '1', '1420798853', '1420794534', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('211', 'appids', '提示关注的公众号', 'text NULL', 'textarea', '', '格式：广东南方卫视|wx2d7ce60bbfc928ef 多个公众号用换行分割', '1', '', '24', '0', '1', '1420798902', '1420796356', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('212', 'finish_button', '成功抢答完后显示的按钮', 'text NULL', 'textarea', '', '格式：按钮名|跳转链接，如：百度|www.baidu.com 多个时换行分割', '1', '', '24', '0', '1', '1420857847', '1420857847', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('213', 'card_id', '卡券ID', 'varchar(255) NULL', 'string', '', '可为空', '1', '', '24', '0', '1', '1421406387', '1421406387', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('214', 'appsecre', '卡券对应的appsecre', 'varchar(255) NULL', 'string', '', '', '1', '', '24', '0', '1', '1421406470', '1421406470', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('215', 'template', '素材模板', 'varchar(255) NULL', 'string', 'default', '', '1', '', '24', '0', '1', '1430210161', '1430210161', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('216', 'answer', '回答内容', 'text NULL', 'textarea', '', '', '0', '', '25', '0', '1', '1396955766', '1396955766', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('217', 'openid', 'OpenId', 'varchar(255) NULL', 'string', '', '', '0', '', '25', '0', '1', '1430286439', '1396955581', '', '3', '', 'regex', 'get_openid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('218', 'uid', '用户UID', 'int(10) NULL ', 'num', '', '', '0', '', '25', '0', '1', '1396955530', '1396955530', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('219', 'question_id', 'question_id', 'int(10) unsigned NOT NULL ', 'num', '', '', '4', '', '25', '1', '1', '1396955412', '1396955392', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('220', 'cTime', '发布时间', 'int(10) unsigned NULL ', 'datetime', '', '', '0', '', '25', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('221', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '25', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('222', 'ask_id', 'ask_id', 'int(10) unsigned NOT NULL ', 'num', '', '', '4', '', '25', '1', '1', '1396955403', '1396955369', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('223', 'is_correct', '是否回答正确', 'tinyint(2) NULL', 'bool', '1', '', '0', '0:不正确\r\n1:正确', '25', '0', '1', '1420685956', '1420685956', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('224', 'times', '次数', 'int(4) NULL', 'num', '0', '', '0', '', '25', '0', '1', '1420965038', '1420965038', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('225', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '26', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('226', 'intro', '问题描述', 'text NULL', 'textarea', '', '', '1', '', '26', '0', '1', '1396954176', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('227', 'cTime', '发布时间', 'int(10) unsigned NULL ', 'datetime', '', '', '0', '', '26', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('228', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '26', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('229', 'is_must', '是否必填', 'tinyint(2) NULL', 'bool', '1', '', '0', '0:否\r\n1:是', '26', '0', '1', '1420686586', '1396954649', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('230', 'extra', '参数', 'text NOT NULL', 'textarea', '', '类型为单选、多选时的定义数据，格式见上面的提示', '1', '', '26', '1', '1', '1421749164', '1396954558', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('231', 'type', '问题类型', 'char(50) NOT NULL', 'radio', 'radio', '', '1', 'radio:单选题\r\ncheckbox:多选题', '26', '1', '1', '1420689062', '1396954463', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('232', 'ask_id', 'ask_id', 'int(10) unsigned NOT NULL ', 'num', '', '', '4', '', '26', '1', '1', '1396954240', '1396954240', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('233', 'sort', '排序号', 'int(10) unsigned NULL ', 'num', '0', '值越小越靠前', '1', '', '26', '0', '1', '1420689390', '1396955010', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('234', 'answer', '正确答案', 'varchar(255) NOT NULL', 'string', '', '多个答案用空格分开，如： A B C', '1', '', '26', '1', '1', '1421749143', '1420685041', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('235', 'is_last', '是否最后一题', 'tinyint(2) NULL', 'bool', '0', '如设置为最后一题，用户回答后进入完成页面，否则进入等待下一题提示页面', '0', '0:否\r\n1:是', '26', '0', '1', '1421749096', '1420686448', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('236', 'wait_time', '等待时间', 'int(10) NULL', 'num', '0', '单位为秒，表示答题后进入下一题的间隔时间', '1', '', '26', '0', '1', '1420688805', '1420688703', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('237', 'percent', '抢中概率', 'int(10) NULL', 'num', '100', '抢到题目的百分比，请填写0~100之间的整数，如填写50表示概率为50%', '1', '', '26', '0', '1', '1420855970', '1420855970', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('238', 'answer_time', '答题时间', 'int(10) NULL', 'num', '', '不填则为无答题时间限制', '1', '', '26', '0', '1', '1427541360', '1427541360', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('239', 'permission', '权限设置', 'char(50) NULL', 'select', '1', '', '1', '1:完全公开(公众人物)\r\n2:群友可见(商务交往)\r\n3:交换名片可见(私人来往)\r\n4:仅自己可见(绝密保存)', '27', '0', '1', '1438945015', '1438945015', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('240', 'intro', '个人介绍', 'text NULL', 'textarea', '', '', '1', '', '27', '0', '1', '1438944828', '1438944828', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('241', 'wishing', '希望结交', 'varchar(100) NULL', 'string', '', '', '1', '', '27', '0', '1', '1438942908', '1438942908', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('242', 'wechat', '微信号', 'varchar(50) NULL', 'string', '', '', '1', '', '27', '0', '1', '1438942392', '1438942392', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('243', 'Email', '邮箱', 'varchar(100) NULL', 'string', '', '', '1', '', '27', '0', '1', '1438942359', '1438942359', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('244', 'telephone', '座机', 'varchar(30) NULL', 'string', '', '', '1', '', '27', '0', '1', '1438942330', '1438942330', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('245', 'address', '地址', 'varchar(255) NULL', 'string', '', '', '1', '', '27', '0', '1', '1438933681', '1438933681', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('246', 'company_url', '公司网址', 'varchar(255) NULL', 'string', '', '', '1', '', '27', '0', '1', '1438933650', '1438933650', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('247', 'department', '所属部门', 'varchar(50) NULL', 'string', '', '', '1', '', '27', '0', '1', '1438933471', '1438933471', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('248', 'company', '公司名称', 'varchar(100) NULL', 'string', '', '', '1', '', '27', '1', '1', '1438933418', '1438933418', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('249', 'mobile', '手机', 'varchar(30) NULL', 'string', '', '', '1', '', '27', '1', '1', '1438933381', '1438933381', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('250', 'position', '职位头衔', 'varchar(50) NULL', 'string', '', '', '1', '如：XX创始人、xx级教师、xx投资顾问、XX爸爸、XX达人', '27', '0', '1', '1438933330', '1438933330', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('251', 'headface', '头像', 'int(10) UNSIGNED NULL', 'picture', '', '', '0', '', '27', '0', '1', '1439175454', '1438944864', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('252', 'personal_url', '个人主页', 'varchar(255) NULL', 'string', '', '', '1', '', '27', '0', '1', '1438944804', '1438944804', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('253', 'interest', '兴趣', 'varchar(255) NULL', 'string', '', '', '1', '', '27', '0', '1', '1438942945', '1438942945', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('254', 'tag', '人物标签', 'varchar(255) NULL', 'string', '', '多个用逗号分开', '1', '', '27', '0', '1', '1438942491', '1438942491', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('255', 'weibo', '微博', 'varchar(255) NULL', 'string', '', '', '1', '', '27', '0', '1', '1438942443', '1438942443', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('256', 'qq', 'QQ号', 'varchar(30) NULL', 'string', '', '', '1', '', '27', '0', '1', '1438942418', '1438942418', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('257', 'service', '产品服务', 'text NULL', 'textarea', '', '', '1', '', '27', '1', '1', '1438933623', '1438933623', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('258', 'truename', '真实姓名', 'varchar(50) NULL', 'string', '', '', '1', '', '27', '1', '1', '1438931443', '1438931443', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('259', 'uid', '用户ID', 'int(10) NULL', 'num', '', '', '0', '', '27', '0', '1', '1438931293', '1438931293', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('260', 'template', '选择的模板', 'varchar(50) NULL', 'string', '', '', '0', '', '27', '0', '1', '1438947089', '1438947089', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('261', 'token', 'Token', 'varchar(100) NULL', 'string', '', '', '0', '', '27', '0', '1', '1439869080', '1439290478', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('262', 'from_uid', '收藏人ID', 'int(10) NULL', 'num', '', '', '0', '', '28', '0', '1', '1439188549', '1439188462', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('263', 'to_uid', '被收藏人的ID', 'int(10) NULL', 'num', '', '', '0', '', '28', '0', '1', '1439188512', '1439188512', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('264', 'cTime', '收藏时间', 'int(10) NULL', 'datetime', '', '', '0', '', '28', '0', '1', '1439188537', '1439188537', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('265', 'uid', 'uid', 'int(10) NULL', 'num', '', '', '1', '', '29', '0', '1', '1430998977', '1430998977', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('266', 'cover', '素材封面', 'int(10) UNSIGNED NULL', 'picture', '', '', '0', '', '29', '0', '1', '1427435373', '1422000629', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('267', 'balance', '红包余额', 'varchar(30) NULL', 'string', '', '红包余额，以分为单位。红包类型必填 （LUCKY_MONEY），其他卡券类型不填', '0', '', '29', '0', '1', '1427435295', '1421982394', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('268', 'card_id', '卡券ID', 'varchar(100) NOT NULL', 'string', '', '', '0', '', '29', '1', '1', '1427435272', '1421980436', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('269', 'openid', 'OpenID', 'text NULL', 'textarea', '', '指定领取者的openid，只有该用户能领取。bind_openid字段为true的卡券必须填写，非自定义openid 不必填写', '0', '', '29', '0', '1', '1427435344', '1421980851', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('270', 'appsecre', '开通卡券的商家公众号密钥', 'varchar(255) NULL', 'string', '', '', '1', '', '29', '1', '1', '1464711086', '1421980516', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('271', 'code', '卡券code码', 'text NULL', 'textarea', '', '指定的卡券code 码，只能被领一次。use_custom_code 字段为true 的卡券必须填写，非自定义code 不必填写', '1', '', '29', '0', '1', '1421980773', '1421980773', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('272', 'content', '活动介绍', 'text NULL', 'editor', '', '', '1', '', '29', '0', '1', '1421981078', '1421981078', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('273', 'background', '背景图', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '29', '0', '1', '1422000931', '1422000931', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('274', 'token', 'token', 'varchar(50) NULL', 'string', '', '', '1', '', '29', '0', '1', '1430999013', '1430999013', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('275', 'title', '卡券标题', 'varchar(255) NULL', 'string', '卡券', '', '1', '', '29', '0', '1', '1427435445', '1427435445', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('276', 'button_color', '领取按钮颜色', 'varchar(255) NULL', 'string', '#0dbd02', '', '1', '', '29', '0', '1', '1427435492', '1427435492', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('277', 'head_bg_color', '头部背景颜色', 'varchar(255) NULL', 'string', '#35a2dd', '', '1', '', '29', '0', '1', '1427435535', '1427435535', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('278', 'shop_name', '商家名称', 'varchar(255) NULL', 'string', '', '', '1', '', '29', '0', '1', '1427438002', '1427438002', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('279', 'shop_logo', '商家LOGO', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '29', '0', '1', '1427437781', '1427437781', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('280', 'more_button', '添加更多按钮', 'text NULL', 'textarea', '', '', '1', '', '29', '0', '1', '1427512791', '1427512791', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('281', 'template', '素材模板', 'varchar(255) NULL', 'string', 'default', '', '1', '', '29', '0', '1', '1430129779', '1430129779', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1132', 'aim_table', '评论关联数据表', 'varchar(30) NULL', 'string', '', '', '0', '', '130', '0', '1', '1432602501', '1432602501', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1133', 'aim_id', '评论关联ID', 'int(10) NULL', 'num', '', '', '0', '', '130', '0', '1', '1432602466', '1432602466', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1134', 'cTime', '评论时间', 'int(10) NULL', 'datetime', '', '', '0', '', '130', '0', '1', '1432602404', '1432602404', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1135', 'follow_id', 'follow_id', 'int(10) NULL', 'num', '', '', '0', '', '130', '1', '1', '1432602345', '1432602345', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1136', 'content', '评论内容', 'text NULL', 'textarea', '', '', '0', '', '130', '1', '1', '1432602376', '1432602376', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1137', 'is_audit', '是否审核', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:未审核\r\n1:已审核', '130', '0', '1', '1435031747', '1435029949', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1138', 'uid', 'uid', 'int(10) NULL', 'num', '', '', '0', '', '130', '0', '1', '1435561416', '1435561392', '', '3', '', 'regex', 'get_mid', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1356', 'background', '素材背景图', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '152', '0', '1', '1422000992', '1422000992', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1357', 'keyword', '关键词', 'varchar(100) NULL', 'string', '', '', '0', '', '152', '0', '1', '1422330526', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1358', 'use_tips', '使用说明', 'text NULL', 'editor', '', '用户获取优惠券后显示的提示信息', '1', '', '152', '1', '1', '1420868972', '1399259489', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1359', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '152', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1360', 'intro', '封面简介', 'text NULL', 'textarea', '', '', '0', '', '152', '0', '1', '1418885972', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1361', 'end_time', '领取结束时间', 'int(10) NULL', 'datetime', '', '', '1', '', '152', '0', '1', '1427161023', '1399259433', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1362', 'cover', '优惠券图片', 'int(10) unsigned NULL ', 'picture', '', '', '1', '', '152', '0', '1', '1418886050', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1363', 'cTime', '发布时间', 'int(10) unsigned NULL ', 'datetime', '', '', '0', '', '152', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1364', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '152', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1365', 'start_time', '开始时间', 'int(10) NULL', 'datetime', '', '', '1', '', '152', '0', '1', '1422330558', '1399259416', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1366', 'end_tips', '领取结束说明', 'text NULL', 'textarea', '', '活动过期或者结束说明', '1', '', '152', '0', '1', '1427161168', '1399259570', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1367', 'end_img', '领取结束提示图片', 'int(10) unsigned NULL ', 'picture', '', '可为空', '1', '', '152', '0', '1', '1427161296', '1400989793', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1368', 'num', '优惠券数量', 'int(10) unsigned NULL ', 'num', '0', '0表示不限制数量', '1', '', '152', '0', '1', '1399259838', '1399259808', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1369', 'max_num', '每人最多允许获取次数', 'int(10) unsigned NULL ', 'num', '1', '0表示不限制数量', '0', '', '152', '0', '1', '1447758805', '1399260079', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1370', 'follower_condtion', '粉丝状态', 'char(50) NULL', 'select', '1', '粉丝达到设置的状态才能获取', '0', '0:不限制\r\n1:已关注\r\n2:已绑定信息\r\n3:会员卡成员', '152', '0', '1', '1418885814', '1399260479', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1371', 'credit_conditon', '积分限制', 'int(10) unsigned NULL ', 'num', '0', '粉丝达到多少积分后才能领取，领取后不扣积分', '0', '', '152', '0', '1', '1418885804', '1399260618', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1372', 'credit_bug', '积分消费', 'int(10) unsigned NULL ', 'num', '0', '用积分中的财富兑换、兑换后扣除相应的积分财富', '0', '', '152', '0', '1', '1418885794', '1399260764', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1373', 'addon_condition', '插件场景限制', 'varchar(255) NULL', 'string', '', '格式：[插件名:id值]，如[投票:10]表示对ID为10的投票投完才能领取，更多的说明见表单上的提示', '0', '', '152', '0', '1', '1418885827', '1399261026', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1374', 'collect_count', '已领取数', 'int(10) unsigned NULL ', 'num', '0', '', '0', '', '152', '0', '1', '1400992246', '1399270900', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1375', 'view_count', '浏览人数', 'int(10) unsigned NULL ', 'num', '0', '', '0', '', '152', '0', '1', '1399270926', '1399270926', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1376', 'addon', '插件', 'char(50) NULL', 'select', 'public', '', '0', 'public:通用\r\ninvite:微邀约', '152', '0', '1', '1418885638', '1418885638', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1377', 'shop_uid', '商家管理员ID', 'varchar(255) NULL', 'string', '', '', '0', '', '152', '0', '1', '1421750246', '1418900122', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1378', 'use_count', '已使用数', 'int(10) NULL', 'num', '0', '', '0', '', '152', '0', '1', '1418910237', '1418910237', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1379', 'pay_password', '核销密码', 'varchar(255) NULL', 'string', '', '', '1', '', '152', '0', '1', '1420875229', '1420875229', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1380', 'empty_prize_tips', '奖品抽完后的提示', 'varchar(255) NULL', 'string', '', '不填写时默认显示：您来晚了，优惠券已经领取完', '1', '', '152', '0', '1', '1421394437', '1421394267', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1381', 'start_tips', '活动还没开始时的提示语', 'varchar(255) NULL', 'string', '', '', '1', '', '152', '0', '1', '1423134546', '1423134546', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1382', 'more_button', '其它按钮', 'text NULL', 'textarea', '', '格式：按钮名称|按钮跳转地址，每行一个。如：查看官网|http://weiphp.cn', '1', '', '152', '0', '1', '1423193853', '1423193853', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1383', 'over_time', '使用的截止时间', 'int(10) NULL', 'datetime', '', '券的使用截止时间，为空时表示不限制', '1', '', '152', '0', '1', '1427161334', '1427161118', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1384', 'use_start_time', '使用开始时间', 'int(10) NULL', 'datetime', '', '', '1', '', '152', '1', '1', '1427280116', '1427280008', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1385', 'shop_name', '商家名称', 'varchar(255) NULL', 'string', '优惠商家', '', '1', '', '152', '0', '1', '1427280255', '1427280255', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1386', 'shop_logo', '商家LOGO', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '152', '0', '1', '1427280293', '1427280293', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1387', 'head_bg_color', '头部背景颜色', 'varchar(255) NULL', 'string', '#35a2dd', '', '1', '', '152', '0', '1', '1427282839', '1427282785', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1388', 'button_color', '按钮颜色', 'varchar(255) NULL', 'string', '#0dbd02', '', '1', '', '152', '0', '1', '1427282886', '1427282886', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1389', 'template', '素材模板', 'varchar(255) NULL', 'string', 'default', '', '1', '', '152', '0', '1', '1430127336', '1430127336', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1390', 'name', '店名', 'varchar(100) NULL', 'string', '', '', '1', '', '153', '1', '1', '1427164635', '1427164635', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1391', 'address', '详细地址', 'varchar(255) NULL', 'string', '', '', '1', '', '153', '1', '1', '1427164668', '1427164668', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1392', 'phone', '联系电话', 'varchar(30) NULL', 'string', '', '', '1', '', '153', '0', '1', '1427166529', '1427164707', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1393', 'gps', 'GPS经纬度', 'varchar(50) NULL', 'string', '', '格式：经度,纬度', '1', '', '153', '0', '1', '1427371523', '1427164833', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1394', 'coupon_id', '所属优惠券编号', 'int(10) NULL', 'num', '', '', '4', '', '153', '0', '1', '1427165806', '1427165806', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1397', 'coupon_id', 'coupon_id', 'int(10) NULL', 'num', '', '', '1', '', '154', '0', '1', '1427356371', '1427356371', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1398', 'shop_id', 'shop_id', 'int(10) NULL', 'num', '', '', '1', '', '154', '0', '1', '1427356387', '1427356387', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('330', 'sort', '排序号', 'tinyint(4) NULL ', 'num', '0', '数值越小越靠前', '1', '', '34', '0', '1', '1394523288', '1394519175', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('331', 'pid', '一级菜单', 'int(10) NULL', 'select', '0', '如果是一级菜单，选择“无”即可', '1', '0:无', '34', '0', '1', '1416810279', '1394518930', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('332', 'title', '菜单名', 'varchar(50) NOT NULL', 'string', '', '可创建最多 3 个一级菜单，每个一级菜单下可创建最多 5 个二级菜单。编辑中的菜单不会马上被用户看到，请放心调试。', '1', '', '34', '1', '1', '1408951570', '1394518988', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('333', 'keyword', '关联关键词', 'varchar(100) NULL', 'string', '', '', '1', '', '34', '0', '1', '1464331802', '1394519054', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('334', 'url', '关联URL', 'varchar(255) NULL ', 'string', '', '', '1', '', '34', '0', '1', '1394519090', '1394519090', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('335', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '34', '0', '1', '1394526820', '1394526820', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('336', 'type', '类型', 'varchar(30) NULL', 'bool', 'click', '', '1', 'click:点击推事件|keyword@show,url@hide\r\nview:跳转URL|keyword@hide,url@show\r\nscancode_push:扫码推事件|keyword@show,url@hide\r\nscancode_waitmsg:扫码带提示|keyword@show,url@hide\r\npic_sysphoto:弹出系统拍照发图|keyword@show,url@hide\r\npic_photo_or_album:弹出拍照或者相册发图|keyword@show,url@hide\r\npic_weixin:弹出微信相册发图器|keyword@show,url@hide\r\nlocation_select:弹出地理位置选择器|keyword@show,url@hide\r\nnone:无事件的一级菜单|keyword@hide,url@hide', '34', '0', '1', '1416812039', '1416810588', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('337', 'keyword', '关键词', 'varchar(255) NULL', 'string', '', '', '1', '', '35', '0', '1', '1396602514', '1396602514', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('338', 'keyword_type', '关键词类型', 'tinyint(2) NULL', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配\r\n4:正则匹配\r\n5:随机匹配', '35', '0', '1', '1396602706', '1396602548', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('339', 'mult_ids', '多图文ID', 'varchar(255) NULL', 'string', '', '', '0', '', '35', '0', '1', '1396602601', '1396602578', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('340', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '35', '0', '1', '1396602821', '1396602821', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('341', 'keyword', '关键词', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '36', '1', '1', '1396061575', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('342', 'keyword_type', '关键词类型', 'tinyint(2) NULL', 'select', '', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配\r\n4:正则匹配\r\n5:随机匹配', '36', '0', '1', '1396061814', '1396061765', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('343', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '36', '1', '1', '1396061877', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('344', 'intro', '简介', 'text NULL', 'textarea', '', '', '1', '', '36', '0', '1', '1396061947', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('345', 'cate_id', '所属类别', 'int(10) unsigned NULL ', 'select', '0', '要先在微官网分类里配置好分类才可选择', '1', '0:请选择分类', '36', '0', '1', '1396078914', '1396062003', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('346', 'cover', '封面图片', 'int(10) unsigned NULL ', 'picture', '', '', '1', '', '36', '0', '1', '1396062093', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('347', 'content', '内容', 'text NULL', 'editor', '', '', '1', '', '36', '0', '1', '1396062146', '1396062146', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('348', 'cTime', '发布时间', 'int(10) NULL', 'datetime', '', '', '0', '', '36', '0', '1', '1396075102', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('349', 'sort', '排序号', 'int(10) unsigned NULL ', 'num', '0', '数值越小越靠前', '1', '', '36', '0', '1', '1396510508', '1396510508', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('350', 'view_count', '浏览数', 'int(10) unsigned NULL ', 'num', '0', '', '0', '', '36', '0', '1', '1396510630', '1396510630', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('351', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '36', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('352', 'jump_url', '外链', 'varchar(255) NULL', 'string', '', '如需跳转填写网址(记住必须有http://)如果填写了图文详细内容，这里请留空，不要设置！', '1', '', '36', '0', '1', '1402482073', '1402482073', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('353', 'author', '作者', 'varchar(50) NULL', 'string', '', '为空时取当前用户名', '1', '', '36', '0', '1', '1437988055', '1437988055', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('354', 'keyword', '关键词', 'varchar(255) NULL', 'string', '', '多个关键词请用空格分开：例如: 高 富 帅', '1', '', '37', '0', '1', '1396578460', '1396578212', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('355', 'keyword_type', '关键词类型', 'tinyint(2) NULL', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配\r\n4:正则匹配\r\n5:随机匹配', '37', '0', '1', '1396623302', '1396578249', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('356', 'content', '回复内容', 'text NULL', 'textarea', '', '请不要多于1000字否则无法发送。支持加超链接，但URL必须带http://', '1', '', '37', '0', '1', '1396607362', '1396578597', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('357', 'view_count', '浏览数', 'int(10) unsigned NULL ', 'num', '0', '', '0', '', '37', '0', '1', '1396580643', '1396580643', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('358', 'sort', '排序号', 'int(10) unsigned NULL ', 'num', '0', '', '1', '', '37', '0', '1', '1396580674', '1396580674', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('359', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '37', '0', '1', '1396603007', '1396603007', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('360', 'follow_id', '粉丝id', 'int(10) NULL', 'num', '', '', '1', '', '38', '0', '1', '1432619233', '1432619233', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('361', 'sports_id', '场次id', 'int(10) NULL', 'num', '', '', '1', '', '38', '0', '1', '1432690316', '1432619261', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('362', 'count', '抽奖次数', 'int(10) NULL', 'num', '0', '', '1', '', '38', '0', '1', '1432619288', '1432619288', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('363', 'uid', 'uid', 'int(10) NULL', 'num', '', '', '0', '', '38', '0', '1', '1435313298', '1435313298', '', '3', '', 'regex', 'get_mid', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('364', 'cTime', '支持时间', 'int(10) NULL', 'datetime', '', '', '1', '', '38', '0', '1', '1432690461', '1432690461', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('365', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '39', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('366', 'cTime', '发布时间', 'int(10) UNSIGNED NULL', 'datetime', '', '', '0', '', '39', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('367', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '39', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('368', 'password', '表单密码', 'varchar(255) NULL', 'string', '', '如要用户输入密码才能进入表单，则填写此项。否则留空，用户可直接进入表单', '0', '', '39', '0', '1', '1396871497', '1396672643', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('369', 'keyword_type', '关键词类型', 'tinyint(2) NOT NULL', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配', '39', '1', '1', '1396624426', '1396061765', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('370', 'jump_url', '提交后跳转的地址', 'varchar(255) NULL', 'string', '', '要以http://开头的完整地址，为空时不跳转', '1', '', '39', '0', '1', '1402458121', '1399800276', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('371', 'content', '详细介绍', 'text NULL', 'editor', '', '可不填', '1', '', '39', '0', '1', '1396865295', '1396865295', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('372', 'finish_tip', '用户提交后提示内容', 'text NULL', 'string', '', '为空默认为：提交成功，谢谢参与', '1', '', '39', '0', '1', '1447497102', '1396673689', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('373', 'can_edit', '是否允许编辑', 'tinyint(2) NULL', 'bool', '0', '用户提交表单是否可以再编辑', '1', '0:不允许\r\n1:允许', '39', '0', '1', '1396688624', '1396688624', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('374', 'intro', '封面简介', 'text NULL', 'textarea', '', '', '1', '', '39', '1', '1', '1439371986', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('375', 'mTime', '修改时间', 'int(10) NULL', 'datetime', '', '', '0', '', '39', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('376', 'cover', '封面图片', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '39', '1', '1', '1439372018', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('377', 'keyword', '关键词', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '39', '1', '1', '1465895484', '1396061575', 'keyword_unique', '3', '该关键词已经存在', 'function', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('378', 'template', '模板', 'varchar(255) NULL', 'string', 'default', '', '1', '', '39', '0', '1', '1431661124', '1431661124', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('379', 'is_show', '是否显示', 'tinyint(2) NULL', 'select', '1', '是否显示在表单中', '1', '1:显示\r\n0:不显示', '40', '0', '1', '1396848437', '1396848437', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('380', 'forms_id', '表单ID', 'int(10) UNSIGNED NULL', 'num', '', '', '4', '', '40', '0', '1', '1396710040', '1396690613', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('381', 'error_info', '出错提示', 'varchar(255) NULL', 'string', '', '验证不通过时的提示语', '1', '', '40', '0', '1', '1396685920', '1396685920', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('382', 'sort', '排序号', 'int(10) UNSIGNED NULL', 'num', '0', '值越小越靠前', '1', '', '40', '0', '1', '1396685825', '1396685825', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('383', 'validate_rule', '正则验证', 'varchar(255) NULL', 'string', '', '为空表示不作验证', '1', '', '40', '0', '1', '1396685776', '1396685776', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('384', 'is_must', '是否必填', 'tinyint(2) NULL', 'bool', '', '用于自动验证', '1', '0:否\r\n1:是', '40', '0', '1', '1396685579', '1396685579', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('385', 'remark', '字段备注', 'varchar(255) NULL', 'string', '', '用于表单中的提示', '1', '', '40', '0', '1', '1396685482', '1396685482', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('386', 'name', '字段名', 'varchar(100) NULL', 'string', '', '请输入字段名 英文字母开头，长度不超过30', '1', '', '40', '1', '1', '1447638080', '1396676792', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('387', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '40', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('388', 'value', '默认值', 'varchar(255) NULL', 'string', '', '字段的默认值', '1', '', '40', '0', '1', '1396685291', '1396685291', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('389', 'title', '字段标题', 'varchar(255) NOT NULL', 'string', '', '请输入字段标题，用于表单显示', '1', '', '40', '1', '1', '1396676830', '1396676830', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('390', 'mTime', '修改时间', 'int(10) NULL', 'datetime', '', '', '0', '', '40', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('391', 'extra', '参数', 'text NULL', 'textarea', '', '字段类型为单选、多选、下拉选择和级联选择时的定义数据，其它字段类型为空', '1', '', '40', '0', '1', '1396835020', '1396685105', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('392', 'type', '字段类型', 'char(50) NOT NULL', 'select', 'string', '用于表单中的展示方式', '1', 'string:单行输入\r\ntextarea:多行输入\r\nradio:单选\r\ncheckbox:多选\r\nselect:下拉选择\r\ndatetime:时间\r\npicture:上传图片', '40', '1', '1', '1396871262', '1396683600', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('393', 'forms_id', '表单ID', 'int(10) UNSIGNED NULL', 'num', '', '', '4', '', '41', '0', '1', '1396710064', '1396688308', '', '3', '', 'regex', '', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('394', 'value', '表单值', 'text NULL', 'textarea', '', '', '0', '', '41', '0', '1', '1396688355', '1396688355', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('395', 'cTime', '增加时间', 'int(10) NULL', 'datetime', '', '', '0', '', '41', '0', '1', '1396688434', '1396688434', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('396', 'openid', 'OpenId', 'varchar(255) NULL', 'string', '', '', '0', '', '41', '0', '1', '1396688187', '1396688187', '', '3', '', 'regex', 'get_openid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('397', 'uid', '用户ID', 'int(10) NULL', 'num', '', '', '0', '', '41', '0', '1', '1396688042', '1396688042', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('398', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '41', '0', '1', '1396690911', '1396690911', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('399', 'title', '竞猜标题', 'varchar(255) NULL', 'string', '', '', '1', '', '42', '1', '1', '1428655010', '1428655010', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('400', 'desc', '活动说明', 'text NULL', 'textarea', '', '', '1', '', '42', '0', '1', '1428657017', '1428657017', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('401', 'start_time', '开始时间', 'int(10) NULL', 'datetime', '', '', '1', '', '42', '1', '1', '1428657086', '1428657086', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('402', 'end_time', '结束时间', 'int(10) NULL', 'datetime', '', '', '1', '', '42', '1', '1', '1428657122', '1428657122', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('403', 'create_time', '创建时间', 'int(10) NULL', 'datetime', '', '', '4', '', '42', '0', '1', '1428664508', '1428664122', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('404', 'guess_count', '', 'int(10) unsigned NULL ', 'num', '0', '', '4', '', '42', '0', '1', '1428718033', '1428717991', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('405', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '42', '0', '1', '1429521291', '1429512366', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('406', 'template', '素材模板', 'varchar(255) NULL', 'string', 'default', '', '1', '', '42', '0', '1', '1430115411', '1430103969', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('407', 'cover', '主题图片', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '42', '0', '1', '1430384839', '1430384839', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('408', 'user_id', '用户ID', 'int(10) unsigned NULL', 'num', '0', '', '0', '', '43', '0', '1', '1428738317', '1428738317', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('409', 'guess_id', '竞猜Id', 'int(10) unsigned NULL', 'num', '0', '', '0', '', '43', '0', '1', '1428738379', '1428738379', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('410', 'token', '用户token', 'varchar(255) NULL', 'string', '', '', '1', '', '43', '0', '1', '1428738405', '1428738405', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('411', 'optionIds', '用户猜的选项IDs', 'varchar(255) NULL', 'string', '', '', '0', '', '43', '0', '1', '1428738522', '1428738522', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('412', 'cTime', '创时间', 'int(10) NULL', 'date', '', '', '0', '', '43', '0', '1', '1428738552', '1428738552', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('413', 'guess_id', '竞猜活动的Id', 'int(10) NULL', 'num', '0', '', '4', '', '44', '0', '1', '1428659228', '1428659228', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('414', 'name', '选项名称', 'varchar(255) NULL', 'string', '', '', '1', '', '44', '1', '1', '1428659270', '1428659270', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('415', 'image', '选项图片', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '44', '0', '1', '1428659313', '1428659313', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('416', 'order', '选项顺序', 'int(10) NULL', 'num', '0', '', '1', '', '44', '0', '1', '1428659354', '1428659354', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('417', 'guess_count', '竞猜人数', 'int(10) unsigned NULL ', 'num', '0', '', '0', '', '44', '0', '1', '1430302786', '1428659432', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('418', 'keyword', '关键词', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '45', '1', '1', '1396624337', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('419', 'keyword_type', '关键词类型', 'tinyint(2) NOT NULL', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配', '45', '1', '1', '1396624426', '1396061765', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('420', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '45', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('421', 'intro', '封面简介', 'text NULL', 'textarea', '', '', '1', '', '45', '1', '1', '1447826199', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('422', 'mTime', '修改时间', 'int(10) NULL', 'datetime', '', '', '0', '', '45', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('423', 'cover', '封面图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '45', '1', '1', '1418266006', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('424', 'experience', '消耗经验值', 'int(10) NULL', 'num', '0', '', '1', '', '45', '0', '1', '1418180506', '1418180506', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('425', 'cTime', '发布时间', 'int(10) UNSIGNED NULL', 'datetime', '', '', '0', '', '45', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('426', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '45', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('427', 'num', '邀请人数', 'int(10) NULL', 'num', '0', '邀请多少人后才能用优惠券', '1', '', '45', '1', '1', '1447826376', '1418180590', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('428', 'coupon_id', '优惠券编号', 'int(10) NULL', 'num', '', '可以在优惠券列表中找到对应的编号', '1', '', '45', '1', '1', '1462358810', '1418180739', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('429', 'coupon_num', '优惠券数', 'int(10) NULL', 'num', '0', '赠送多少张优惠券', '0', '', '45', '0', '1', '1418959022', '1418180812', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('430', 'receive_num', '已领取优惠券数', 'int(10) NULL', 'num', '0', '', '0', '', '45', '0', '1', '1418181528', '1418181528', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('431', 'content', '邀约介绍', 'text NULL', 'editor', '', '', '1', '', '45', '1', '1', '1447826165', '1418265599', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('432', 'template', '模板名称', 'varchar(255) NULL', 'string', 'default', '', '1', '', '45', '0', '1', '1430122784', '1430122766', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('433', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '46', '0', '1', '1418192408', '1418192408', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('434', 'uid', '用户ID', 'int(10) NULL', 'num', '', '', '0', '', '46', '0', '1', '1418192629', '1418192629', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('435', 'invite_id', '邀约ID', 'int(10) NULL', 'num', '', '', '1', '', '46', '0', '1', '1418192878', '1418192878', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('436', 'invite_num', '已邀请人数', 'int(10) NULL', 'num', '', '', '0', '', '46', '0', '1', '1418192971', '1418192971', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('437', 'sports_id', '活动编号', 'int(10) NULL', 'num', '', '', '1', '', '47', '0', '1', '1432690590', '1432613794', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('438', 'award_id', '奖品编号', 'varchar(255) NULL', 'cascade', '', '', '1', '', '47', '0', '1', '1432710935', '1432613820', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('439', 'award_num', '奖品数量', 'int(10) NULL', 'num', '', '', '1', '', '47', '0', '1', '1432624743', '1432624743', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('440', 'uid', 'uid', 'int(10) NULL', 'num', '', '', '0', '', '47', '0', '1', '1435313078', '1435313078', '', '3', '', 'regex', 'get_mid', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('441', 'uid', 'uid', 'int(10) NULL', 'num', '', '', '0', '', '48', '0', '1', '1435313219', '1435313219', '', '3', '', 'regex', 'get_mid', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('442', 'draw_id', '活动编号', 'int(10) NULL', 'num', '', '', '1', '', '48', '0', '1', '1432619092', '1432618270', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('443', 'sport_id', '场次编号', 'int(10) NULL', 'num', '', '', '1', '', '48', '0', '1', '1432618305', '1432618305', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('444', 'award_id', '奖品编号', 'int(10) NULL', 'num', '', '', '1', '', '48', '0', '1', '1432618336', '1432618336', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('445', 'follow_id', '粉丝id', 'int(10) NULL', 'num', '', '', '1', '', '48', '0', '1', '1432618392', '1432618392', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('446', 'address', '地址', 'varchar(255) NULL', 'string', '', '', '1', '', '48', '0', '1', '1432618543', '1432618543', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('447', 'num', '获奖数', 'int(10) NULL', 'num', '0', '', '1', '', '48', '0', '1', '1432618584', '1432618584', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('448', 'state', '兑奖状态', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:未兑奖\r\n1:已兑奖', '48', '0', '1', '1432644421', '1432618716', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('449', 'zjtime', '中奖时间', 'int(10) NULL', 'datetime', '', '', '1', '', '48', '0', '1', '1432716949', '1432618837', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('450', 'djtime', '兑奖时间', 'int(10) NULL', 'datetime', '', '', '1', '', '48', '0', '1', '1432618922', '1432618922', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('451', 'title', '活动名称', 'varchar(255) NULL', 'string', '', '', '1', '', '49', '1', '1', '1435306559', '1435306559', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('452', 'remark', '活动描述', 'text NULL', 'textarea', '', '', '1', '', '49', '1', '1', '1435307454', '1435307126', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('453', 'logo_img', '活动LOGO', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '49', '1', '1', '1435307446', '1435307174', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('454', 'start_time', '开始时间', 'int(10) NULL', 'datetime', '', '', '1', '', '49', '1', '1', '1435310820', '1435307277', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('455', 'end_time', '结束时间', 'int(10) NULL', 'datetime', '', '', '1', '', '49', '1', '1', '1435310830', '1435307296', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('456', 'get_prize_tip', '中奖提示信息', 'varchar(255) NULL', 'string', '', '', '1', '', '49', '1', '1', '1435307421', '1435307411', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('457', 'no_prize_tip', '未中奖提示信息', 'varchar(255) NULL', 'string', '', '', '1', '', '49', '1', '1', '1435307517', '1435307517', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('458', 'ctime', '活动创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '49', '0', '1', '1435307577', '1435307577', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('459', 'uid', 'uid', 'int(10) NULL', 'num', '', '', '0', '', '49', '0', '1', '1435307671', '1435307671', '', '3', '', 'regex', 'get_mid', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('460', 'lottery_number', '抽奖次数', 'int(10) NULL', 'num', '1', '每日允许用户抽奖的机会数，小于0 为无限次', '1', '', '49', '0', '1', '1436233580', '1435585561', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('461', 'comment_status', '评论是否需要审核', 'char(10) NULL', 'radio', '0', '', '1', '0:不审核\r\n1:审核', '49', '0', '1', '1436155693', '1435665821', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('462', 'get_prize_count', '中奖次数', 'int(10) NULL', 'num', '1', '每用户是否允许多次中奖', '1', '', '49', '0', '1', '1436181974', '1436181850', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('463', 'lzwg_id', '活动编号', 'int(10) NULL', 'num', '', '', '1', '', '50', '0', '1', '1435734910', '1435734886', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('464', 'lzwg_type', '活动类型', 'char(10) NULL', 'radio', '0', '', '1', '0:投票\r\n1:调查', '50', '0', '1', '1435734977', '1435734977', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('465', 'vote_id', '题目编号', 'int(10) NULL', 'num', '', '', '1', '', '50', '0', '1', '1435735047', '1435735047', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('466', 'vote_type', '问题类型', 'char(10) NULL', 'radio', '1', '', '1', '0:单选\r\n1:多选', '50', '0', '1', '1435735092', '1435735092', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('467', 'vote_limit', '最多选择几项', 'int(10) NULL', 'num', '', '', '1', '', '50', '0', '1', '1435735172', '1435735172', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('518', 'from', '回调地址', 'varchar(50) NOT NULL', 'string', '', '', '1', '', '60', '0', '1', '1420596347', '1420596347', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('519', 'orderName', '订单名称', 'varchar(255) NULL', 'string', '', '', '1', '', '60', '0', '1', '1439976366', '1420596373', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('520', 'single_orderid', '订单号', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '60', '0', '1', '1420596415', '1420596415', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('521', 'price', '价格', 'decimal(10,2) NULL', 'num', '', '', '1', '', '60', '0', '1', '1439812508', '1420596472', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('522', 'token', 'Token', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '60', '0', '1', '1420596492', '1420596492', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('523', 'wecha_id', 'OpenID', 'varchar(200) NOT NULL', 'string', '', '', '1', '', '60', '0', '1', '1420596530', '1420596530', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('524', 'paytype', '支付方式', 'varchar(30) NOT NULL', 'string', '', '', '1', '', '60', '0', '1', '1420596929', '1420596929', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('525', 'showwxpaytitle', '是否显示标题', 'tinyint(2) NOT NULL', 'bool', '0', '', '1', '0:不显示\r\n1:显示', '60', '0', '1', '1420596980', '1420596980', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('526', 'status', '支付状态', 'tinyint(2) NOT NULL', 'bool', '0', '', '1', '0:未支付\r\n1:已支付\r\n2:支付失败', '60', '0', '1', '1420597026', '1420597026', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('527', 'wxmchid', '微信支付商户号', 'varchar(255) NULL', 'string', '', '', '1', '', '61', '1', '1', '1439364696', '1436437067', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('528', 'shop_id', '商店ID', 'int(10) NULL', 'num', '0', '', '0', '', '61', '0', '1', '1436437020', '1436437003', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('529', 'quick_merid', '银联在线merid', 'varchar(255) NULL', 'string', '', '', '1', '', '61', '0', '1', '1436436949', '1436436949', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('530', 'quick_merabbr', '商户名称', 'varchar(255) NULL', 'string', '', '', '1', '', '61', '0', '1', '1436436970', '1436436970', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('531', 'wxpartnerid', '微信partnerid', 'varchar(255) NULL', 'string', '', '', '0', '', '61', '0', '1', '1436437196', '1436436910', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('532', 'wxpartnerkey', '微信partnerkey', 'varchar(255) NULL', 'string', '', '', '0', '', '61', '0', '1', '1436437236', '1436436888', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('533', 'partnerid', '财付通标识', 'varchar(255) NULL', 'string', '', '', '1', '', '61', '0', '1', '1436436798', '1436436798', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('534', 'key', 'KEY', 'varchar(255) NULL', 'string', '', '', '1', '', '61', '0', '1', '1436436771', '1436436771', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('535', 'ctime', '创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '61', '0', '1', '1436436498', '1436436498', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('536', 'quick_security_key', '银联在线Key', 'varchar(255) NULL', 'string', '', '', '1', '', '61', '0', '1', '1436436931', '1436436931', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('537', 'wappartnerkey', 'WAP财付通Key', 'varchar(255) NULL', 'string', '', '', '1', '', '61', '0', '1', '1436436863', '1436436863', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('538', 'wappartnerid', '财付通标识WAP', 'varchar(255) NULL', 'string', '', '', '1', '', '61', '0', '1', '1436436834', '1436436834', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('539', 'partnerkey', '财付通Key', 'varchar(255) NULL', 'string', '', '', '1', '', '61', '0', '1', '1436436816', '1436436816', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('540', 'pid', 'PID', 'varchar(255) NULL', 'string', '', '', '1', '', '61', '0', '1', '1436436707', '1436436707', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('541', 'zfbname', '帐号', 'varchar(255) NULL', 'string', '', '', '1', '', '61', '0', '1', '1436436653', '1436436653', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('542', 'wxappsecret', 'AppSecret', 'varchar(255) NULL', 'string', '', '微信支付中的公众号应用密钥', '1', '', '61', '1', '1', '1439364612', '1436436618', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('543', 'wxpaysignkey', '支付密钥', 'varchar(255) NULL', 'string', '', 'PartnerKey', '1', '', '61', '1', '1', '1439364810', '1436436569', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('544', 'wxappid', 'AppID', 'varchar(255) NULL', 'string', '', '微信支付中的公众号应用ID', '1', '', '61', '1', '1', '1439364573', '1436436534', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('545', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '0', '', '61', '0', '1', '1436436415', '1436436415', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('546', 'wx_cert_pem', '上传证书', 'int(10) UNSIGNED NULL', 'file', '', 'apiclient_cert.pem', '1', '', '61', '0', '1', '1439804529', '1439550487', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('555', 'address', '奖品收货地址', 'varchar(255) NULL', 'textarea', '', '', '1', '', '63', '1', '1', '1429857152', '1429521685', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('556', 'mobile', '手机', 'varchar(50) NULL', 'string', '', '', '1', '', '63', '1', '1', '1429521877', '1429521877', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('557', 'turename', '收货人姓名', 'varchar(255) NULL', 'string', '', '', '1', '', '63', '1', '1', '1429672245', '1429521930', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('558', 'uid', '用户id', 'int(10) NULL', 'num', '', '', '0', '', '63', '0', '1', '1429673948', '1429522086', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('559', 'remark', '备注', 'varchar(255) NULL', 'string', '', '', '1', '', '63', '0', '1', '1429598446', '1429598446', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('560', 'prizeid', '奖品编号', 'int(10) NULL', 'num', '', '', '4', '', '63', '0', '1', '1447832021', '1429607543', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('561', 'prize_name', '奖品名称', 'varchar(255) NULL', 'string', '', '', '1', '', '64', '1', '1', '1429515512', '1429515512', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('562', 'prize_conditions', '活动说明', 'text NULL', 'textarea', '', '奖品说明', '1', '', '64', '1', '1', '1429756762', '1429516052', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('563', 'prize_count', '奖品个数', 'int(10) NULL', 'num', '', '', '1', '', '64', '1', '1', '1429779465', '1429516109', '/^[0-9]*$/', '3', '奖品个数不能小于0', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('564', 'prize_image', '奖品图片', 'varchar(255) NULL', 'picture', '上传奖品图片', '', '1', '', '64', '1', '1', '1429756675', '1429516329', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('565', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '0', '', '64', '0', '1', '1429521039', '1429521039', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('566', 'fail_content', '领取失败提示', 'text NULL', 'textarea', '', '用户领取失败，或者没有领取到时看到的提示', '1', '', '64', '1', '1', '1429860149', '1429860149', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('567', 'prize_type', '奖品类型', 'tinyint(2) NULL', 'radio', '1', '选择奖品类型', '1', '1:实物\r\n0:虚拟', '64', '1', '1', '1429756998', '1429756539', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('568', 'use_content', '使用说明', 'text NULL', 'textarea', '', '用户领取成功后才会看到', '1', '', '64', '1', '1', '1429757185', '1429757185', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('569', 'prize_title', '活动标题', 'varchar(255) NULL', 'string', '', '', '1', '', '64', '1', '1', '1429855569', '1429855569', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('570', 'template', '素材模板', 'varchar(255) NULL', 'string', 'default', '', '1', '', '64', '0', '1', '1430132994', '1430132994', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('571', 'token', 'token', 'varchar(50) NULL', 'string', '', '', '1', '', '65', '0', '1', '1430999098', '1430999079', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('572', 'uid', 'uid', 'int(10) NULL', 'num', '', '', '1', '', '65', '0', '1', '1430999121', '1430999121', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('573', 'mch_id', '商户号', 'varchar(32) NULL', 'string', '', '微信支付分配的商户号', '1', '', '65', '1', '1', '1427702346', '1427702346', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('574', 'sub_mch_id', '子商户号', 'varchar(32) NULL', 'string', '', '可为空，微信支付分配的子商户号，受理模式下必填', '0', '', '65', '0', '1', '1427785321', '1427702397', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('575', 'wxappid', '公众账号appid', 'varchar(32) NULL', 'string', '', '商户appid', '1', '', '65', '1', '1', '1427702433', '1427702433', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('576', 'nick_name', '提供方名称', 'varchar(32) NULL', 'string', '', '', '1', '', '65', '1', '1', '1427702473', '1427702473', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('577', 'send_name', '商户名称', 'varchar(32) NULL', 'string', '', '红包发送者名称', '1', '', '65', '1', '1', '1427702505', '1427702505', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('578', 'total_amount', '付款金额', 'int(10) NULL', 'num', '1000', '付款金额，单位分', '1', '', '65', '1', '1', '1427702603', '1427702603', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('579', 'min_value', '最小红包金额', 'int(10) NULL', 'num', '1000', '最小红包金额，单位分', '1', '', '65', '1', '1', '1427702653', '1427702653', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('580', 'max_value', '最大红包金额', 'int(10) NULL', 'num', '1000', '最大红包金额，单位分', '1', '', '65', '1', '1', '1427702703', '1427702703', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('581', 'total_num', '红包发放总人数', 'int(10) NULL', 'num', '1', '', '1', '', '65', '1', '1', '1427702757', '1427702757', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('582', 'wishing', '红包祝福语', 'varchar(255) NULL', 'string', '', '如：感谢您参加猜灯谜活动，祝您元宵节快乐！', '1', '', '65', '1', '1', '1427702843', '1427702843', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('583', 'act_name', '活动名称', 'varchar(255) NULL', 'string', '', '如：猜灯谜抢红包活动', '1', '', '65', '1', '1', '1427702920', '1427702920', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('584', 'remark', '备注', 'varchar(255) NULL', 'string', '', '如：猜越多得越多，快来抢！', '1', '', '65', '1', '1', '1427703037', '1427703011', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('585', 'logo_imgurl', '商户logo的url', 'int(10) UNSIGNED NULL', 'picture', '', '', '0', '', '65', '0', '1', '1427785307', '1427703083', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('586', 'share_content', '分享文案', 'varchar(255) NULL', 'string', '', '如：快来参加猜灯谜活动', '0', '', '65', '0', '1', '1427785298', '1427703125', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('587', 'share_url', '分享链接', 'varchar(255) NULL', 'string', '', '', '0', '', '65', '0', '1', '1427785292', '1427703167', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('588', 'share_imgurl', '分享的图片', 'int(10) UNSIGNED NULL', 'picture', '', '', '0', '', '65', '0', '1', '1427785285', '1427703301', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('589', 'collect_count', '领取人数', 'int(10) NULL', 'num', '0', '', '0', '', '65', '0', '1', '1427785218', '1427785211', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('590', 'collect_amount', '已领取金额', 'int(10) NULL', 'num', '0', '单位为分', '0', '', '65', '0', '1', '1427785274', '1427785262', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('591', 'collect_limit', '每人最多领取次数', 'tinyint(2) NULL', 'num', '0', '0 表示不限制', '1', '', '65', '0', '1', '1427786937', '1427786937', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('592', 'partner_key', '商户API密钥', 'varchar(50) NULL', 'string', '', '用户生成支付签名', '1', '', '65', '0', '1', '1427850414', '1427850414', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('593', 'template', '素材模板', 'varchar(255) NULL', 'string', 'default', '', '1', '', '65', '0', '1', '1430132068', '1430132068', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('594', 'redbag_id', '红包ID', 'int(10) NULL', 'num', '', '', '1', '', '66', '0', '1', '1427703408', '1427703408', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('595', 'follow_id', '粉丝ID', 'int(10) NULL', 'num', '', '', '1', '', '66', '0', '1', '1427703457', '1427703457', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('596', 'amount', '领取金额', 'int(10) NULL', 'num', '0', '单位为分', '1', '', '66', '0', '1', '1427703546', '1427703546', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('597', 'cTime', '领取时间', 'int(10) NULL', 'num', '', '', '1', '', '66', '0', '1', '1427703593', '1427703593', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('723', 'sn', 'SN码', 'varchar(255) NULL', 'string', '', '', '0', '', '81', '0', '1', '1399272236', '1399272228', '', '3', '', 'regex', 'uniqid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('724', 'uid', '粉丝UID', 'int(10) NULL', 'num', '', '', '0', '', '81', '0', '1', '1399772738', '1399272401', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('725', 'cTime', '创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '81', '0', '1', '1399272456', '1399272456', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('726', 'is_use', '是否已使用', 'tinyint(2) NULL', 'bool', '0', '', '0', '0:未使用\r\n1:已使用', '81', '0', '1', '1400601159', '1399272514', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('727', 'use_time', '使用时间', 'int(10) NULL', 'datetime', '', '', '0', '', '81', '0', '1', '1399272560', '1399272537', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('728', 'addon', '来自的插件', 'varchar(255) NULL', 'string', 'Coupon', '', '4', '', '81', '0', '1', '1399272651', '1399272651', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('729', 'target_id', '来源ID', 'int(10) unsigned NULL ', 'num', '', '', '4', '', '81', '0', '1', '1399272705', '1399272705', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('730', 'prize_id', '奖项ID', 'int(10) unsigned NULL ', 'num', '', '', '0', '', '81', '0', '1', '1399686317', '1399686317', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('731', 'prize_title', '奖项', 'varchar(255) NULL', 'string', '', '', '1', '', '81', '0', '1', '1399790367', '1399790367', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('732', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '81', '0', '1', '1404525481', '1404525481', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('733', 'can_use', '是否可用', 'tinyint(2) NULL', 'bool', '1', '', '0', '0:不可用\r\n1:可用', '81', '0', '1', '1418890020', '1418890020', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('734', 'server_addr', '服务器IP', 'varchar(50) NULL', 'string', '', '', '1', '', '81', '0', '1', '1425807865', '1425807865', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('735', 'img', '奖品图片', 'int(10) NOT NULL', 'picture', '', '', '1', '', '82', '1', '1', '1432609211', '1432607410', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('736', 'name', '奖项名称', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '82', '1', '1', '1432621511', '1432607270', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('737', 'score', '积分数', 'int(10) NULL', 'num', '0', '虚拟奖品积分奖励', '1', '', '82', '1', '1', '1433312545', '1433304974', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('738', 'award_type', '奖品类型', 'varchar(30) NULL', 'select', '1', '选择奖品类别', '1', '1:实物奖品|price@show,score@hide,coupon_id@hide,money@hide\r\n0:虚拟奖品|price@hide,score@show,coupon_id@hide,money@hide\r\n2:优惠券|price@hide,score@hide,coupon_id@show,money@hide', '82', '1', '1', '1464712807', '1433303130', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('739', 'price', '商品价格', 'FLOAT(10) NULL', 'num', '0', '价格默认为0，表示未报价', '1', '', '82', '0', '1', '1433312127', '1432607574', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('740', 'explain', '奖品说明', 'text NULL', 'textarea', '', '', '1', '', '82', '0', '1', '1432621815', '1432607605', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('741', 'count', '奖品数量', 'int(10) NOT NULL', 'num', '', '', '1', '', '82', '1', '1', '1447833730', '1432607983', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('742', 'sort', '排序号', 'int(10) unsigned NULL ', 'num', '0', '', '0', '', '82', '0', '1', '1432809831', '1432608522', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('743', 'uid', 'uid', 'int(10) NULL', 'num', '', '', '0', '', '82', '0', '1', '1435308540', '1435308540', '', '3', '', 'regex', 'get_mid', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('744', 'score', '比分', 'varchar(30) NULL', 'string', '', '输入格式：4:1', '1', '', '83', '0', '1', '1432781750', '1432556644', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('745', 'content', '说明', 'text NULL', 'textarea', '', '请输入说明', '1', '', '83', '0', '1', '1432556696', '1432556696', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('746', 'start_time', '时间', 'int(10) NULL', 'datetime', '', '', '1', '', '83', '1', '1', '1432556499', '1432556499', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('747', 'visit_team', '客场球队', 'varchar(255) NULL', 'cascade', '', '', '1', 'type=db&table=sports_team', '83', '1', '1', '1432558295', '1432556450', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('748', 'home_team', '主场球队', 'varchar(255) NULL', 'cascade', '', '', '1', 'type=db&table=sports_team', '83', '1', '1', '1432558269', '1432556380', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('749', 'countdown', '擂鼓时长', 'int(10) NULL', 'num', '60', '擂鼓倒计的时长,单位为秒,取值范围: 10~99', '1', '', '83', '0', '1', '1432645901', '1432642097', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('750', 'drum_count', '擂鼓次数', 'int(10) NULL', 'num', '0', '', '0', '', '83', '0', '1', '1432642664', '1432642664', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('751', 'drum_follow_count', '擂鼓人数', 'int(10) NULL', 'num', '0', '', '0', '', '83', '0', '1', '1432642718', '1432642718', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('752', 'home_team_support_count', '主场球队支持数', 'int(10) NULL', 'num', '0', '', '0', '', '83', '0', '1', '1432642808', '1432642808', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('753', 'visit_team_support_count', '客场球队支持人数', 'int(10) NULL', 'num', '0', '', '0', '', '83', '0', '1', '1432642849', '1432642849', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('754', 'home_team_drum_count', '主场球队擂鼓数', 'int(10) NULL', 'num', '0', '', '0', '', '83', '0', '1', '1432642978', '1432642978', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('755', 'visit_team_drum_count', '客场球队擂鼓数', 'int(10) NULL', 'num', '0', '', '0', '', '83', '0', '1', '1432644311', '1432643015', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('756', 'yaotv_count', '摇一摇总次', 'int(10) NULL', 'num', '0', '', '0', '', '83', '0', '1', '1432884957', '1432784354', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('757', 'draw_count', '抽奖总次数', 'int(10) NULL', 'num', '0', '', '0', '', '83', '0', '1', '1432887571', '1432784416', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('758', 'is_finish', '是否已结束', 'tinyint(2) NULL', 'bool', '0', '', '0', '0:未结束\r\n1:已结束', '83', '0', '1', '1432868975', '1432868975', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('759', 'yaotv_follow_count', '摇电视总人数', 'int(10) NULL', 'num', '0', '', '0', '', '83', '0', '1', '1432884721', '1432884721', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('760', 'draw_follow_count', '抽奖总人数', 'int(10) NULL', 'num', '0', '', '0', '', '83', '0', '1', '1432887553', '1432887553', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('761', 'comment_status', '评论是否需要审核', 'tinyint(2) NULL', 'radio', '0', '', '1', '0:不审核\r\n1:审核', '83', '0', '1', '1435109668', '1435030411', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('762', 'sports_id', '场次ID', 'int(10) NULL', 'num', '', '', '0', '', '84', '0', '1', '1432642290', '1432642290', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('763', 'team_id', '球队ID', 'int(10) NULL', 'num', '', '', '0', '', '84', '0', '1', '1432642312', '1432642312', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('764', 'follow_id', '用户ID', 'int(10) NULL', 'num', '', '', '0', '', '84', '0', '1', '1432642354', '1432642354', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('765', 'drum_count', '擂鼓次数', 'int(10) NULL', 'num', '', '', '0', '', '84', '0', '1', '1432642384', '1432642384', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('766', 'cTime', '时间', 'int(10) NULL', 'datetime', '', '', '0', '', '84', '0', '1', '1432642409', '1432642409', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('767', 'sports_id', '场次ID', 'int(10) NULL', 'num', '', '', '0', '', '85', '0', '1', '1432635120', '1432635120', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('768', 'team_id', '球队ID', 'int(10) NULL', 'num', '', '', '0', '', '85', '0', '1', '1432635147', '1432635147', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('769', 'follow_id', '用户ID', 'int(10) NULL', 'num', '', '', '0', '', '85', '0', '1', '1432635168', '1432635168', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('770', 'cTime', '支持时间', 'int(10) NULL', 'datetime', '', '', '0', '', '85', '0', '1', '1432635202', '1432635202', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('771', 'sort', '排序号', 'int(10) NULL', 'num', '0', '', '0', '', '86', '0', '1', '1432559360', '1432559360', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('772', 'intro', '球队说明', 'text  NULL', 'textarea', '', '', '1', '', '86', '0', '1', '1432557159', '1432556960', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('773', 'pid', 'pid', 'int(10) NULL', 'num', '0', '', '0', '', '86', '0', '1', '1432557085', '1432557085', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('774', 'logo', '球队图标', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '86', '1', '1', '1432556913', '1432556913', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('775', 'title', '球队名称', 'varchar(100) NULL', 'string', '', '请输入球队名称', '1', '', '86', '1', '1', '1432958716', '1432556869', 'unique', '3', '球队名称不能重复', 'unique', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('776', 'title', '应用标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '87', '1', '1', '1402758132', '1394033402', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('777', 'uid', '用户ID', 'int(10) NULL ', 'num', '0', '', '0', '', '87', '0', '1', '1394087733', '1394033447', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('778', 'content', '应用详细介绍', 'text NULL ', 'editor', '', '', '1', '', '87', '1', '1', '1402758118', '1394033484', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('779', 'cTime', '发布时间', 'int(10) NULL ', 'datetime', '', '', '0', '', '87', '0', '1', '1394033571', '1394033571', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('780', 'attach', '应用压缩包', 'varchar(255) NULL ', 'file', '', '需要上传zip文件', '1', '', '87', '0', '1', '1402758100', '1394033674', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('781', 'is_top', '置顶', 'int(10) NULL ', 'bool', '0', '0表示不置顶，否则其它值表示置顶且值是置顶的时间', '1', '0:不置顶\r\n1:置顶', '87', '0', '1', '1402800009', '1394068787', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('782', 'cid', '分类', 'tinyint(4) NULL ', 'select', '', '', '0', '1:基础模块\r\n2:行业模块\r\n3:会议活动\r\n4:娱乐模块\r\n5:其它模块', '87', '0', '1', '1402758069', '1394069964', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('783', 'view_count', '浏览数', 'int(11) unsigned NULL ', 'num', '0', '', '0', '', '87', '0', '1', '1394072168', '1394072168', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('784', 'download_count', '下载数', 'int(10) unsigned NULL ', 'num', '0', '', '0', '', '87', '0', '1', '1394085763', '1394085763', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('785', 'img_2', '应用截图2', 'int(10) unsigned NULL ', 'picture', '', '', '1', '', '87', '0', '1', '1402758035', '1394084714', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('786', 'img_1', '应用截图1', 'int(10) unsigned NULL ', 'picture', '', '', '1', '', '87', '0', '1', '1402758046', '1394084635', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('787', 'img_3', '应用截图3', 'int(10) unsigned NULL ', 'picture', '', '', '1', '', '87', '0', '1', '1402758021', '1394084757', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('788', 'img_4', '应用截图4', 'int(10) unsigned NULL ', 'picture', '', '', '1', '', '87', '0', '1', '1402758011', '1394084797', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('789', 'uid', 'uid', 'int(10) NULL', 'num', '', '', '1', '', '88', '0', '1', '1430880974', '1430880974', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('790', 'name', '素材名称', 'varchar(100) NULL', 'string', '', '', '1', '', '88', '0', '1', '1424612322', '1424611929', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('791', 'status', '状态', 'char(10) NULL', 'radio', 'UnSubmit', '', '1', 'UnSubmit:未提交\r\nWaiting:入库中\r\nSuccess:入库成功\r\nFailure:入库失败', '88', '0', '1', '1424612039', '1424612039', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('792', 'cTime', '提交时间', 'int(10) NULL', 'datetime', '', '', '1', '', '88', '0', '1', '1424612114', '1424612114', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('793', 'url', '实际摇一摇所使用的页面URL', 'varchar(255) NULL', 'string', '', '', '1', '', '88', '0', '1', '1424612483', '1424612154', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('794', 'type', '素材类型', 'varchar(255) NULL', 'string', '', '', '1', '', '88', '0', '1', '1424612421', '1424612421', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('795', 'detail', '素材内容', 'text NULL', 'textarea', '', '', '1', '', '88', '0', '1', '1424612456', '1424612456', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('796', 'reason', '入库失败的原因', 'text NULL', 'textarea', '', '', '1', '', '88', '0', '1', '1424612509', '1424612509', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('797', 'create_time', '申请时间', 'int(10) NULL', 'datetime', '', '', '1', '', '88', '0', '1', '1424612542', '1424612542', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('798', 'checked_time', '入库时间', 'int(10) NULL', 'datetime', '', '', '1', '', '88', '0', '1', '1424612571', '1424612571', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('799', 'source', '来源', 'varchar(50) NULL', 'string', '', '', '1', '', '88', '0', '1', '1424836818', '1424836818', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('800', 'source_id', '来源ID', 'int(10) NULL', 'num', '', '', '1', '', '88', '0', '1', '1424836842', '1424836842', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('801', 'wechat_id', '微信端的素材ID', 'int(10) NULL', 'num', '', '', '0', '', '88', '0', '1', '1425370605', '1425370605', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('802', 'uid', '管理员id', 'int(10) NULL', 'num', '', '', '1', '', '89', '0', '1', '1431575588', '1431575588', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('803', 'token', '用户token', 'varchar(255) NULL', 'string', '', '', '1', '', '89', '0', '1', '1431575617', '1431575617', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('804', 'addons', '插件名称', 'varchar(255) NULL', 'string', '', '', '1', '', '89', '0', '1', '1431590322', '1431575667', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('805', 'template', '模版名称', 'varchar(255) NULL', 'string', '', '', '1', '', '89', '0', '1', '1431575691', '1431575691', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('806', 'keyword', '关键词', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '90', '1', '1', '1396624337', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('807', 'keyword_type', '关键词类型', 'tinyint(2) NOT NULL', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配\r\n4:正则匹配\r\n5:随机匹配', '90', '1', '1', '1396624426', '1396061765', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('808', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '90', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('809', 'intro', '封面简介', 'text NULL', 'textarea', '', '', '1', '', '90', '0', '1', '1396624505', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('810', 'mTime', '修改时间', 'int(10) NULL', 'datetime', '', '', '0', '', '90', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('811', 'cover', '封面图片', 'int(10) unsigned NULL ', 'picture', '', '', '1', '', '90', '1', '1', '1439368240', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('812', 'cTime', '发布时间', 'int(10) unsigned NULL ', 'datetime', '', '', '0', '', '90', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('813', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '90', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('814', 'finish_tip', '结束语', 'text NULL', 'string', '', '为空默认为：调研完成，谢谢参与', '1', '', '90', '0', '1', '1447640072', '1396953940', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('815', 'template', '素材模板', 'varchar(255) NULL', 'string', 'default', '', '1', '', '90', '0', '1', '1430193696', '1430193696', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('816', 'answer', '回答内容', 'text NULL', 'textarea', '', '', '0', '', '91', '0', '1', '1396955766', '1396955766', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('817', 'openid', 'OpenId', 'varchar(255) NULL', 'string', '', '', '0', '', '91', '0', '1', '1396955581', '1396955581', '', '3', '', 'regex', 'get_openid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('818', 'uid', '用户UID', 'int(10) NULL ', 'num', '', '', '0', '', '91', '0', '1', '1396955530', '1396955530', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('819', 'question_id', 'question_id', 'int(10) unsigned NOT NULL ', 'num', '', '', '4', '', '91', '1', '1', '1396955412', '1396955392', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('820', 'cTime', '发布时间', 'int(10) unsigned NULL ', 'datetime', '', '', '0', '', '91', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('821', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '91', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('822', 'survey_id', 'survey_id', 'int(10) unsigned NOT NULL ', 'num', '', '', '4', '', '91', '1', '1', '1396955403', '1396955369', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('823', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '92', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('824', 'intro', '问题描述', 'text NULL', 'textarea', '', '', '1', '', '92', '0', '1', '1396954176', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('825', 'cTime', '发布时间', 'int(10) unsigned NULL ', 'datetime', '', '', '0', '', '92', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('826', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '92', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('827', 'is_must', '是否必填', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:否\r\n1:是', '92', '0', '1', '1396954649', '1396954649', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('828', 'extra', '参数', 'text NULL', 'textarea', '', '类型为单选、多选时的定义数据，格式见上面的提示', '1', '', '92', '0', '1', '1396954558', '1396954558', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('829', 'type', '问题类型', 'char(50) NOT NULL', 'radio', 'radio', '', '1', 'radio:单选题\r\ncheckbox:多选题\r\ntextarea:简答题', '92', '1', '1', '1396962517', '1396954463', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('830', 'survey_id', 'survey_id', 'int(10) unsigned NOT NULL ', 'num', '', '', '4', '', '92', '1', '1', '1396954240', '1396954240', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('831', 'sort', '排序号', 'int(10) unsigned NULL ', 'num', '0', '值越小越靠前', '1', '', '92', '0', '1', '1396955010', '1396955010', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('832', 'title', '公告标题', 'varchar(255) NULL', 'string', '', '', '1', '', '93', '1', '1', '1431143985', '1431143985', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('833', 'content', '公告内容', 'text  NULL', 'editor', '', '', '1', '', '93', '1', '1', '1431144020', '1431144020', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('834', 'create_time', '发布时间', 'int(10) NULL', 'datetime', '', '', '4', '', '93', '0', '1', '1431146373', '1431144069', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('835', 'version', '版本号', 'int(10) unsigned NOT NULL ', 'num', '', '', '1', '', '94', '1', '1', '1393770457', '1393770457', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('836', 'title', '升级包名', 'varchar(50) NOT NULL', 'string', '', '', '1', '', '94', '1', '1', '1393770499', '1393770499', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('837', 'description', '描述', 'text NULL', 'textarea', '', '', '1', '', '94', '0', '1', '1393770546', '1393770546', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('838', 'create_date', '创建时间', 'int(10) NULL', 'datetime', '', '', '1', '', '94', '0', '1', '1393770591', '1393770591', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('839', 'download_count', '下载统计', 'int(10) unsigned NULL ', 'num', '0', '', '0', '', '94', '0', '1', '1393770659', '1393770659', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('840', 'package', '升级包地址', 'varchar(255) NOT NULL', 'textarea', '', '', '1', '', '94', '1', '1', '1393812247', '1393770727', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('841', 'keyword', '关键词', 'varchar(50) NOT NULL', 'string', '', '用户在微信里回复此关键词将会触发此投票。', '1', '', '95', '1', '1', '1392969972', '1388930888', 'keyword_unique', '1', '此关键词已经存在，请换成别的关键词再试试', 'function', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('842', 'title', '投票标题', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '95', '1', '1', '1388931041', '1388931041', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('843', 'description', '投票描述', 'text NULL', 'textarea', '', '', '1', '', '95', '0', '1', '1400633517', '1388931173', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('844', 'picurl', '封面图片', 'int(10) unsigned NULL ', 'picture', '', '支持JPG、PNG格式，较好的效果为大图360*200，小图200*200', '1', '', '95', '0', '1', '1463541141', '1388931285', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('845', 'type', '选择类型', 'char(10) NOT NULL', 'radio', '0', '', '0', '0:单选\r\n1:多选', '95', '0', '1', '1462357306', '1388931487', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('846', 'start_date', '开始日期', 'int(10) NULL', 'datetime', '', '', '1', '', '95', '0', '1', '1388931734', '1388931734', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('847', 'end_date', '结束日期', 'int(10) NULL', 'datetime', '', '', '1', '', '95', '0', '1', '1388931769', '1388931769', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('848', 'is_img', '文字/图片投票', 'tinyint(2) NULL', 'radio', '0', '', '0', '0:文字投票\r\n1:图片投票', '95', '1', '1', '1389081985', '1388931941', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('849', 'vote_count', '投票数', 'int(10) unsigned NULL ', 'num', '0', '', '0', '', '95', '0', '1', '1388932035', '1388932035', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('850', 'cTime', '投票创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '95', '1', '1', '1388932128', '1388932128', '', '1', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('851', 'mTime', '更新时间', 'int(10) NULL', 'datetime', '', '', '0', '', '95', '0', '1', '1430379170', '1390634006', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('852', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '95', '0', '1', '1391397388', '1391397388', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('853', 'template', '素材模板', 'varchar(255) NULL', 'string', 'default', '', '1', '', '95', '0', '1', '1430188739', '1430188739', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('854', 'vote_id', '投票ID', 'int(10) unsigned NULL ', 'num', '', '', '1', '', '96', '1', '1', '1429846753', '1388934189', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('855', 'user_id', '用户ID', 'int(10) NULL ', 'num', '', '', '1', '', '96', '1', '1', '1429855665', '1388934265', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('856', 'token', '用户TOKEN', 'varchar(255) NULL', 'string', '', '', '0', '', '96', '1', '1', '1429855713', '1388934296', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('857', 'options', '选择选项', 'varchar(255) NULL', 'string', '', '', '1', '', '96', '1', '1', '1429855086', '1388934351', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('858', 'cTime', '创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '96', '0', '1', '1429874378', '1388934392', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1059', 'order', '选项排序', 'int(10) unsigned NULL ', 'num', '0', '', '1', '', '123', '0', '1', '1388933951', '1388933951', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1058', 'opt_count', '当前选项投票数', 'int(10) unsigned NULL ', 'num', '0', '', '1', '', '123', '0', '1', '1429861248', '1388933860', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1057', 'image', '图片选项', 'int(10) unsigned NULL ', 'picture', '', '', '5', '', '123', '0', '1', '1388984467', '1388933679', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1056', 'name', '选项标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '123', '1', '1', '1388933552', '1388933552', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1055', 'vote_id', '投票ID', 'int(10) unsigned NOT NULL ', 'num', '', '', '4', '', '123', '1', '1', '1388982678', '1388933478', '', '3', '', 'regex', '$_REQUEST[\'vote_id\']', '3', 'string');
INSERT INTO `wp_attribute` VALUES ('867', 'title', '分类标题', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '99', '1', '1', '1408950771', '1395988016', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('868', 'icon', '分类图片', 'int(10) unsigned NULL ', 'picture', '', '', '1', '', '99', '0', '1', '1395988966', '1395988966', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('869', 'url', '外链', 'varchar(255) NULL', 'string', '', '为空时默认跳转到该分类的文章列表页面', '1', '', '99', '0', '1', '1401408363', '1395989660', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('870', 'is_show', '显示', 'tinyint(2) NULL', 'bool', '1', '', '1', '0:不显示\r\n1:显示', '99', '0', '1', '1464704467', '1395989709', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('871', 'token', 'Token', 'varchar(100) NULL ', 'string', '', '', '0', '', '99', '0', '1', '1395989760', '1395989760', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('872', 'sort', '排序号', 'int(10) NULL ', 'num', '0', '数值越小越靠前', '1', '', '99', '0', '1', '1396340334', '1396340334', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('873', 'pid', '一级目录', 'int(10) NULL', 'cascade', '0', '', '1', 'type=db&table=weisite_category&pid=id', '99', '0', '1', '1439522271', '1439469294', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('874', 'keyword', '关键词', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '100', '1', '1', '1396061575', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('875', 'keyword_type', '关键词类型', 'tinyint(2) NULL', 'select', '', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配\r\n4:正则匹配\r\n5:随机匹配', '100', '0', '1', '1396061814', '1396061765', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('876', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '100', '1', '1', '1396061877', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('877', 'intro', '简介', 'text NULL', 'textarea', '', '', '1', '', '100', '0', '1', '1396061947', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('878', 'cate_id', '所属类别', 'int(10) unsigned NULL ', 'select', '0', '要先在微官网分类里配置好分类才可选择', '1', '0:请选择分类', '100', '0', '1', '1396078914', '1396062003', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('879', 'cover', '封面图片', 'int(10) unsigned NULL ', 'picture', '', '', '1', '', '100', '0', '1', '1396062093', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('880', 'content', '内容', 'text NULL', 'editor', '', '', '1', '', '100', '0', '1', '1396062146', '1396062146', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('881', 'cTime', '发布时间', 'int(10) NULL', 'datetime', '', '', '0', '', '100', '0', '1', '1396075102', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('882', 'sort', '排序号', 'int(10) unsigned NULL ', 'num', '0', '数值越小越靠前', '1', '', '100', '0', '1', '1396510508', '1396510508', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('883', 'view_count', '浏览数', 'int(10) unsigned NULL ', 'num', '0', '', '0', '', '100', '0', '1', '1396510630', '1396510630', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('884', 'url', '关联URL', 'varchar(255) NULL ', 'string', '', '', '1', '', '101', '0', '1', '1394519090', '1394519090', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('885', 'title', '菜单名', 'varchar(50) NOT NULL', 'string', '', '可创建最多 3 个一级菜单，每个一级菜单下可创建最多 5 个二级菜单。编辑中的菜单不会马上被用户看到，请放心调试。', '1', '', '101', '1', '1', '1408950832', '1394518988', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('886', 'pid', '一级菜单', 'tinyint(2) NULL', 'select', '0', '如果是一级菜单，选择“无”即可', '1', '0:无', '101', '0', '1', '1409045931', '1394518930', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('887', 'sort', '排序号', 'tinyint(4) NULL ', 'num', '0', '数值越小越靠前', '1', '', '101', '0', '1', '1394523288', '1394519175', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('888', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '101', '0', '1', '1394526820', '1394526820', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('889', 'icon', '图标', 'int(10) unsigned NULL ', 'picture', '', '根据选择的底部模板决定是否需要上传图标', '1', '', '101', '0', '1', '1396506297', '1396506297', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('890', 'title', '标题', 'varchar(255) NULL', 'string', '', '可为空', '1', '', '102', '0', '1', '1396098316', '1396098316', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('891', 'img', '图片', 'int(10) unsigned NOT NULL ', 'picture', '', '', '1', '', '102', '1', '1', '1396098349', '1396098349', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('892', 'url', '链接地址', 'varchar(255) NULL', 'string', '', '', '1', '', '102', '0', '1', '1396098380', '1396098380', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('893', 'is_show', '是否显示', 'tinyint(2) NULL', 'bool', '1', '', '1', '0:不显示\r\n1:显示', '102', '0', '1', '1396098464', '1396098464', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('894', 'sort', '排序', 'int(10) NULL ', 'num', '0', '值越小越靠前', '1', '', '102', '0', '1', '1464704295', '1396098682', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('895', 'token', 'Token', 'varchar(100) NULL', 'string', '', '', '0', '', '102', '0', '1', '1396098747', '1396098747', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('896', 'ToUserName', 'Token', 'varchar(100) NULL', 'string', '', '', '0', '', '103', '0', '1', '1438143065', '1438143065', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('897', 'FromUserName', 'OpenID', 'varchar(100) NULL', 'string', '', '', '0', '', '103', '0', '1', '1438143098', '1438143098', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('898', 'CreateTime', '创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '103', '0', '1', '1438143120', '1438143120', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('899', 'MsgType', '消息类型', 'varchar(30) NULL', 'string', '', '', '0', '', '103', '0', '1', '1438143139', '1438143139', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('900', 'MsgId', '消息ID', 'varchar(100) NULL', 'string', '', '', '0', '', '103', '0', '1', '1438143182', '1438143182', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('901', 'Content', '文本消息内容', 'text NULL', 'textarea', '', '', '0', '', '103', '0', '1', '1438143218', '1438143218', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('902', 'PicUrl', '图片链接', 'varchar(255) NULL', 'string', '', '', '0', '', '103', '0', '1', '1438143273', '1438143273', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('903', 'MediaId', '多媒体文件ID', 'varchar(100) NULL', 'string', '', '', '0', '', '103', '0', '1', '1438143357', '1438143357', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('904', 'Format', '语音格式', 'varchar(30) NULL', 'string', '', '', '0', '', '103', '0', '1', '1438143397', '1438143397', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('905', 'ThumbMediaId', '缩略图的媒体id', 'varchar(30) NULL', 'string', '', '', '0', '', '103', '0', '1', '1438143445', '1438143426', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('906', 'Title', '消息标题', 'varchar(100) NULL', 'string', '', '', '0', '', '103', '0', '1', '1438143471', '1438143471', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('907', 'Description', '消息描述', 'text NULL', 'textarea', '', '', '0', '', '103', '0', '1', '1438143535', '1438143535', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('908', 'Url', 'Url', 'varchar(255) NULL', 'string', '', '', '0', '', '103', '0', '1', '1438143558', '1438143558', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('909', 'collect', '收藏状态', 'tinyint(1) NULL', 'bool', '0', '', '0', '0:未收藏\r\n1:已收藏', '103', '0', '1', '1438153936', '1438153936', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('910', 'deal', '处理状态', 'tinyint(1) NULL', 'bool', '0', '', '0', '0:未处理\r\n1:已处理', '103', '0', '1', '1438165005', '1438153991', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('911', 'is_read', '是否已读', 'tinyint(1) NULL', 'bool', '0', '', '1', '0:未读\r\n1:已读', '103', '0', '1', '1438165062', '1438165062', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('912', 'type', '消息分类', 'tinyint(1) NULL', 'bool', '0', '', '1', '0:用户消息\r\n1:管理员回复消息', '103', '0', '1', '1438168301', '1438168301', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('913', 'send_name', '发送人', 'varchar(255) NULL', 'string', '', '', '1', '', '104', '1', '1', '1429346507', '1429346507', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('914', 'receive_name', '接收人', 'varchar(255) NULL', 'string', '', '', '1', '', '104', '1', '1', '1429346556', '1429346556', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('915', 'content', '祝福语', 'text NULL', 'textarea', '', '', '1', '', '104', '1', '1', '1429346679', '1429346679', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('916', 'create_time', ' 创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '104', '0', '1', '1429604045', '1429346729', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('917', 'template', '模板', 'char(50) NULL', 'string', '', '模板的文件夹名称，不能为中文', '1', '', '104', '1', '1', '1429348371', '1429346979', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('918', 'template_cate', '模板分类', 'varchar(255) NULL', 'string', '', '', '4', '', '104', '1', '1', '1429348355', '1429347540', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('919', 'read_count', '浏览次数', 'int(10) NULL', 'num', '0', '', '0', '', '104', '0', '1', '1429348951', '1429348951', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('920', 'mid', '用户Id', 'varchar(255) NULL', 'num', '', '', '0', '', '104', '0', '1', '1429673299', '1429512603', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('921', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '104', '0', '1', '1429764969', '1429764969', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('922', 'content_cate_id', '祝福语类别Id', 'int(10) NULL', 'num', '0', '', '4', '', '105', '1', '1', '1429349347', '1429349074', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('923', 'content', '祝福语', 'text NULL', 'textarea', '', '', '1', '', '105', '1', '1', '1429349162', '1429349162', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('924', 'content_cate', '类别', 'varchar(255) NULL', 'select', '', '', '1', '', '105', '0', '1', '1429522282', '1429350568', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('925', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '105', '0', '1', '1429523422', '1429512730', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('926', 'content_cate_name', '祝福语类别', 'varchar(255) NULL', 'string', '', '', '1', '', '106', '1', '1', '1429349396', '1429349396', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('927', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '106', '0', '1', '1429520955', '1429512697', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('928', 'content_cate_icon', '类别图标', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '106', '0', '1', '1429597855', '1429597855', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1060', 'wx_key_pem', '上传密匙', 'int(10) UNSIGNED NULL', 'file', '', 'apiclient_key.pem', '1', '', '61', '0', '1', '1439804544', '1439804014', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1062', 'login_name', 'login_name', 'varchar(100) NULL', 'string', '', '', '1', '', '1', '0', '1', '1447302647', '1439978705', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1063', 'content', '文本消息内容', 'text NULL', 'textarea', '', '', '0', '', '18', '0', '1', '1439980070', '1439980070', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1395', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '0', '', '153', '0', '1', '1440071867', '1440071805', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1396', 'manager_id', '管理员id', 'int(10) NULL', 'num', '', '', '0', '', '153', '0', '1', '1440071927', '1440071917', '', '3', '', 'regex', 'get_mid', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1067', 'start_time', '开始时间', 'int(10) NULL', 'datetime', '', '', '1', '', '90', '1', '1', '1440408604', '1440407931', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1068', 'end_time', '结束时间', 'int(10) NULL', 'datetime', '', '', '1', '', '90', '1', '1', '1440408598', '1440407951', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1069', 'act_remark', '活动备注', 'varchar(255) NULL', 'string', '', '', '1', '', '65', '0', '1', '1440488802', '1440488802', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1071', 'is_bind', '是否为微信开放平台绑定账号', 'tinyint(2) NULL', 'bool', '0', '', '0', '0:否\r\n1:是', '6', '0', '1', '1440746890', '1440746890', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1101', 'url', '图文页url', 'varchar(255) NULL', 'string', '', '', '0', '', '17', '0', '1', '1441077355', '1441077355', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1815', 'from_type', '配置动作', 'char(50) NULL', 'select', '-1', '', '1', '0:站内信息|keyword@hide,url@hide,type@hide,sucai_type@hide,addon@show,jump_type@show\r\n1:站内素材|keyword@hide,url@hide,type@hide,sucai_type@show,addon@hide,jump_type@hide\r\n9:自定义|keyword@show,url@hide,type@show,addon@hide,sucai_type@hide,jump_type@hide\r\n-1:请选择|keyword@hide,url@hide,type@hide,addon@hide,sucai_type@hide,jump_type@hide', '34', '0', '1', '1447318552', '1447208677', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1864', 'addon', '选择插件', 'char(50) NULL', 'select', '0', '', '1', '0:请选择', '34', '0', '1', '1447208750', '1447208750', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1865', 'target_id', '选择内容', 'int(10) NULL', 'num', '', '', '4', '0:请选择', '34', '0', '1', '1447208825', '1447208825', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1866', 'sucai_type', '素材类型', 'varchar(50) NULL', 'material', '', '', '1', '', '34', '0', '1', '1464357378', '1447208890', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1867', 'jump_type', '推送类型', 'char(10) NULL', 'radio', '0', '', '1', '1:URL|keyword@hide,url@show\r\n0:关键词|keyword@show,url@hide', '34', '0', '1', '1447208981', '1447208981', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1825', 'ToUserName', 'token', 'varchar(255) NULL', 'string', '', '', '1', '', '201', '0', '1', '1447241964', '1447241964', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1826', 'FromUserName', 'openid', 'varchar(255) NULL', 'string', '', '', '1', '', '201', '0', '1', '1447242006', '1447242006', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1827', 'cTime', '创建时间', 'int(10) NULL', 'datetime', '', '', '1', '', '201', '0', '1', '1447242030', '1447242030', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1828', 'msgType', '消息类型', 'varchar(255) NULL', 'string', '', '', '1', '', '201', '0', '1', '1447242059', '1447242059', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1829', 'manager_id', '管理员id', 'int(10) NULL', 'num', '', '', '1', '', '201', '0', '1', '1447242090', '1447242090', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1830', 'content', '内容', 'text NULL', 'textarea', '', '', '1', '', '201', '0', '1', '1447242120', '1447242120', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1831', 'media_id', '多媒体文件id', 'varchar(255) NULL', 'string', '', '', '1', '', '201', '0', '1', '1447242146', '1447242146', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1832', 'is_send', '是否已经发送', 'int(10) NULL', 'num', '', '', '1', '0:未发\r\n1:已发', '201', '0', '1', '1447242181', '1447242181', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1833', 'uid', '粉丝uid', 'int(10) NULL', 'num', '', '', '1', '', '201', '0', '1', '1447242202', '1447242202', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1834', 'news_group_id', '图文组id', 'varchar(255) NULL', 'string', '', '', '1', '', '201', '0', '1', '1447242229', '1447242229', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1835', 'video_title', '视频标题', 'varchar(255) NULL', 'string', '', '', '1', '', '201', '0', '1', '1447242267', '1447242267', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1836', 'video_description', '视频描述', 'text NULL', 'textarea', '', '', '1', '', '201', '0', '1', '1447242291', '1447242291', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1837', 'video_thumb', '视频缩略图', 'varchar(255) NULL', 'string', '', '', '1', '', '201', '0', '1', '1447242366', '1447242366', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1844', 'voice_id', '语音id', 'int(10) NULL', 'num', '', '', '1', '', '201', '0', '1', '1447242400', '1447242400', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1845', 'image_id', '图片id', 'int(10) NULL', 'num', '', '', '1', '', '201', '0', '1', '1447242440', '1447242440', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1846', 'video_id', '视频id', 'int(10) NULL', 'num', '', '', '1', '', '201', '0', '1', '1447242464', '1447242464', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1847', 'send_type', '发送方式', 'int(10) NULL', 'num', '', '', '1', '0:分组\r\n1:指定用户', '201', '0', '1', '1447242498', '1447242498', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1848', 'send_opends', '指定用户', 'text NULL', 'textarea', '', '', '1', '', '201', '0', '1', '1447242529', '1447242529', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1849', 'group_id', '分组id', 'int(10) NULL', 'num', '', '', '1', '', '201', '0', '1', '1447242553', '1447242553', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1850', 'diff', '区分消息标识', 'int(10) NULL', 'num', '0', '', '1', '', '201', '0', '1', '1447242584', '1447242584', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1326', 'content', '文本内容', 'text NULL', 'textarea', '', '', '1', '', '148', '1', '1', '1442976151', '1442976151', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1327', 'token', 'Token', 'varchar(50) NULL', 'string', '', '', '0', '', '148', '0', '1', '1442978004', '1442978004', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1328', 'uid', 'uid', 'int(10) NULL', 'num', '', '', '0', '', '148', '0', '1', '1442978041', '1442978041', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1820', 'is_use', '可否使用', 'int(10) NULL', 'num', '1', '', '0', '0:不可用\r\n1:可用', '148', '0', '1', '1445496947', '1445496947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1821', 'aim_id', '添加来源标识id', 'int(10) NULL', 'num', '', '', '0', '', '148', '0', '1', '1445497010', '1445497010', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1822', 'aim_table', '来源表名', 'varchar(255) NULL', 'string', '', '', '0', '', '148', '0', '1', '1445497218', '1445497218', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1329', 'file_id', '上传文件', 'int(10) NULL', 'file', '', '', '1', '', '149', '0', '1', '1442982169', '1438684652', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1330', 'cover_url', '本地URL', 'varchar(255) NULL', 'string', '', '', '0', '', '149', '0', '1', '1438684692', '1438684692', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1331', 'media_id', '微信端图文消息素材的media_id', 'varchar(100) NULL', 'string', '0', '', '0', '', '149', '0', '1', '1438744962', '1438684776', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1332', 'wechat_url', '微信端的文件地址', 'varchar(255) NULL', 'string', '', '', '0', '', '149', '0', '1', '1439973558', '1438684807', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1333', 'cTime', '创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '149', '0', '1', '1443004484', '1438684829', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1334', 'manager_id', '管理员ID', 'int(10) NULL', 'num', '', '', '0', '', '149', '0', '1', '1442982446', '1438684847', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1335', 'token', 'Token', 'varchar(100) NULL', 'string', '', '', '0', '', '149', '0', '1', '1442982460', '1438684865', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1336', 'title', '素材名称', 'varchar(100) NULL', 'string', '', '', '1', '', '149', '1', '1', '1463748750', '1442981165', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1341', 'type', '类型', 'int(10) NULL', 'num', '', '', '0', '1:语音素材\r\n2:视频素材', '149', '0', '1', '1445599238', '1443006101', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1838', 'introduction', '描述', 'text NULL', 'textarea', '', '', '0', '', '149', '0', '1', '1447299133', '1445684769', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1853', 'from_type', '用途', 'varchar(255) NULL', 'string', '', '', '1', '', '202', '0', '1', '1446107717', '1446107717', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1854', 'code', '验证码', 'varchar(255) NULL', 'string', '', '', '1', '', '202', '0', '1', '1446110095', '1446110095', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1855', 'smsId', '短信唯一标识', 'varchar(255) NULL', 'string', '', '', '1', '', '202', '0', '1', '1446110244', '1446110244', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1856', 'phone', '手机号', 'varchar(255) NULL', 'string', '', '', '1', '', '202', '0', '1', '1446110276', '1446110276', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1857', 'cTime', '创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '202', '0', '1', '1446110405', '1446110405', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1858', 'status', '使用状态', 'int(10) NULL', 'num', '', '', '1', '', '202', '0', '1', '1446110690', '1446110690', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1859', 'plat_type', '平台标识', 'int(10) NULL', 'num', '', '', '1', '', '202', '0', '1', '1446110716', '1446110716', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1120', 'business_card_id', '名片id', 'int(10) NULL', 'num', '', '', '4', '', '128', '0', '1', '1441779829', '1441522726', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1121', 'level', '管理等级', 'tinyint(2) NULL', 'num', '0', '', '0', '', '1', '0', '1', '1441522953', '1441522953', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1113', 'type', '栏目类型', 'char(10) NULL', 'select', '0', '', '1', '0:自定义|cate_id@hide,title@show,url@show\r\n1:文章分类|cate_id@show,title@hide,url@hide', '128', '0', '1', '1441525619', '1441512922', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1285', 'cTime', '创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '143', '0', '1', '1442392869', '1442392869', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1284', 'token', 'Token', 'varchar(100) NULL', 'string', '', '', '0', '', '143', '0', '1', '1442392843', '1442392843', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1283', 'manager_id', '管理员ID', 'int(10) NULL', 'num', '', '', '0', '', '143', '0', '1', '1442392818', '1442392818', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1282', 'use_count', '已使用数', 'int(10) NULL', 'num', '0', '', '0', '', '143', '0', '1', '1442392790', '1442392790', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1281', 'collect_count', '领取数', 'int(10) NULL', 'num', '0', '', '0', '', '143', '0', '1', '1442392753', '1442392753', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1280', 'status', '状态', 'tinyint(2) NULL', 'bool', '1', '', '0', '0:失效\r\n1:正常', '143', '0', '1', '1442392723', '1442392723', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1279', 'content', '使用说明', 'text NULL', 'textarea', '', '', '1', '', '143', '0', '1', '1442392183', '1442392183', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1277', 'limit_goods_ids', '指定的商品', 'varchar(100) NULL', 'string', '', '', '1', '', '143', '0', '1', '1442391948', '1442391948', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1278', 'is_market_price', '仅原价购买商品时可用 ', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:否\r\n1:是', '143', '0', '1', '1442392119', '1442392119', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1276', 'limit_goods', '可适用商品', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:全店适用|limit_gooods_ids@hide\r\n1:指定商品适用|limit_gooods_ids@show', '143', '0', '1', '1442391793', '1442391793', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1275', 'end_time', '过期时间', 'int(10) NULL', 'datetime', '', '', '1', '', '143', '1', '1', '1442391587', '1442391560', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1274', 'start_time', '生效时间', 'int(10) NULL', 'datetime', '', '', '1', '', '143', '1', '1', '1442391577', '1442391534', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1273', 'limit_num', '每人限领', 'char(50) NULL', 'select', '0', '', '1', '0:不限张\r\n1:1张\r\n2:2张\r\n3:3张\r\n4:4张\r\n5:5张\r\n10:10张', '143', '0', '1', '1442391505', '1442391505', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1272', 'order_money', '订单金额', 'decimal(11,2) NULL', 'num', '0', '满多少可以使用，0表示不限制', '1', '', '143', '0', '1', '1442391194', '1442391194', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1271', 'is_money_rand', '面值是否随机', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:否|money_max@hide\r\n1:是|money_max@show', '143', '0', '1', '1442391067', '1442391067', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1270', 'money_max', '最大面值', 'decimal(11,2) NULL', 'num', '0', '', '1', '', '143', '0', '1', '1444650857', '1442390963', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1268', 'num', '发放量', 'int(10) NULL', 'num', '0', '', '1', '', '143', '1', '1', '1442390822', '1442390822', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1267', 'title', '优惠券名称', 'varchar(30) NULL', 'string', '', '', '1', '', '143', '1', '1', '1442390791', '1442390791', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1269', 'money', '面值', 'decimal(11,2) NULL', 'num', '', '', '1', '', '143', '1', '1', '1442390916', '1442390916', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1112', 'login_password', '登录密码', 'varchar(255) NULL', 'string', '', '', '1', '', '1', '0', '1', '1441187439', '1441187439', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1114', 'manager_id', '公众号管理员ID', 'int(10) NULL', 'num', '0', '', '0', '', '1', '0', '1', '1441512815', '1441512815', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1115', 'cate_id', '分类', 'varchar(100) NULL', 'dynamic_select', '0', '', '1', 'table=we_media_category&value_field=id', '128', '0', '1', '1441525628', '1441513085', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1116', 'title', '栏目名称', 'varchar(255) NULL', 'string', '', '', '1', '', '128', '0', '1', '1441525667', '1441513114', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1117', 'url', '跳转url', 'varchar(255) NULL', 'string', '', '', '1', '', '128', '0', '1', '1441525683', '1441520141', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1118', 'sort', '排序', 'int(10) NULL', 'num', '0', '', '1', '', '128', '0', '1', '1441520666', '1441520666', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1124', 'uid', '用户id', 'int(10) NULL', 'num', '', '', '0', '', '128', '0', '1', '1441781769', '1441528808', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1155', 'membership', '会员等级', 'char(50) NULL', 'select', '0', '请在会员等级 添加会员级别名称', '0', '', '1', '0', '1', '1447302405', '1441795509', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1343', 'shop_pay_score', '支付返积分', 'int(10) NULL', 'num', '0', '不设置则默认为采用该支付方式不送积分', '1', '', '61', '0', '1', '1443065789', '1443064056', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1350', 'status', '发放状态', 'char(10) NULL', 'radio', 'SENDING', '', '1', 'SENDING:发放中\r\nSENT:已发放待领取\r\nFAILED：发放失败\r\nRECEIVED:已领取\r\nREFUND:已退款 ', '66', '0', '1', '1443077224', '1443077224', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1351', 'reason', '失败原因 ', 'varchar(50) NULL', 'string', '', '', '0', '', '66', '0', '1', '1443077304', '1443077304', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1352', 'Rcv_time', '领取红包的时间 ', 'int(10) NULL', 'datetime', '', '', '0', '', '66', '0', '1', '1443077415', '1443077415', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1353', 'Send_time', '红包发送时间 ', 'int(10) NULL', 'datetime', '', '', '0', '', '66', '0', '1', '1443077446', '1443077446', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1354', 'Refund_time', '红包退款时间', 'int(10) NULL', 'datetime', '', '', '0', '', '66', '0', '1', '1443077472', '1443077472', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1355', 'extra', '微信返回的数据集', 'text NULL', 'textarea', '', '', '0', '', '66', '0', '1', '1443077530', '1443077530', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1399', 'open_time', '营业时间', 'varchar(50) NULL', 'string', '', '', '1', '', '153', '0', '1', '1443106576', '1443106576', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1400', 'title', '活动名称', 'varchar(100) NULL', 'string', '', '', '1', '', '155', '1', '1', '1443111611', '1443111611', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1402', 'start_time', '开始时间', 'int(10) NULL', 'datetime', '', '', '1', '', '155', '0', '1', '1443111673', '1443111673', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1403', 'end_time', '过期时间', 'int(10) NULL', 'datetime', '', '', '1', '', '155', '0', '1', '1443111693', '1443111693', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1404', 'limit_num', '帮拆人数限制', 'int(10) NULL', 'num', '5', '多少好友帮拆开礼包才有效', '1', '', '155', '0', '1', '1443111821', '1443111821', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1758', 'coupon_id', '优惠券ID', 'int(10) NULL', 'num', '', '', '1', '', '194', '0', '1', '1445081094', '1445081094', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1406', 'content', '活动规则', 'text  NULL', 'textarea', '', '', '1', '', '155', '0', '1', '1445078360', '1443111915', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1408', 'invite_uid', '邀请人ID', 'int(10) NULL', 'num', '', '', '0', '', '156', '0', '1', '1443141991', '1443141991', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1409', 'friend_uid', '帮拆人ID', 'int(10) NULL', 'num', '', '', '0', '', '156', '0', '1', '1443142036', '1443142036', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1410', 'help_id', '活动ID', 'int(10) NULL', 'num', '', '', '0', '', '156', '0', '1', '1443142057', '1443142057', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1411', 'cTime', '创建时间', 'int(10) NULL', 'num', '', '', '1', '', '156', '0', '1', '1443142208', '1443142208', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1759', 'shop_coupon_id', '代金券ID', 'int(10) NULL', 'num', '', '', '1', '', '194', '0', '1', '1445081136', '1445081136', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1760', 'money', '返现金额', 'decimal(11,2) NULL', 'num', '', '', '1', '', '194', '0', '1', '1445081198', '1445081198', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1447', 'title', '活动名称', 'varchar(255) NULL', 'string', '', '', '1', '', '163', '1', '1', '1443148922', '1443148534', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1448', 'select_type', '投票类型', 'char(10) NULL', 'radio', '1', '', '1', '1:单选|multi_num@hide\r\n2:多选|multi_num@show', '163', '0', '1', '1443148839', '1443148618', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1449', 'multi_num', '多选限制', 'int(10) NULL', 'num', '0', '0代表不限制', '1', '', '163', '0', '1', '1443148734', '1443148734', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1450', 'start_time', '开始时间', 'int(10) NULL', 'datetime', '', '', '1', '', '163', '1', '1', '1443148948', '1443148880', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1451', 'end_time', '结束时间', 'int(10) NULL', 'datetime', '', '', '1', '', '163', '1', '1', '1443148958', '1443148911', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1757', 'prize_type', '奖项类型', 'tinyint(1) NULL', 'radio', '0', '', '1', '0:请选择\r\n1:优惠券\r\n2:代金券\r\n3:返现', '194', '0', '1', '1445081030', '1445081030', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1453', 'remark', '活动说明', 'text NULL', 'textarea', '', '', '1', '', '163', '0', '1', '1443149020', '1443149020', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1756', 'name', '奖项名称', 'varchar(100) NULL', 'string', '', '', '1', '', '194', '0', '1', '1445080939', '1445080939', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1455', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '0', '', '163', '0', '1', '1443149050', '1443149050', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1456', 'token', 'token', 'varchar(50) NULL', 'string', '', '', '0', '', '155', '0', '1', '1443148889', '1443148889', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1457', 'manager_id', 'manager_id', 'int(10) NULL', 'num', '', '', '0', '', '155', '0', '1', '1443148912', '1443148912', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1458', 'manager_id', '管理员id', 'int(10) NULL', 'num', '', '', '0', '', '163', '0', '1', '1443149118', '1443149118', '', '3', '', 'regex', 'get_mid', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1459', 'truename', '参赛者', 'varchar(255) NULL', 'string', '', '', '1', '', '164', '1', '1', '1447817227', '1443149261', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1460', 'image', '参赛图片', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '164', '1', '1', '1447817196', '1443149366', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1461', 'uid', '用户id', 'int(10) NULL', 'num', '', '', '0', '', '164', '0', '1', '1443149449', '1443149437', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1462', 'manifesto', '参赛宣言', 'text NULL', 'textarea', '', '', '1', '', '164', '1', '1', '1447817176', '1443149626', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1463', 'introduce', '选手介绍', 'text NULL', 'textarea', '', '', '1', '', '164', '1', '1', '1443149732', '1443149732', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1464', 'ctime', '创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '164', '0', '1', '1443149776', '1443149776', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1465', 'vote_id', '活动id', 'int(10) NULL', 'num', '', '', '4', '', '164', '0', '1', '1443149827', '1443149827', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1466', 'opt_count', '投票数', 'int(10) NULL', 'num', '0', '', '0', '', '164', '0', '1', '1443154633', '1443149866', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1467', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '0', '', '164', '0', '1', '1443149961', '1443149961', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1468', 'vote_id', '活动id', 'int(10) NULL', 'num', '', '', '1', '', '165', '0', '1', '1443150128', '1443150128', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1469', 'option_id', '选项id', 'int(10) NULL', 'num', '', '', '1', '', '165', '0', '1', '1443150157', '1443150157', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1470', 'uid', '投票者id', 'int(10) NULL', 'num', '', '', '1', '', '165', '0', '1', '1443150185', '1443150185', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1471', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '0', '', '165', '0', '1', '1443150248', '1443150248', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1472', 'ctime', '投票时间', 'int(10) NULL', 'datetime', '', '', '0', '', '165', '0', '1', '1443150271', '1443150271', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1473', 'title', '特权标题', 'varchar(255) NULL', 'string', '', '', '1', '', '166', '0', '1', '1443153661', '1443153661', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1474', 'grade', '适用人群', 'varchar(100) NULL', 'checkbox', '', '', '1', '', '166', '0', '1', '1443165742', '1443153832', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1475', 'start_time', '开始时间', 'int(10) NULL', 'datetime', '', '', '1', '', '166', '0', '1', '1443153870', '1443153870', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1476', 'end_time', '结束时间', 'int(10) NULL', 'datetime', '', '', '1', '', '166', '0', '1', '1443153895', '1443153895', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1477', 'intro', '使用说明', 'text NULL', 'textarea', '', '', '1', '', '166', '0', '1', '1443153964', '1443153964', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1478', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '0', '', '166', '0', '1', '1443154036', '1443154036', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1480', 'level', '会员等级', 'varchar(255) NULL', 'string', '', '', '1', '', '167', '0', '1', '1443163097', '1443163097', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1481', 'score', '累计积分', 'int(10) NULL', 'num', '', '', '1', '', '167', '0', '1', '1443163223', '1443163223', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1482', 'recharge', '累计充值', 'int(10) NULL', 'num', '', '', '1', '', '167', '0', '1', '1443163252', '1443163252', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1483', 'discount', '折扣率', 'int(10) NULL', 'num', '', '例如10代表优惠10%，即打9折', '1', '', '167', '0', '1', '1443163384', '1443163384', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1484', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '0', '', '167', '0', '1', '1443163422', '1443163422', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1485', 'enable', '是否启用', 'tinyint(2) NULL', 'bool', '1', '', '1', '1:启用\r\n0:禁用', '166', '0', '1', '1443164479', '1443164437', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1524', 'status', '会员状态', 'tinyint(2) NULL', 'bool', '1', '', '0', '1:正常\r\n0:冻结', '173', '0', '1', '1444271533', '1444271533', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1504', 'give_type', '发放方式', 'tinyint(2) NOT NULL', 'bool', '0', '人工发放是指管理员要会员管理列表手工进行发放', '0', '0:自动发放\r\n1:人工发放', '171', '0', '1', '1395487734', '1395486034', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1505', 'title', '优惠券标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '171', '0', '1', '1395485828', '1395485828', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1506', 'end_date', '结束时间', 'int(10) NULL', 'datetime', '', '', '1', '', '171', '0', '1', '1395486188', '1395486188', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1507', 'start_date', '开始时间', 'int(10) NOT NULL', 'datetime', '', '', '1', '', '171', '0', '1', '1395486135', '1395486135', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1508', 'content', '使用说明', 'text NOT NULL', 'editor', '', '', '1', '', '171', '0', '1', '1395486307', '1395486307', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1509', 'cTime', '发布时间', 'int(10) NULL', 'datetime', '', '', '0', '', '171', '0', '1', '1395486839', '1395486801', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1510', 'token', 'Token', 'varchar(100) NOT NULL', 'string', '', '', '0', '', '171', '0', '1', '1395912079', '1395912079', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1511', 'cTime', '发布时间', 'int(10) NULL', 'datetime', '', '', '0', '', '172', '0', '1', '1395485303', '1395485303', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1512', 'content', '通知内容', 'text NOT NULL', 'editor', '', '', '1', '', '172', '1', '1', '1444471509', '1395485247', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1513', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '172', '1', '1', '1444471517', '1395485192', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1514', 'token', 'Token', 'varchar(100) NOT NULL', 'string', '', '', '0', '', '172', '0', '1', '1395911896', '1395911896', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1515', 'number', '卡号', 'varchar(50) NULL', 'string', '', '', '3', '', '173', '0', '1', '1395484806', '1395483310', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1516', 'cTime', '加入时间', 'int(10) NULL', 'datetime', '', '', '0', '', '173', '0', '1', '1395484366', '1395484366', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1517', 'phone', '手机号', 'varchar(30) NULL', 'string', '', '', '1', '', '173', '0', '1', '1395483248', '1395483248', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1518', 'username', '姓名', 'varchar(100) NULL', 'string', '', '', '1', '', '173', '0', '1', '1395483048', '1395483048', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1519', 'uid', '用户UID', 'int(10) NOT NULL', 'num', '', '', '0', '', '173', '0', '1', '1395482973', '1395482973', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1520', 'token', 'Token', 'varchar(100) NOT NULL', 'string', '', '', '0', '', '173', '0', '1', '1395973788', '1395912028', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1523', 'number', '编号', 'int(10) NULL', 'num', '1', '', '0', '', '164', '0', '1', '1443173465', '1443173454', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1522', 'recharge', '余额', 'int(10) NULL', 'num', '0', '', '1', '', '173', '0', '1', '1443171423', '1443170806', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1526', 'recharge', '充值金额', 'float(10) NULL', 'num', '', '', '1', '', '174', '1', '1', '1444286201', '1444276045', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1527', 'branch_id', '充值门店', 'int(10) NULL', 'num', '0', '', '1', '', '174', '0', '1', '1444276408', '1444276408', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1528', 'operator', '操作员', 'varchar(255) NULL', 'string', '', '', '1', '', '174', '0', '1', '1444287439', '1444276506', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1529', 'cTime', '创建时间', 'int(10) NULL', 'datetime', '', '', '1', '', '174', '0', '1', '1444276539', '1444276539', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1530', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '1', '', '174', '0', '1', '1444276565', '1444276565', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1531', 'member_id', '会员id', 'int(10) NULL', 'num', '', '', '4', '', '174', '0', '1', '1444285683', '1444285649', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1532', 'manager_id', '管理员id', 'int(10) NULL', 'num', '', '', '1', '', '174', '0', '1', '1444287330', '1444287330', '', '3', '', 'regex', 'get_mid', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1533', 'pay', '消费金额', 'float(10) NULL', 'num', '', '', '1', '', '175', '1', '1', '1444296855', '1444289970', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1534', 'sn_id', '优惠卷', 'int(10) NULL', 'num', '', '', '1', '', '175', '0', '1', '1444297432', '1444290217', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1535', 'pay_type', '支付方式', 'char(10) NULL', 'radio', '', '', '1', '1:会员卡余额消费\r\n2:现金或POS机消费', '175', '1', '1', '1444296840', '1444290385', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1536', 'branch_id', '消费门店', 'int(10) NULL', 'num', '0', '', '1', '', '175', '0', '1', '1444296901', '1444290445', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1537', 'member_id', '会员卡id', 'int(10) NULL', 'num', '', '', '4', '', '175', '0', '1', '1444290484', '1444290472', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1538', 'cTime', '创建时间', 'int(10) NULL', 'datetime', '', '', '1', '', '175', '0', '1', '1444290512', '1444290512', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1539', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '1', '', '175', '0', '1', '1444290535', '1444290535', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1540', 'manager_id', '管理员ID', 'int(10) NULL', 'num', '', '', '1', '', '175', '0', '1', '1444297606', '1444290558', '', '3', '', 'regex', 'get_mid', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1542', 'score', '修改积分', 'int(10) NULL', 'num', '', '', '1', '', '176', '1', '1', '1444302622', '1444302410', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1543', 'branch_id', '修改门店', 'int(10) NULL', 'num', '', '', '1', '', '176', '0', '1', '1444302450', '1444302450', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1544', 'operator', '操作员', 'varchar(255) NULL', 'string', '', '', '1', '', '176', '0', '1', '1444302474', '1444302474', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1545', 'cTime', '修改时间', 'int(10) NULL', 'datetime', '', '', '0', '', '176', '0', '1', '1444302508', '1444302508', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1546', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '1', '', '176', '0', '1', '1444302539', '1444302539', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1547', 'member_id', '会员卡id', 'int(10) NULL', 'num', '', '', '4', '', '176', '0', '1', '1444302566', '1444302566', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1548', 'manager_id', '管理员id', 'int(10) NULL', 'num', '', '', '1', '', '176', '0', '1', '1444302595', '1444302595', '', '3', '', 'regex', 'get_mid', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1549', 'score', '积分', 'int(10) NOT NULL', 'num', '', '', '1', '', '177', '0', '1', '1404694456', '1404694456', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1550', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '177', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1551', 'sTime', '签到时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '177', '1', '1', '1404631787', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1552', 'uid', '用户ID', 'varchar(255) NOT NULL', 'textarea', '', '', '1', '', '177', '1', '1', '1404631866', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1751', 'share_icon', '分享图标', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '155', '0', '1', '1445078407', '1445078407', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1562', 'sn_id', 'sn', 'int(10) NULL', 'num', '', '', '0', '', '156', '0', '1', '1445240730', '1444462169', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1797', 'is_check', '验证是否成功', 'int(10) NULL', 'num', '0', '', '0', '', '192', '0', '1', '1445246146', '1445246146', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1753', 'share_intro', '分享简介', 'varchar(255) NULL', 'string', '', '', '1', '', '155', '0', '1', '1445078450', '1445078450', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1565', 'img', '通知图片', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '172', '0', '1', '1444472055', '1444470114', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1566', 'grade', '适用人群', 'varchar(100) NULL', 'checkbox', '0', '', '1', '0:所有会员', '172', '0', '1', '1444478807', '1444471427', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1567', 'title', '活动名称', 'varchar(255) NULL', 'string', '', '', '1', '', '179', '1', '1', '1444482518', '1444482518', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1568', 'start_time', '开始时间', 'int(10) NULL', 'datetime', '', '', '1', '', '179', '1', '1', '1444482549', '1444482549', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1569', 'end_time', '结束时间', 'int(10) NULL', 'datetime', '', '', '1', '', '179', '1', '1', '1444482572', '1444482572', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1570', 'status', '状态', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:关闭\r\n1:开启', '179', '0', '1', '1444482635', '1444482635', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1571', 'type', '活动类型', 'char(50) NULL', 'select', '', '', '1', '1:开卡即送\r\n2:积分兑换\r\n3:充值赠送\r\n4:消费赠送', '179', '0', '1', '1444482777', '1444482777', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1572', 'give_type', '赠送类型', 'char(10) NULL', 'radio', '', '', '1', '1:积分\r\n2:优惠券\r\n3:现金', '179', '0', '1', '1444482866', '1444482866', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1573', 'give', '赠送数据', 'int(10) NULL', 'num', '', '', '1', '', '179', '0', '1', '1444482894', '1444482894', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1574', 'condition', '赠送条件', 'int(10) NULL', 'num', '', '', '1', '', '179', '0', '1', '1444482918', '1444482918', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1575', 'branch_id', '充值门店', 'int(10) NULL', 'num', '', '', '1', '', '179', '0', '1', '1444482965', '1444482952', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1576', 'grade', '适用人群', 'int(10) NULL', 'num', '', '', '1', '', '179', '0', '1', '1444482986', '1444482986', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1577', 'exchange_count', '兑换次数', 'int(10) NULL', 'num', '', '', '1', '', '179', '0', '1', '1444483035', '1444483035', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1578', 'open_give_rule', '启用赠送规则', 'tinyint(2) NULL', 'bool', '0', '', '1', '', '179', '0', '1', '1444483107', '1444483107', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1579', 'enjoy_power', '消费享受权限', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:不限\r\n1:使用券消费的用户不享受', '179', '0', '1', '1444483206', '1444483206', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1580', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '1', '', '179', '0', '1', '1444483238', '1444483238', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1583', 'member', '选择人群', 'varchar(100) NULL', 'checkbox', '0', '', '1', '0:所有用户\r\n-1:所有会员', '143', '0', '1', '1446101088', '1444620516', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1584', 'manager_id', '管理员ID', 'int(10) NULL', 'num', '', '', '0', '', '180', '0', '1', '1442458516', '1442458516', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1585', 'token', 'Token', 'varchar(50) NULL', 'string', '', '', '0', '', '180', '0', '1', '1442458480', '1442458480', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1586', 'cTime', '创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '180', '0', '1', '1442458439', '1442458439', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1594', 'score', '积分数', 'int(10) NULL', 'num', '0', '', '1', '', '180', '0', '1', '1444622853', '1444622853', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1595', 'coupon_id', '商城优惠券', 'int(10) NULL', 'num', '', '', '1', '', '180', '0', '1', '1444634724', '1444622932', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1600', 'manager_id', '管理员ID', 'int(10) NULL', 'num', '', '', '0', '', '181', '0', '1', '1442458516', '1442458516', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1596', 'is_show', '是否在用户领卡界面展示', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:否\r\n1:是', '180', '0', '1', '1444622979', '1444622979', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1590', 'start_time', '开始时间', 'int(10) NULL', 'datetime', '', '', '1', '', '180', '1', '1', '1442457879', '1442457879', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1591', 'end_time', '过期时间', 'int(10) NULL', 'datetime', '', '', '1', '', '180', '1', '1', '1442457902', '1442457902', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1592', 'title', '活动名称', 'varchar(100) NULL', 'string', '', '', '1', '', '180', '1', '1', '1442457852', '1442457852', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1593', 'type', '活动策略', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:送积分\r\n1:送优惠券', '180', '0', '1', '1444622808', '1444622808', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1597', 'content', '活动说明', 'text NULL', 'textarea', '', '', '1', '', '180', '0', '1', '1444623015', '1444623015', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1598', 'birthday', '生日', 'int(10) NULL', 'date', '', '', '0', '', '173', '0', '1', '1444634831', '1444634831', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1599', 'address', '地址', 'varchar(255) NULL', 'string', '', '', '0', '', '173', '0', '1', '1444634852', '1444634852', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1601', 'token', 'Token', 'varchar(50) NULL', 'string', '', '', '0', '', '181', '0', '1', '1442458480', '1442458480', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1602', 'cTime', '创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '181', '0', '1', '1442458439', '1442458439', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1603', 'num_limit', '兑换次数限制', 'int(10) NULL', 'num', '0', '', '1', '', '181', '0', '1', '1444639490', '1444622853', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1604', 'coupon_id', '商城优惠券', 'int(10) NULL', 'num', '', '', '1', '', '181', '0', '1', '1444634724', '1444622932', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1605', 'score_limit', '所需积分', 'int(10) NULL', 'num', '0', '', '1', '', '181', '0', '1', '1444639428', '1444622979', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1606', 'start_time', '开始时间', 'int(10) NULL', 'datetime', '', '', '1', '', '181', '1', '1', '1442457879', '1442457879', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1607', 'end_time', '过期时间', 'int(10) NULL', 'datetime', '', '', '1', '', '181', '1', '1', '1442457902', '1442457902', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1608', 'title', '活动名称', 'varchar(100) NULL', 'string', '', '', '1', '', '181', '1', '1', '1442457852', '1442457852', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1609', 'member', '适用人群', 'varchar(100) NULL', 'checkbox', '0', '', '1', '0:所有用户\r\n-1:所有会员卡成员', '181', '0', '1', '1446107007', '1444622808', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1628', 'end_time', '过期时间', 'int(10) NULL', 'datetime', '', '', '1', '', '183', '1', '1', '1442457902', '1442457902', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1627', 'start_time', '开始时间', 'int(10) NULL', 'datetime', '', '', '1', '', '183', '1', '1', '1442457879', '1442457879', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1624', 'goods_ids', '指定商品ID串', 'text NULL', 'textarea', '', '', '0', '', '183', '0', '1', '1442540989', '1442458406', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1623', 'cTime', '创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '183', '0', '1', '1442458439', '1442458439', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1622', 'token', 'Token', 'varchar(50) NULL', 'string', '', '', '0', '', '183', '0', '1', '1442458480', '1442458480', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1626', 'is_mult', '多级优惠', 'tinyint(2) NULL', 'bool', '0', '多级情况下每级优惠不累积叠加', '1', '0:否\r\n1:是', '183', '0', '1', '1442458033', '1442458011', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1625', 'is_all_goods', '适用的活动商品', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:全部商品参与\r\n1:指定商品参与', '183', '0', '1', '1442458365', '1442458365', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1621', 'manager_id', '管理员ID', 'int(10) NULL', 'num', '', '', '0', '', '183', '0', '1', '1442458516', '1442458516', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1629', 'title', '活动名称', 'varchar(100) NULL', 'string', '', '', '1', '', '183', '1', '1', '1442457852', '1442457852', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1631', 'money_param', '现金参数', 'decimal(11,2) NULL', 'num', '', '', '1', '', '184', '0', '1', '1442542160', '1442542160', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1632', 'money', '现在开关', 'tinyint(2) NULL', 'bool', '', '', '0', '0:关\r\n1:开', '184', '0', '1', '1442542127', '1442542127', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1633', 'reward_id', '活动ID', 'int(10) NULL', 'num', '', '', '0', '', '184', '0', '1', '1442458906', '1442458906', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1634', 'sort', '排序号', 'int(10) NULL', 'num', '0', '', '1', '', '184', '0', '1', '1442544909', '1442544909', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1635', 'condition', '条件', 'decimal(11,2) NULL', 'num', '', '满多少元', '1', '', '184', '1', '1', '1442458834', '1442458834', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1636', 'score', '积分开关', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:关\r\n1:开', '184', '0', '1', '1442542268', '1442542268', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1637', 'score_param', '积分参数', 'int(10) NULL', 'num', '', '', '1', '', '184', '0', '1', '1442542292', '1442542292', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1638', 'shop_coupon', '优惠券开关', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:关\r\n1:开', '184', '0', '1', '1442542329', '1442542329', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1639', 'shop_coupon_param', '优惠券ID', 'int(10) NULL', 'num', '', '', '1', '', '184', '0', '1', '1442542366', '1442542366', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1640', 'manager_id', '管理员ID', 'int(10) NULL', 'num', '', '', '0', '', '185', '0', '1', '1442458516', '1442458516', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1641', 'token', 'Token', 'varchar(50) NULL', 'string', '', '', '0', '', '185', '0', '1', '1442458480', '1442458480', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1642', 'cTime', '创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '185', '0', '1', '1442458439', '1442458439', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1643', 'score', '积分数', 'int(10) NULL', 'num', '0', '', '1', '', '185', '0', '1', '1444622853', '1444622853', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1644', 'coupon_id', '商城优惠券', 'int(10) NULL', 'num', '', '', '1', '', '185', '0', '1', '1444634724', '1444622932', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1645', 'is_show', '是否在会员卡界面展示', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:否\r\n1:是', '185', '0', '1', '1444646159', '1444622979', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1646', 'start_time', '节日时间', 'int(10) NULL', 'datetime', '', '', '1', '', '185', '0', '1', '1444647869', '1442457879', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1647', 'end_time', '赠送时间', 'int(10) NULL', 'datetime', '', '', '1', '', '185', '0', '1', '1444647885', '1442457902', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1648', 'title', '活动名称', 'varchar(100) NULL', 'string', '', '', '1', '', '185', '1', '1', '1442457852', '1442457852', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1649', 'type', '活动策略', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:送积分\r\n1:送优惠券', '185', '0', '1', '1444622808', '1444622808', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1650', 'content', '活动说明', 'text NULL', 'textarea', '', '', '1', '', '185', '0', '1', '1444623015', '1444623015', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1654', 'type', '优惠券类型', 'char(10) NULL', 'radio', '0', '', '1', '0:优惠券\r\n1:代金券\r\n2:礼品券', '143', '0', '1', '1444649770', '1444649770', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1651', 'member', '适用人群', 'int(10) NULL', 'num', '', '', '1', '', '185', '0', '1', '1444646000', '1444646000', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1652', 'is_birthday', '节日类型', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:公历节日\r\n1:会员生日', '185', '0', '1', '1444646065', '1444646065', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1653', 'before_day', '生日前', 'tinyint(2) NULL', 'num', '1', '', '1', '', '185', '0', '1', '1444646117', '1444646117', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1655', 'level', '会员卡等级', 'int(10) NULL', 'num', '0', '', '1', '', '173', '0', '1', '1444714615', '1444714615', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1656', 'to_uid', '指定用户', 'int(10) NULL', 'num', '0', '', '0', '', '172', '0', '1', '1444717008', '1444716962', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1657', 'sex', '性别', 'int(10) NULL', 'num', '', '', '1', '1:男\r\n2:女', '173', '0', '1', '1444721537', '1444720977', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1658', 'coupon_type', '优惠券类型', 'int(10) NULL', 'num', '0', '', '1', '0:代金券\r\n1:优惠券', '181', '0', '1', '1444727785', '1444727785', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1659', 'card_score_id', '兑换活动id', 'int(10) NULL', 'num', '', '', '1', '', '186', '0', '1', '1444731420', '1444731420', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1660', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '1', '', '186', '0', '1', '1444799211', '1444731443', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1661', 'uid', 'uid', 'int(10) NULL', 'num', '', '', '1', '', '186', '0', '1', '1444731483', '1444731483', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1662', 'ctime', 'ctime', 'int(10) NULL', 'datetime', '', '', '1', '', '186', '0', '1', '1444731520', '1444731520', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1663', 'credit_title', '积分标题', 'varchar(50) NULL', 'string', '', '', '0', '', '15', '0', '1', '1444731976', '1444731976', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1664', 'uid', '用户id', 'int(10) NULL', 'num', '', '', '1', '', '187', '0', '1', '1444789735', '1444789735', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1665', 'sTime', '分享时间', 'int(10) NULL', 'datetime', '', '', '1', '', '187', '0', '1', '1444789762', '1444789762', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1666', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '1', '', '187', '0', '1', '1444789785', '1444789785', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1667', 'score', '积分', 'int(10) NULL', 'num', '', '', '1', '', '187', '0', '1', '1444789813', '1444789813', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1668', 'cover_id', '活动图片', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '181', '0', '1', '1444801906', '1444801906', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1669', 'member', '选择人群', 'varchar(100) NULL', 'checkbox', '0', '', '1', '0:所有用户\r\n-1:所有会员', '152', '0', '1', '1444821380', '1444821380', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1670', 'title', '活动名称', 'varchar(255) NULL', 'string', '', '', '1', '', '188', '1', '1', '1444877324', '1444877324', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1671', 'game_type', '游戏类型', 'char(10) NULL', 'radio', '1', '', '1', '1:刮刮乐\r\n2:大转盘\r\n3:砸金蛋\r\n4:九宫格', '188', '1', '1', '1444877425', '1444877425', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1672', 'status', '状态', 'char(10) NULL', 'radio', '1', '', '1', '1:开启\r\n0:禁用', '188', '0', '1', '1444877482', '1444877468', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1673', 'start_time', '开始时间', 'int(10) NULL', 'datetime', '', '', '1', '', '188', '1', '1', '1444877509', '1444877509', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1674', 'end_time', '结束时间', 'int(10) NULL', 'datetime', '', '', '1', '', '188', '1', '1', '1444877530', '1444877530', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1675', 'day_attend_limit', '每人每天抽奖次数', 'int(10) NULL', 'num', '0', '0，则不限制，超过此限制点击抽奖，系统会提示“您今天的抽奖次数已经用完!”', '1', '', '188', '0', '1', '1444879540', '1444878111', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1676', 'attend_limit', '每人总共抽奖次数', 'int(10) NULL', 'num', '0', '0，则不限制；否则必须>=每人每天抽奖次数，超过此限制点击抽奖，系统会提示“您的所有抽奖次数已用完!”', '1', '', '188', '0', '1', '1444879552', '1444878167', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1677', 'day_win_limit', '每人每天中奖次数', 'int(10) NULL', 'num', '0', '0，则不限制，超过此限制点击抽奖，抽奖者将无概率中奖', '1', '', '188', '0', '1', '1444879608', '1444878254', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1678', 'win_limit', '每人总共中奖次数', 'int(10) NULL', 'num', '0', '0，则不限制；否则必须>=每人每天中奖次数，超过此限制点击抽奖，抽奖者将无概率中奖', '1', '', '188', '0', '1', '1444879656', '1444878336', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1679', 'day_winners_count', '每天最多中奖人数', 'int(10) NULL', 'num', '0', '0，则不限制，超过此限制时，系统会提示“今天奖品已抽完，明天再来吧!”', '1', '', '188', '0', '1', '1444879673', '1444878419', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1680', 'url', '关注链接', 'varchar(300) NULL', 'string', '', '', '0', '', '188', '0', '1', '1445068488', '1444878621', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1681', 'remark', '活动说明', 'text NULL', 'textarea', '', '', '1', '', '188', '0', '1', '1444878676', '1444878676', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1682', 'keyword', '微信关键词', 'varchar(255) NULL', 'string', '', '', '1', '', '188', '1', '1', '1444878722', '1444878722', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1683', 'attend_num', '参与总人数', 'int(10) NULL', 'num', '0', '', '0', '', '188', '0', '1', '1444878774', '1444878774', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1684', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '0', '', '188', '0', '1', '1444878837', '1444878837', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1685', 'manager_id', '管理员id', 'int(10) NULL', 'num', '', '', '0', '', '188', '0', '1', '1444878900', '1444878900', '', '3', '', 'regex', 'get_mid', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1686', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '0', '', '82', '0', '1', '1444879923', '1444879923', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1687', 'coupon_id', '选择赠送券', 'char(50) NULL', 'select', '', '', '1', '', '82', '0', '1', '1444893831', '1444881398', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1688', 'money', '返现金额', 'float(10) NULL', 'num', '', '', '1', '', '82', '0', '1', '1444882709', '1444881428', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1691', 'award_id', '奖品id', 'int(10) NULL', 'num', '', '', '1', '', '189', '1', '1', '1444901378', '1444900999', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1692', 'games_id', '抽奖游戏id', 'int(10) NULL', 'num', '', '', '1', '', '189', '1', '1', '1444901386', '1444901037', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1744', 'remark', '备注', 'text NULL', 'textarea', '', '', '1', '', '48', '0', '1', '1445056786', '1445056786', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1690', 'aim_table', '活动标识', 'varchar(255) NULL', 'string', '', '', '0', '', '82', '0', '1', '1444883071', '1444883071', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1693', 'grade', '中奖等级', 'varchar(255) NULL', 'string', '', '', '1', '', '189', '1', '1', '1444901399', '1444901079', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1694', 'num', '奖品数量', 'int(10) NULL', 'num', '', '', '1', '', '189', '1', '1', '1444901364', '1444901364', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1695', 'max_count', '最多抽奖', 'int(10) NULL', 'num', '', 'n次,把奖品发放完, 不能小于奖品数量', '1', '', '189', '0', '1', '1444901486', '1444901486', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1696', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '0', '', '189', '0', '1', '1444901512', '1444901512', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1697', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '190', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1698', 'cTime', '发布时间', 'int(10) UNSIGNED NULL', 'datetime', '', '', '0', '', '190', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1699', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '190', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1700', 'password', '微预约密码', 'varchar(255) NULL', 'string', '', '如要用户输入密码才能进入微预约，则填写此项。否则留空，用户可直接进入微预约', '0', '', '190', '0', '1', '1396871497', '1396672643', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1743', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '0', '', '38', '0', '1', '1444986759', '1444986759', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1702', 'jump_url', '提交后跳转的地址', 'varchar(255) NULL', 'string', '', '要以http://开头的完整地址，为空时不跳转', '1', '', '190', '0', '1', '1402458121', '1399800276', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1703', 'content', '详细介绍', 'text NULL', 'editor', '', '可不填', '1', '', '190', '0', '1', '1396865295', '1396865295', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1704', 'finish_tip', '用户提交后提示内容', 'text NULL', 'textarea', '', '为空默认为：提交成功，谢谢参与', '1', '', '190', '0', '1', '1396676366', '1396673689', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1705', 'can_edit', '是否允许编辑', 'tinyint(2) NULL', 'bool', '0', '用户提交预约是否可以再编辑', '1', '0:不允许\r\n1:允许', '190', '0', '1', '1396688624', '1396688624', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1706', 'intro', '封面简介', 'text NULL', 'textarea', '', '', '1', '', '190', '1', '1', '1439371986', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1707', 'mTime', '修改时间', 'int(10) NULL', 'datetime', '', '', '0', '', '190', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1708', 'cover', '封面图片', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '190', '1', '1', '1439372018', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1710', 'template', '模板', 'varchar(255) NULL', 'string', 'default', '', '1', '', '190', '0', '1', '1431661124', '1431661124', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1742', 'aim_table', '活动标识', 'varchar(255) NULL', 'string', '', '', '0', '', '48', '0', '1', '1444966689', '1444966689', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1741', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '0', '', '48', '0', '1', '1444966581', '1444966581', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1711', 'is_show', '是否显示', 'tinyint(2) NULL', 'select', '1', '是否显示在微预约中', '1', '1:显示\r\n0:不显示', '191', '0', '1', '1396848437', '1396848437', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1712', 'reserve_id', '微预约ID', 'int(10) UNSIGNED NULL', 'num', '', '', '4', '', '191', '0', '1', '1396710040', '1396690613', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1713', 'error_info', '出错提示', 'varchar(255) NULL', 'string', '', '验证不通过时的提示语', '1', '', '191', '0', '1', '1396685920', '1396685920', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1714', 'sort', '排序号', 'int(10) UNSIGNED NULL', 'num', '0', '值越小越靠前', '1', '', '191', '0', '1', '1396685825', '1396685825', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1715', 'validate_rule', '正则验证', 'varchar(255) NULL', 'string', '', '为空表示不作验证', '1', '', '191', '0', '1', '1396685776', '1396685776', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1716', 'is_must', '是否必填', 'tinyint(2) NULL', 'bool', '', '用于自动验证', '1', '0:否\r\n1:是', '191', '0', '1', '1396685579', '1396685579', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1717', 'remark', '字段备注', 'varchar(255) NULL', 'string', '', '用于微预约中的提示', '1', '', '191', '0', '1', '1396685482', '1396685482', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1719', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '191', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1720', 'value', '默认值', 'varchar(255) NULL', 'string', '', '字段的默认值', '1', '', '191', '0', '1', '1396685291', '1396685291', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1721', 'title', '字段标题', 'varchar(255) NOT NULL', 'string', '', '请输入字段标题，用于微预约显示', '1', '', '191', '1', '1', '1396676830', '1396676830', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1722', 'mTime', '修改时间', 'int(10) NULL', 'datetime', '', '', '0', '', '191', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1723', 'extra', '参数', 'text NULL', 'textarea', '', '字段类型为单选、多选、下拉选择和级联选择时的定义数据，其它字段类型为空', '1', '', '191', '0', '1', '1396835020', '1396685105', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1724', 'type', '字段类型', 'char(50) NOT NULL', 'select', 'string', '用于微预约中的展示方式', '1', 'string:单行输入\r\ntextarea:多行输入\r\nradio:单选\r\ncheckbox:多选\r\nselect:下拉选择\r\ndatetime:时间\r\npicture:上传图片', '191', '1', '1', '1396871262', '1396683600', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1725', 'reserve_id', '微预约ID', 'int(10) UNSIGNED NULL', 'num', '', '', '4', '', '192', '0', '1', '1396710064', '1396688308', '', '3', '', 'regex', '', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1726', 'value', '微预约值', 'text NULL', 'textarea', '', '', '0', '', '192', '0', '1', '1396688355', '1396688355', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1727', 'cTime', '增加时间', 'int(10) NULL', 'datetime', '', '', '0', '', '192', '0', '1', '1396688434', '1396688434', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1728', 'openid', 'OpenId', 'varchar(255) NULL', 'string', '', '', '0', '', '192', '0', '1', '1396688187', '1396688187', '', '3', '', 'regex', 'get_openid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1729', 'uid', '用户ID', 'int(10) NULL', 'num', '', '', '0', '', '192', '0', '1', '1396688042', '1396688042', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1730', 'token', 'Token', 'varchar(255) NULL', 'string', '', '', '0', '', '192', '0', '1', '1396690911', '1396690911', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('1731', 'status', '状态', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:已禁用\r\n1:已开启', '190', '0', '1', '1444917938', '1444917938', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1732', 'start_time', '报名开始时间', 'int(10) NULL', 'datetime', '', '', '1', '', '190', '0', '1', '1444959115', '1444959115', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1733', 'end_time', '报名结束时间', 'int(10) NULL', 'datetime', '', '', '1', '', '190', '0', '1', '1444959142', '1444959142', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1734', 'pay_online', '是否支持在线支付', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:否\r\n1:是', '190', '0', '1', '1444959225', '1444959225', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1735', 'reserve_id', '预约活动ID', 'int(10) NULL', 'num', '', '', '0', '', '193', '0', '1', '1444962084', '1444962084', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1736', 'name', '名称', 'varchar(100) NULL', 'string', '', '', '0', '', '193', '0', '1', '1444962123', '1444962123', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1737', 'money', '报名费用', 'decimal(11,2) NULL', 'num', '0', '', '0', '', '193', '0', '1', '1444962160', '1444962160', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1738', 'max_limit', '最大预约数', 'int(10) NULL', 'num', '0', '为空时表示不限制', '0', '', '193', '0', '1', '1444962264', '1444962198', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1739', 'init_count', '初始化预约数', 'int(10) NULL', 'num', '0', '', '0', '', '193', '0', '1', '1444962246', '1444962246', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1740', 'join_count', '参加人数', 'int(10) NULL', 'num', '0', '', '0', '', '193', '0', '1', '1444962764', '1444962764', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1755', 'sort', '序号', 'int(10) NULL', 'num', '', '', '1', '', '194', '0', '1', '1445080918', '1445080918', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1754', 'help_id', '活动ID', 'int(10) NULL', 'num', '', '', '0', '', '194', '0', '1', '1445080858', '1445080858', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1747', 'prize_num', '大礼包数量', 'int(10) NULL', 'num', '', '', '1', '', '155', '0', '1', '1445078232', '1445057624', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1752', 'share_title', '分享标题', 'varchar(100) NULL', 'string', '', '', '1', '', '155', '0', '1', '1445078427', '1445078427', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1749', 'status', '是否开启', 'tinyint(2) NULL', 'bool', '1', '', '1', '0:禁用\r\n1:启用', '155', '0', '1', '1445072096', '1445072096', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1750', 'collect_tips', '领取说明', 'text NULL', 'textarea', '', '', '1', '', '155', '0', '1', '1445072703', '1445072703', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1796', 'join_count', '领取数量', 'int(10) NULL', 'num', '0', '', '1', '', '156', '0', '1', '1445240488', '1445240488', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1798', 'type', '充值方式', 'tinyint(2) NULL', 'bool', '1', '', '0', '0:系统自动\r\n1:管理员手工', '174', '0', '1', '1445251928', '1445251928', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1799', 'remark', '备注', 'text NULL', 'textarea', '', '', '0', '', '174', '0', '1', '1445251962', '1445251962', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1800', 'uid', '用户ID', 'int(10) NULL', 'num', '', '', '0', '', '174', '0', '1', '1445252123', '1445252123', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1803', 'uid', '用户uid', 'int(10) NULL', 'num', '', '', '0', '', '60', '0', '1', '1445255505', '1445255505', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1802', 'aim_id', 'aim_id', 'int(10) NULL', 'num', '', '', '0', '', '60', '0', '1', '1445253482', '1445253482', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1804', 'is_pay', '是否支付', 'int(10) NULL', 'num', '0', '', '0', '', '192', '0', '1', '1445258123', '1445258123', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1823', 'is_material', '设置为文本素材', 'int(10) NULL', 'num', '0', '', '0', '0:不设置\r\n1:设置', '103', '0', '1', '1445497359', '1445497359', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1824', 'admin_uid', '核销管理员ID', 'int(10) NULL', 'num', '', '', '0', '', '81', '0', '1', '1445504807', '1445504807', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1839', 'msgtype', '消息类型', 'varchar(255) NULL', 'string', '', '', '1', '', '18', '0', '1', '1445833955', '1445833955', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1840', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '1', '', '18', '0', '1', '1445834006', '1445834006', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1841', 'appmsg_id', '图文id', 'int(10) NULL', 'num', '', '', '1', '', '18', '0', '1', '1445840292', '1445834101', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1842', 'voice_id', '语音id', 'int(10) NULL', 'num', '', '', '1', '', '18', '0', '1', '1445834144', '1445834144', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1843', 'video_id', '视频id', 'int(10) NULL', 'num', '', '', '1', '', '18', '0', '1', '1445834174', '1445834174', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1851', 'cTime', '群发时间', 'int(10) NULL', 'datetime', '', '', '1', '', '18', '0', '1', '1445856491', '1445856442', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1852', 'is_verify', '投票是否需要填写验证码', 'tinyint(2) NULL', 'bool', '0', '防止刷票行为时需要开启', '1', '0:不需要\r\n1:需要', '163', '0', '1', '1446000352', '1445997031', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1860', 'is_del', '是否删除', 'int(10) NULL', 'num', '0', '', '0', '', '152', '0', '1', '1446119564', '1446119564', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1861', 'is_del', '是否删除', 'int(10) NULL', 'num', '0', '', '0', '', '143', '0', '1', '1446119655', '1446119655', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1863', 'scan_code', '核销码', 'varchar(255) NULL', 'string', '', '', '1', '', '48', '0', '1', '1446202559', '1446202559', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('1868', 'img', '门店展示图', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '153', '0', '1', '1447060275', '1447060275', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11182', 'keyword', '关键词', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '1134', '1', '1', '1396624337', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11183', 'keyword_type', '关键词匹配类型', 'tinyint(2) NOT NULL', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配', '1134', '1', '1', '1396624426', '1396061765', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11184', 'title', '试卷标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '1134', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11185', 'intro', '封面简介', 'text NOT NULL', 'textarea', '', '', '1', '', '1134', '0', '1', '1396624505', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11186', 'mTime', '修改时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '1134', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11187', 'cover', '封面图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '1134', '0', '1', '1396624534', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11188', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '1134', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11189', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '1134', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11190', 'finish_tip', '结束语', 'text NOT NULL', 'string', '', '为空默认为：考试完成，谢谢参与', '1', '', '1134', '0', '1', '1447646362', '1396953940', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11191', 'start_time', '考试开始时间', 'int(10) NULL', 'datetime', '', '为空表示什么时候开始都可以', '2', '', '1134', '0', '1', '1447752638', '1397036762', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11192', 'end_time', '考试结束时间', 'int(10) NULL', 'datetime', '', '为空表示不限制结束时间', '2', '', '1134', '0', '1', '1447753072', '1397036831', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11252', 'image_material', '素材图片id', 'int(10) NULL', 'num', '', '', '0', '', '11', '0', '1', '1447738833', '1447738833', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11193', 'title', '题目标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '1135', '1', '1', '1397037377', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11194', 'intro', '题目描述', 'text NOT NULL', 'textarea', '', '', '1', '', '1135', '0', '1', '1396954176', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11195', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '1135', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11196', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '1135', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11197', 'is_must', '是否必填', 'tinyint(2) NOT NULL', 'bool', '1', '', '0', '0:否\r\n1:是', '1135', '0', '1', '1397035513', '1396954649', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11198', 'extra', '参数', 'text NOT NULL', 'textarea', '', '每个选项换一行，每项输入格式如：A:男人', '1', '', '1135', '0', '1', '1397036210', '1396954558', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11199', 'type', '题目类型', 'char(50) NOT NULL', 'radio', 'radio', '', '1', 'radio:单选题\r\ncheckbox:多选题', '1135', '1', '1', '1397036281', '1396954463', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11200', 'exam_id', 'exam_id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '1135', '1', '1', '1396954240', '1396954240', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11201', 'sort', '排序号', 'int(10) UNSIGNED NOT NULL', 'num', '0', '值越小越靠前', '1', '', '1135', '0', '1', '1396955010', '1396955010', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11202', 'score', '分值', 'int(10) UNSIGNED NOT NULL', 'num', '0', '考生答对此题的得分数', '1', '', '1135', '0', '1', '1397035609', '1397035609', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11203', 'answer', '标准答案', 'varchar(255) NOT NULL', 'string', '', '多个答案用空格分开，如： A B C', '1', '', '1135', '0', '1', '1397035889', '1397035889', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11204', 'answer', '回答内容', 'text NOT NULL', 'textarea', '', '', '0', '', '1136', '0', '1', '1396955766', '1396955766', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11205', 'openid', 'OpenId', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '1136', '0', '1', '1396955581', '1396955581', '', '3', '', 'regex', 'get_openid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11206', 'uid', '用户UID', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '1136', '0', '1', '1396955530', '1396955530', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11207', 'question_id', 'question_id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '1136', '1', '1', '1396955412', '1396955392', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11208', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '1136', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11209', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '1136', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11210', 'exam_id', 'exam_id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '1136', '1', '1', '1396955403', '1396955369', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11211', 'score', '得分', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '1136', '0', '1', '1397040133', '1397040133', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11212', 'keyword', '关键词', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '1137', '1', '1', '1396624337', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11213', 'keyword_type', '关键词匹配类型', 'tinyint(2) NOT NULL', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配', '1137', '1', '1', '1396624426', '1396061765', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11214', 'title', '问卷标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '1137', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11215', 'intro', '封面简介', 'text NOT NULL', 'textarea', '', '', '1', '', '1137', '0', '1', '1396624505', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11216', 'mTime', '修改时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '1137', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11217', 'cover', '封面图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '1137', '0', '1', '1396624534', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11218', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '1137', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11219', 'finish_tip', '评论语', 'text NOT NULL', 'textarea', '', '详细说明见上面的提示，配置格式：[0-59]不合格', '1', '', '1137', '0', '1', '1397142371', '1396953940', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11220', 'title', '题目标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '1138', '1', '1', '1397037377', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11221', 'intro', '题目描述', 'text NOT NULL', 'textarea', '', '', '1', '', '1138', '0', '1', '1396954176', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11222', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '1138', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11223', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '1138', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11224', 'is_must', '是否必填', 'tinyint(2) NOT NULL', 'bool', '1', '', '0', '0:否\r\n1:是', '1138', '0', '1', '1397035513', '1396954649', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11225', 'extra', '参数', 'text NOT NULL', 'textarea', '', '输入格式见上面的提示', '1', '', '1138', '0', '1', '1397142592', '1396954558', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11226', 'type', '题目类型', 'char(50) NOT NULL', 'radio', 'radio', '', '0', 'radio:单选题', '1138', '1', '1', '1397142548', '1396954463', '', '3', '', 'regex', 'radio', '1', 'string');
INSERT INTO `wp_attribute` VALUES ('11227', 'test_id', 'test_id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '1138', '1', '1', '1396954240', '1396954240', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11228', 'sort', '排序号', 'int(10) UNSIGNED NOT NULL', 'num', '0', '值越小越靠前', '1', '', '1138', '0', '1', '1396955010', '1396955010', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11229', 'answer', '回答内容', 'text NOT NULL', 'textarea', '', '', '0', '', '1139', '0', '1', '1396955766', '1396955766', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11230', 'openid', 'OpenId', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '1139', '0', '1', '1396955581', '1396955581', '', '3', '', 'regex', 'get_openid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11231', 'uid', '用户UID', 'int(10) NOT NULL', 'num', '', '', '0', '', '1139', '0', '1', '1396955530', '1396955530', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11232', 'question_id', 'question_id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '1139', '1', '1', '1396955412', '1396955392', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11233', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '1139', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11234', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '1139', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11235', 'test_id', 'test_id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '1139', '1', '1', '1396955403', '1396955369', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11236', 'score', '得分', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '1139', '0', '1', '1397040133', '1397040133', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11242', 'is_use', '可否使用', 'int(10) NULL', 'num', '1', '', '0', '0:不可用\r\n1:可用', '149', '0', '1', '1447405173', '1447403730', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11243', 'aim_id', '添加来源标识id', 'int(10) NULL', 'num', '', '', '0', '', '149', '0', '1', '1447404930', '1447404930', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11244', 'aim_table', '来源表名', 'varchar(255) NULL', 'string', '', '', '0', '', '149', '0', '1', '1447901430', '1447405156', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11245', 'is_use', '可否使用', 'int(10) NULL', 'num', '1', '', '0', '0:不可用\r\n1:可用', '16', '0', '1', '1447405234', '1447405234', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11246', 'aim_id', '添加来源标识id', 'int(10) NULL', 'num', '', '', '0', '', '16', '0', '1', '1447405283', '1447405283', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11247', 'aim_table', '来源表名', 'varchar(255) NULL', 'string', '', '', '0', '', '16', '0', '1', '1447901243', '1447405301', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11248', 'is_use', '可否使用', 'int(10) NULL', 'num', '1', '', '0', '0:不可用\r\n1:可用', '17', '0', '1', '1447405553', '1447405510', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11249', 'aim_id', '添加来源标识id', 'int(10) NULL', 'num', '', '', '0', '', '17', '0', '1', '1447405545', '1447405545', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11250', 'aim_table', '来源表名', 'varchar(255) NULL', 'string', '', '', '0', '', '17', '0', '1', '1447405577', '1447405577', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11269', 'is_del', '是否删除', 'int(10) NULL', 'num', '0', '', '0', '', '194', '0', '1', '1462331012', '1462331012', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11288', 'name', '分类名称', 'varchar(255) NULL', 'string', '', '', '1', '', '1147', '1', '1', '1465976454', '1463800258', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11290', 'cid', '所属分类', 'varchar(100) NULL', 'dynamic_select', '', '', '1', 'table=weiba_category&value_field=id&title_field=name', '1148', '0', '1', '1463818112', '1463802336', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11291', 'weiba_name', '版块名称', 'varchar(255) NULL', 'string', '', '', '1', '', '1148', '1', '1', '1463802421', '1463802421', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11292', 'uid', '创建者ID', 'int(10) NULL', 'num', '', '', '0', '', '1148', '0', '1', '1463802459', '1463802459', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11293', 'ctime', '创建时间', 'int(10) NULL', 'datetime', '', '', '0', '', '1148', '0', '1', '1463802489', '1463802489', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11294', 'logo', '版块图标', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '1148', '0', '1', '1463802555', '1463802555', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11295', 'intro', '版块说明', 'text NULL', 'textarea', '', '', '1', '', '1148', '0', '1', '1463818545', '1463802597', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11296', 'who_can_post', '发帖权限', 'tinyint(1) NULL', 'bool', '0', '', '1', '0:所有人\r\n1:仅成员\r\n2:版块管理员 \r\n3:版块圈主', '1148', '0', '1', '1463818512', '1463802689', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11297', 'who_can_reply', '回帖权限', 'tinyint(1) NULL', 'bool', '0', '', '0', '0:所有人\r\n1:仅成员', '1148', '0', '1', '1463818522', '1463802745', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11298', 'follower_count', '成员数', 'int(10) NULL', 'num', '0', '', '0', '', '1148', '0', '1', '1463802873', '1463802873', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11299', 'thread_count', '帖子数', 'int(10) NULL', 'num', '0', '', '0', '', '1148', '0', '1', '1463802904', '1463802904', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11300', 'admin_uid', '版主', 'varchar(255) NULL', 'users', '', '', '1', '', '1148', '0', '1', '1464408355', '1463802951', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11301', 'recommend', '是否设置为推荐', 'tinyint(1) NULL', 'bool', '0', '', '1', '0:否\r\n1:是', '1148', '0', '1', '1463803007', '1463803007', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11302', 'status', '审核状态', 'tinyint(1) NULL', 'bool', '1', '', '0', '0:未通过\r\n1:已通过', '1148', '0', '1', '1463828775', '1463803060', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11303', 'is_del', '是否删除', 'tinyint(1) NULL', 'bool', '0', '', '0', '', '1148', '0', '1', '1463803123', '1463803123', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11304', 'notify', '版块公告', 'text NULL', 'textarea', '', '', '1', '', '1148', '0', '1', '1463818189', '1463803190', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11305', 'avatar_big', 'avatar_big', 'text NULL', 'textarea', '', '', '0', '', '1148', '0', '1', '1463803240', '1463803240', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11306', 'avatar_middle', 'avatar_middle', 'text NULL', 'textarea', '', '', '0', '', '1148', '0', '1', '1463803268', '1463803268', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11307', 'new_count', '最新帖子数', 'int(10) NULL', 'num', '0', '', '0', '', '1148', '0', '1', '1463803307', '1463803307', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11308', 'new_day', 'new_day', 'date', 'date', '', '', '0', '', '1148', '0', '1', '1463803381', '1463803381', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11309', 'info', '申请附件信息', 'varchar(255) NULL', 'string', '', '', '0', '', '1148', '0', '1', '1463803443', '1463803443', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11311', 'weiba_id', '所属版块', 'int(10) NULL', 'dynamic_select', '', '', '1', 'table=weiba&value_field=id&title_field=weiba_name', '1149', '0', '1', '1463804162', '1463804162', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11312', 'post_uid', '发表者uid', 'int(10) NULL', 'num', '', '', '0', '', '1149', '0', '1', '1463804187', '1463804187', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11313', 'title', '帖子标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '1149', '1', '1', '1464345088', '1463804216', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11314', 'content', '帖子内容', 'text NOT  NULL', 'editor', '', '', '1', '', '1149', '1', '1', '1463804251', '1463804251', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11315', 'post_time', '发表时间', 'int(10) NULL', 'datetime', '', '', '0', '', '1149', '0', '1', '1463804276', '1463804276', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11316', 'reply_count', '回复数', 'int(10) NULL', 'num', '0', '', '0', '', '1149', '0', '1', '1463804303', '1463804303', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11317', 'read_count', '浏览数', 'int(10) NULL', 'num', '0', '', '0', '', '1149', '0', '1', '1463804334', '1463804334', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11318', 'last_reply_uid', '最后回复人', 'varchar(50) NULL', 'string', '0', '', '0', '', '1149', '0', '1', '1463804385', '1463804375', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11319', 'last_reply_time', '最后回复时间', 'int(10) NULL', 'datetime', '0', '', '0', '', '1149', '0', '1', '1463804409', '1463804409', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11320', 'digest', '全局精华', 'tinyint(1) NULL', 'bool', '0', '', '0', '0:否\r\n1:是', '1149', '0', '1', '1463804452', '1463804452', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11321', 'top', '置顶帖', 'tinyint(2) NULL', 'bool', '0', '', '0', '0:否\r\n1:吧内\r\n2:全局', '1149', '0', '1', '1463804490', '1463804490', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11322', 'lock', '锁帖', 'tinyint(1) NULL', 'bool', '0', '不允许回复', '0', '0:否\r\n1:是', '1149', '0', '1', '1463804536', '1463804536', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11323', 'recommend', '是否设为推荐', 'tinyint(1) NULL', 'bool', '0', '', '0', '0:否\r\n1:是', '1149', '0', '1', '1463804583', '1463804583', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11324', 'recommend_time', '设为推荐的时间', 'int(10) NULL', 'datetime', '0', '', '0', '', '1149', '0', '1', '1463804636', '1463804636', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11325', 'is_del', '是否已删除', 'tinyint(2) NULL', 'bool', '0', '', '0', '0:否\r\n1:是', '1149', '0', '1', '1463804676', '1463804676', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11326', 'reply_all_count', '全部评论数目', 'int(11) NULL', 'num', '0', '', '0', '', '1149', '0', '1', '1463804754', '1463804754', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11327', 'attach', 'attach', 'varchar(255) NULL', 'file', '', '', '0', '', '1149', '0', '1', '1463804814', '1463804814', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11328', 'praise', '喜欢', 'int(10) NULL', 'num', '0', '', '0', '', '1149', '0', '1', '1463804855', '1463804845', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11329', 'from', '客户端类型', 'tinyint(1) NULL', 'bool', '1', '', '0', '0:网站\r\n1:手机网页版\r\n2:android\r\n3:iphone', '1149', '0', '1', '1463804926', '1463804926', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11330', 'top_time', 'top_time', 'int(10) NULL', 'num', '0', '', '0', '', '1149', '0', '1', '1463804947', '1463804947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11331', 'is_index', '是否推荐到首页', 'tinyint(2) NULL', 'bool', '0', '', '0', '0:否\r\n1:是', '1149', '0', '1', '1463804998', '1463804998', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11332', 'index_img', 'index_img', 'int(10) UNSIGNED NULL', 'picture', '', '', '0', '', '1149', '0', '1', '1463805024', '1463805024', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11333', 'is_index_time', 'is_index_time', 'int(10) NULL', 'num', '', '', '0', '', '1149', '0', '1', '1463805038', '1463805038', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11334', 'img_ids', 'img_ids', 'varchar(255) NULL', 'string', '', '', '0', '', '1149', '0', '1', '1463805051', '1463805051', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11335', 'tag_id', '标签', 'int(10) NULL', 'num', '0', '', '0', '', '1149', '0', '1', '1463805075', '1463805075', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11336', 'index_order', '首页帖子排序', 'int(10) NULL', 'num', '0', '', '0', '', '1149', '0', '1', '1463805101', '1463805101', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11337', 'is_event', '类型', 'tinyint(2) NULL', 'bool', '0', '', '0', '0:话题\r\n1:活动', '1149', '0', '1', '1463805144', '1463805144', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11338', 'globle_recommend', '推荐到全站', 'tinyint(2) NULL', 'bool', '0', '', '0', '0:否\r\n1:是', '1149', '0', '1', '1463805178', '1463805178', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11339', 'token', 'token', 'varchar(100) NULL', 'string', '', '', '0', '', '1147', '0', '1', '1463820483', '1463820483', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11340', 'token', 'token', 'varchar(100) NULL', 'string', '', '', '0', '', '1148', '0', '1', '1463820521', '1463820521', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11341', 'token', 'token', 'varchar(100) NULL', 'string', '', '', '0', '', '1149', '0', '1', '1463820555', '1463820555', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11342', 'title', '标签名称', 'varchar(50) NULL', 'string', '', '', '1', '', '1150', '1', '1', '1463990154', '1463990154', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11343', 'token', 'token', 'varchar(100) NULL', 'string', '', '', '0', '', '1150', '0', '1', '1463990184', '1463990184', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11344', 'uid', 'uid', 'int(10) NULL', 'num', '', '', '0', '', '1151', '0', '1', '1463992933', '1463992933', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11345', 'tag_id', 'tag_id', 'int(10) NULL', 'num', '', '', '0', '', '1151', '0', '1', '1463992951', '1463992951', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11348', 'group_id', '用户组', 'int(10) NULL', 'dynamic_select', '0', '', '1', 'table=auth_group&value_field=id&title_field=title&first_option=不选择', '1152', '0', '1', '1463999863', '1463999863', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11347', 'action_name', '类型', 'varchar(30) NOT NULL', 'bool', 'QR_SCENE', '临时二维码最长有效期是30天', '1', 'QR_SCENE:临时二维码\r\nQR_LIMIT_SCENE:永久二维码', '1152', '1', '1', '1463999695', '1463999695', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11349', 'tag_ids', '用户标签', 'varchar(255) NULL', 'dynamic_checkbox', '', '', '1', 'table=user_tag', '1152', '0', '1', '1464002088', '1464000098', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11350', 'qr_code', '二维码', 'varchar(255) NULL', 'string', '', '', '0', '', '1152', '0', '1', '1464056435', '1464056435', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11352', 'material', '扫码后的回复内容', 'varchar(50) NULL', 'material', '', '', '1', '', '1152', '0', '1', '1464060736', '1464060509', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11353', 'voice_id', '语音素材id', 'int(10) NULL', 'num', '', '', '4', '', '11', '0', '1', '1464157587', '1464147769', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11354', 'video_id', '视频素材id', 'int(10) NULL', 'num', '', '', '4', '', '11', '0', '1', '1464157579', '1464147817', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11356', 'uid', '用户选择', 'int(10) NULL', 'user', '', '', '1', '', '1153', '1', '1', '1445325351', '1443066688', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11357', 'truename', '真实姓名', 'varchar(255) NULL', 'string', '', '', '1', '', '1153', '1', '1', '1445325390', '1443066736', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11358', 'mobile', '手机号', 'varchar(255) NULL', 'string', '', '', '1', '', '1153', '1', '1', '1445325401', '1443066833', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11359', 'role', '授权列表', 'varchar(100) NULL', 'checkbox', '0', '', '1', '1:微信客服\r\n2:扫码验证\r\n3:微订单接单', '1153', '1', '1', '1445325510', '1443067065', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11360', 'enable', '是否启用', 'int(10) NULL', 'radio', '1', '', '1', '0:禁用\r\n1:启用', '1153', '0', '1', '1443067721', '1443067149', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11361', 'token', 'token', 'varchar(255) NULL', 'string', '', '', '0', '', '1153', '0', '1', '1443067647', '1443067638', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11364', 'mobile', '手机号码', 'varchar(50) NULL', 'string', '', '', '1', '', '1154', '1', '1', '1423477580', '1423477580', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11365', 'city', '城市', 'varchar(255) NULL', 'cascade', '', '', '1', 'module=city', '1154', '1', '1', '1423477660', '1423477660', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11366', 'address', '具体地址', 'varchar(255) NULL', 'string', '', '', '1', '', '1154', '1', '1', '1423477681', '1423477681', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11367', 'is_use', '是否设置为默认', 'tinyint(2) NULL', 'bool', '0', '', '1', '0:否\r\n1:是', '1154', '0', '1', '1423536697', '1423477729', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11368', 'give_type', '发放方式', 'tinyint(2) NOT NULL', 'bool', '0', '人工发放是指管理员要会员管理列表手工进行发放', '0', '0:自动发放\r\n1:人工发放', '1155', '0', '1', '1395487734', '1395486034', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11369', 'title', '优惠卷标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '1155', '0', '1', '1395485828', '1395485828', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11370', 'end_date', '结束时间', 'int(10) NULL', 'datetime', '', '', '1', '', '1155', '0', '1', '1395486188', '1395486188', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11371', 'start_date', '开始时间', 'int(10) NOT NULL', 'datetime', '', '', '1', '', '1155', '0', '1', '1395486135', '1395486135', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11372', 'content', '使用说明', 'text NOT NULL', 'editor', '', '', '1', '', '1155', '0', '1', '1395486307', '1395486307', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11373', 'cTime', '发布时间', 'int(10) NULL', 'datetime', '', '', '0', '', '1155', '0', '1', '1395486839', '1395486801', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11374', 'token', 'Token', 'varchar(100) NOT NULL', 'string', '', '', '0', '', '1155', '0', '1', '1395912079', '1395912079', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11375', 'cTime', '发布时间', 'int(10) NULL', 'datetime', '', '', '0', '', '1156', '0', '1', '1395485303', '1395485303', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11376', 'content', '通知内容', 'text NOT NULL', 'editor', '', '', '1', '', '1156', '0', '1', '1395485247', '1395485247', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11377', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '1156', '0', '1', '1395485192', '1395485192', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11378', 'token', 'Token', 'varchar(100) NOT NULL', 'string', '', '', '0', '', '1156', '0', '1', '1395911896', '1395911896', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11379', 'number', '卡号', 'varchar(50) NULL', 'string', '', '', '3', '', '1157', '0', '1', '1395484806', '1395483310', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11380', 'cTime', '加入时间', 'int(10) NULL', 'datetime', '', '', '0', '', '1157', '0', '1', '1395484366', '1395484366', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11381', 'phone', '手机号', 'varchar(30) NULL', 'string', '', '', '1', '', '1157', '0', '1', '1395483248', '1395483248', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11382', 'username', '姓名', 'varchar(100) NULL', 'string', '', '', '1', '', '1157', '0', '1', '1395483048', '1395483048', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('11383', 'uid', '用户UID', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '1157', '0', '1', '1395482973', '1395482973', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('11384', 'token', 'Token', 'varchar(100) NOT NULL', 'string', '', '', '0', '', '1157', '0', '1', '1395973788', '1395912028', '', '3', '', 'regex', 'get_token', '1', 'function');

-- -----------------------------
-- Table structure for `wp_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `wp_auth_extend`;
;

-- -----------------------------
-- Records of `wp_auth_extend`
-- -----------------------------
INSERT INTO `wp_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `wp_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `wp_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `wp_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `wp_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `wp_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `wp_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `wp_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `wp_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `wp_auth_group`;
;

-- -----------------------------
-- Records of `wp_auth_group`
-- -----------------------------
INSERT INTO `wp_auth_group` VALUES ('1', '默认用户组', '', '通用的用户组', '1', '0', '1,2,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,81,82,83,84,86,87,88,89,90,91,92,93,94,95,96,97,100,102,103,105,106', '0', '', '0', '', '', '', '', '0');
INSERT INTO `wp_auth_group` VALUES ('2', '公众号粉丝组', '', '所有从公众号自动注册的粉丝用户都会自动加入这个用户组', '1', '0', '1,2,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,82,83,84,88,89,90,91,92,93,96,97,100,102,103,195', '0', '', '0', '', '', '', '', '0');
INSERT INTO `wp_auth_group` VALUES ('3', '公众号管理组', '', '公众号管理员注册时会自动加入这个用户组', '1', '0', '', '0', '', '0', '', '', '', '', '0');
INSERT INTO `wp_auth_group` VALUES ('151', '未分组', '', '', '1', '1', '', '1', 'gh_89d5cf544493', '0', '', '0', '未分组', '9', '0');
INSERT INTO `wp_auth_group` VALUES ('152', '黑名单', '', '', '1', '1', '', '1', 'gh_89d5cf544493', '0', '', '1', '黑名单', '0', '0');
INSERT INTO `wp_auth_group` VALUES ('153', '星标组', '', '', '1', '1', '', '1', 'gh_89d5cf544493', '0', '', '2', '星标组', '0', '0');
INSERT INTO `wp_auth_group` VALUES ('154', '未分组', '', '', '1', '1', '', '11', 'gh_89d5cf544493', '0', '', '0', '未分组', '9', '0');
INSERT INTO `wp_auth_group` VALUES ('155', '黑名单', '', '', '1', '1', '', '11', 'gh_89d5cf544493', '0', '', '1', '黑名单', '0', '0');
INSERT INTO `wp_auth_group` VALUES ('156', '星标组', '', '', '1', '1', '', '11', 'gh_89d5cf544493', '0', '', '2', '星标组', '0', '0');

-- -----------------------------
-- Table structure for `wp_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `wp_auth_group_access`;
;

-- -----------------------------
-- Records of `wp_auth_group_access`
-- -----------------------------
INSERT INTO `wp_auth_group_access` VALUES ('1', '1');
INSERT INTO `wp_auth_group_access` VALUES ('1', '2');
INSERT INTO `wp_auth_group_access` VALUES ('1', '3');
INSERT INTO `wp_auth_group_access` VALUES ('1', '4');
INSERT INTO `wp_auth_group_access` VALUES ('2', '154');
INSERT INTO `wp_auth_group_access` VALUES ('3', '154');
INSERT INTO `wp_auth_group_access` VALUES ('4', '154');
INSERT INTO `wp_auth_group_access` VALUES ('5', '154');
INSERT INTO `wp_auth_group_access` VALUES ('6', '154');
INSERT INTO `wp_auth_group_access` VALUES ('7', '154');
INSERT INTO `wp_auth_group_access` VALUES ('8', '154');
INSERT INTO `wp_auth_group_access` VALUES ('9', '154');
INSERT INTO `wp_auth_group_access` VALUES ('10', '154');
INSERT INTO `wp_auth_group_access` VALUES ('11', '3');

-- -----------------------------
-- Table structure for `wp_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `wp_auth_rule`;
;

-- -----------------------------
-- Records of `wp_auth_rule`
-- -----------------------------
INSERT INTO `wp_auth_rule` VALUES ('241', 'Admin/Rule/createRule', '权限节点管理', '1', '', '默认分组');
INSERT INTO `wp_auth_rule` VALUES ('242', 'Admin/AuthManager/index', '用户组管理', '1', '', '默认分组');
INSERT INTO `wp_auth_rule` VALUES ('243', 'Admin/User/index', '用户信息', '1', '', '用户管理');

-- -----------------------------
-- Table structure for `wp_auto_reply`
-- -----------------------------
DROP TABLE IF EXISTS `wp_auto_reply`;
;


-- -----------------------------
-- Table structure for `wp_business_card`
-- -----------------------------
DROP TABLE IF EXISTS `wp_business_card`;
;

-- -----------------------------
-- Records of `wp_business_card`
-- -----------------------------
INSERT INTO `wp_business_card` VALUES ('1', '1', '干诚远', 'H5开发工程师', '18616742186', '飞牛网', '移动触屏', 'H5', 'www.feiniu.com', '', '', 'ganchengyuan1990@163.com', '', '714375410', '', '', '', '', '', '', '', '2', 'default', 'gh_89d5cf544493');
INSERT INTO `wp_business_card` VALUES ('2', '0', '干诚远', '', '18616742186', '64646', '', '匿名', '', '', '', '', '', '', '', '', '', '', '', '', '', '1', 'default', '-1');

-- -----------------------------
-- Table structure for `wp_business_card_collect`
-- -----------------------------
DROP TABLE IF EXISTS `wp_business_card_collect`;
;


-- -----------------------------
-- Table structure for `wp_business_card_column`
-- -----------------------------
DROP TABLE IF EXISTS `wp_business_card_column`;
;


-- -----------------------------
-- Table structure for `wp_buy_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_buy_log`;
;


-- -----------------------------
-- Table structure for `wp_card_coupons`
-- -----------------------------
DROP TABLE IF EXISTS `wp_card_coupons`;
;


-- -----------------------------
-- Table structure for `wp_card_custom`
-- -----------------------------
DROP TABLE IF EXISTS `wp_card_custom`;
;

-- -----------------------------
-- Records of `wp_card_custom`
-- -----------------------------
INSERT INTO `wp_card_custom` VALUES ('1', '1', 'gh_89d5cf544493', '1467700439', '20', '0', '1', '1467648000', '1467700800', '周二有礼', '0', '周二有礼，赠送积分', '', '0', '1');
INSERT INTO `wp_card_custom` VALUES ('2', '1', 'gh_89d5cf544493', '1467701331', '10', '0', '1', '1467648000', '1467704340', 'test', '0', 'hahahahah', '', '0', '1');

-- -----------------------------
-- Table structure for `wp_card_level`
-- -----------------------------
DROP TABLE IF EXISTS `wp_card_level`;
;

-- -----------------------------
-- Records of `wp_card_level`
-- -----------------------------
INSERT INTO `wp_card_level` VALUES ('1', '慢城市民', '1000', '5000', '10', 'gh_89d5cf544493');

-- -----------------------------
-- Table structure for `wp_card_marketing`
-- -----------------------------
DROP TABLE IF EXISTS `wp_card_marketing`;
;


-- -----------------------------
-- Table structure for `wp_card_member`
-- -----------------------------
DROP TABLE IF EXISTS `wp_card_member`;
;

-- -----------------------------
-- Records of `wp_card_member`
-- -----------------------------
INSERT INTO `wp_card_member` VALUES ('3', '80001', '1467681270', '18232445667', '186', '-334', '-1', '0', '1', '', '', '0', '');
INSERT INTO `wp_card_member` VALUES ('4', '80001', '1467681388', '18616742186', '你好', '0', '-1', '0', '1', '', '', '0', '');
INSERT INTO `wp_card_member` VALUES ('5', '800001', '1467690114', '18616742186', '干诚远', '3', 'gh_89d5cf544493', '0', '1', '653324400', '', '1', '1');
INSERT INTO `wp_card_member` VALUES ('6', '800002', '1467690936', '13732201252', '你好', '8', 'gh_89d5cf544493', '0', '1', '0', '', '0', '0');

-- -----------------------------
-- Table structure for `wp_card_notice`
-- -----------------------------
DROP TABLE IF EXISTS `wp_card_notice`;
;

-- -----------------------------
-- Records of `wp_card_notice`
-- -----------------------------
INSERT INTO `wp_card_notice` VALUES ('1', '1467699931', '<section><section class=\"wxqq-borderleftcolor wxqq-borderRightcolor wxqq-bordertopcolor wxqq-borderbottomcolor\" style=\"border:5px solid #A50003;padding:5px;width:100%;\"><section class=\"wxqq-borderleftcolor wxqq-borderRightcolor wxqq-bordertopcolor wxqq-borderbottomcolor\" style=\"border:1px solid #A50003;padding:15px 20px;\"><p style=\"color:#A50003;text-align:center;border-bottom:1px solid #A50003\"><span class=\"wxqq-color\" data-brushtype=\"text\" style=\"font-size:48px\">情人节快乐</span></p><section data-style=\"color:#A50003;text-align:center;font-size:18px\" style=\"color:#A50003;text-align:center;width:96%;margin-left:5px;\"><p class=\"wxqq-color\" style=\"color:#A50003;text-align:center;font-size:18px\">happy valentine\'s day<span style=\"color:inherit; font-size:24px; line-height:1.6em; text-align:right; text-indent:2em\"></span><span style=\"color:rgb(227, 108, 9); font-size:24px; line-height:1.6em; text-align:right; text-indent:2em\"></span></p><section style=\"width:100%;\"><section><section><p style=\"color:#000;text-align:left;\">我们没有秘密，整天花前月下，别人以为我们不懂爱情，我们乐呵呵地笑大人们都太傻。</p></section></section></section></section></section></section></section><p><br/></p>', '悦慢会员卡上线', 'gh_89d5cf544493', '29', '0', '0');
INSERT INTO `wp_card_notice` VALUES ('2', '1467704810', '<p>近期福利多多，请大家多多关注</p>', '近期会有许多活动', 'gh_89d5cf544493', '6', '0', '0');

-- -----------------------------
-- Table structure for `wp_card_privilege`
-- -----------------------------
DROP TABLE IF EXISTS `wp_card_privilege`;
;

-- -----------------------------
-- Records of `wp_card_privilege`
-- -----------------------------
INSERT INTO `wp_card_privilege` VALUES ('1', '福利特权', '0', '1467681900', '1467786300', '领取福利吧哈哈', 'gh_89d5cf544493', '1');

-- -----------------------------
-- Table structure for `wp_card_recharge`
-- -----------------------------
DROP TABLE IF EXISTS `wp_card_recharge`;
;


-- -----------------------------
-- Table structure for `wp_card_recharge_condition`
-- -----------------------------
DROP TABLE IF EXISTS `wp_card_recharge_condition`;
;


-- -----------------------------
-- Table structure for `wp_card_reward`
-- -----------------------------
DROP TABLE IF EXISTS `wp_card_reward`;
;


-- -----------------------------
-- Table structure for `wp_card_score`
-- -----------------------------
DROP TABLE IF EXISTS `wp_card_score`;
;


-- -----------------------------
-- Table structure for `wp_card_vouchers`
-- -----------------------------
DROP TABLE IF EXISTS `wp_card_vouchers`;
;

-- -----------------------------
-- Records of `wp_card_vouchers`
-- -----------------------------
INSERT INTO `wp_card_vouchers` VALUES ('1', '<p>你好</p>', '', '', '', 'yueman', '', '', '105', '悦慢咖啡券', '#D54036', '#F9861F', '110', '悦慢', '', 'default', '', 'gh_89d5cf544493');

-- -----------------------------
-- Table structure for `wp_channel`
-- -----------------------------
DROP TABLE IF EXISTS `wp_channel`;
;


-- -----------------------------
-- Table structure for `wp_city`
-- -----------------------------
DROP TABLE IF EXISTS `wp_city`;
;


-- -----------------------------
-- Table structure for `wp_comment`
-- -----------------------------
DROP TABLE IF EXISTS `wp_comment`;
;


-- -----------------------------
-- Table structure for `wp_common_category`
-- -----------------------------
DROP TABLE IF EXISTS `wp_common_category`;
;


-- -----------------------------
-- Table structure for `wp_common_category_group`
-- -----------------------------
DROP TABLE IF EXISTS `wp_common_category_group`;
;


-- -----------------------------
-- Table structure for `wp_config`
-- -----------------------------
DROP TABLE IF EXISTS `wp_config`;
;

-- -----------------------------
-- Records of `wp_config`
-- -----------------------------
INSERT INTO `wp_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1430825115', '1', 'weiphp3.0', '0');
INSERT INTO `wp_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', 'weiphp是互联网+的IT综合解决方案', '9');
INSERT INTO `wp_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', 'weiphp,互联网+,微信开源开发框架', '8');
INSERT INTO `wp_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭\r\n1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1406859591', '1', '1', '1');
INSERT INTO `wp_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '6', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '2');
INSERT INTO `wp_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '苏ICP备14004339号', '9');
INSERT INTO `wp_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '2', '', '文档推荐位，推荐到多个位置KEY值相加即可', '1379053380', '1379235329', '1', '1:列表页推荐\r\n2:频道页推荐\r\n4:网站首页推荐', '3');
INSERT INTO `wp_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可见\r\n2:仅管理员可见', '4');
INSERT INTO `wp_config` VALUES ('13', 'COLOR_STYLE', '4', '后台色系', '1', 'default_color:默认\r\nblue_color:紫罗兰', '后台颜色风格', '1379122533', '1379235904', '1', 'default_color', '10');
INSERT INTO `wp_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '6', '', '配置分组', '1379228036', '1384418383', '1', '1:基本\r\n3:用户\r\n4:扫码登录\r\n5:一键绑定\r\n6:开发\r\n99:高级', '4');
INSERT INTO `wp_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '0', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '6');
INSERT INTO `wp_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '0', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '8');
INSERT INTO `wp_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功能', '0', '0:关闭草稿功能\r\n1:开启草稿功能\r\n', '新增文章时的草稿功能配置', '1379484332', '1379484591', '1', '1', '1');
INSERT INTO `wp_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '0', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '2');
INSERT INTO `wp_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '0', '', '后台数据每页显示记录数', '1379503896', '1391938052', '1', '20', '10');
INSERT INTO `wp_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '0');
INSERT INTO `wp_config` VALUES ('27', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '0', '3024-day:3024 day\r\n3024-night:3024 night\r\nambiance:ambiance\r\nbase16-dark:base16 dark\r\nbase16-light:base16 light\r\nblackboard:blackboard\r\ncobalt:cobalt\r\neclipse:eclipse\r\nelegant:elegant\r\nerlang-dark:erlang-dark\r\nlesser-dark:lesser-dark\r\nmidnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '3');
INSERT INTO `wp_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '6', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '5');
INSERT INTO `wp_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '6', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '7');
INSERT INTO `wp_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '6', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '9');
INSERT INTO `wp_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '6', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '10');
INSERT INTO `wp_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '6', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '0', '0');
INSERT INTO `wp_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox\r\n1:article/mydocument\r\n2:Category/tree\r\n3:Index/verify\r\n4:file/upload\r\n5:file/download\r\n6:user/updatePassword\r\n7:user/updateNickname\r\n8:user/submitPassword\r\n9:user/submitNickname', '0');
INSERT INTO `wp_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '0');
INSERT INTO `wp_config` VALUES ('35', 'REPLY_LIST_ROWS', '0', '回复列表每页条数', '0', '', '', '1386645376', '1387178083', '1', '20', '0');
INSERT INTO `wp_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '99', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '12');
INSERT INTO `wp_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '6', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '0', '1');
INSERT INTO `wp_config` VALUES ('38', 'WEB_SITE_VERIFY', '4', '登录验证码', '3', '0:关闭\r\n1:开启', '登录时是否需要验证码', '1378898976', '1406859544', '1', '0', '2');
INSERT INTO `wp_config` VALUES ('42', 'ACCESS', '2', '未登录时可访问的页面', '6', '', '不区分大小写', '1390656601', '1390664079', '1', 'Home/User/*\r\nHome/Index/*\r\nHome/Help/*\r\nhome/weixin/*\r\nadmin/File/*\r\nhome/File/*\r\nhome/Forum/*\r\nHome/Material/detail', '0');
INSERT INTO `wp_config` VALUES ('44', 'DEFAULT_PUBLIC_GROUP_ID', '0', '公众号默认等级ID', '0', '', '前台新增加的公众号的默认等级，值为0表示不做权限控制，公众号拥有全部插件的权限', '1393759885', '1393759981', '1', '0', '2');
INSERT INTO `wp_config` VALUES ('45', 'SYSTEM_UPDATE_REMIND', '4', '系统升级提醒', '6', '0:关闭\r\n1:开启', '开启后官方有新升级信息会及时在后台的网站设置页面头部显示升级提醒', '1393764263', '1393764263', '1', '0', '5');
INSERT INTO `wp_config` VALUES ('46', 'SYSTEM_UPDATRE_VERSION', '0', '系统升级最新版本号', '6', '', '记录当前系统的版本号，这是与官方比较是否有升级包的唯一标识，不熟悉者只勿改变其数值', '1393764702', '1394337646', '1', '20140826', '0');
INSERT INTO `wp_config` VALUES ('47', 'FOLLOW_YOUKE_UID', '0', '粉丝游客ID', '0', '', '', '1398927704', '1398927704', '1', '-984', '0');
INSERT INTO `wp_config` VALUES ('48', 'DEFAULT_PUBLIC', '0', '注册后默认可管理的公众号ID', '0', '', '可为空。配置用户注册后即可管理的公众号ID，多个时用英文逗号分割', '1398928794', '1398929088', '1', '', '3');
INSERT INTO `wp_config` VALUES ('49', 'DEFAULT_PUBLIC_CREATE_MAX_NUMB', '0', '默认用户最多可创建的公众号数', '0', '', '注册用户最多的创建数，也可以在用户管理里对每个用户设置不同的值', '1398949652', '1398950115', '1', '5', '4');
INSERT INTO `wp_config` VALUES ('50', 'COPYRIGHT', '1', '版权信息', '1', '', '', '1401018910', '1401018910', '1', '版本由圆梦云科技有限公司所有', '3');
INSERT INTO `wp_config` VALUES ('51', 'WEIPHP_STORE_LICENSE', '1', '应用商店授权许可证', '0', '', '要与 应用商店》网站信息 里的授权许可证保持一致', '1402972720', '1464689362', '1', 'ecc8d48f26160d4f89ad668ff7145e665b0aa', '0');
INSERT INTO `wp_config` VALUES ('52', 'SYSTEM_LOGO', '1', '网站LOGO的URL', '1', '', '填写LOGO的网址，为空时默认显示weiphp的logo', '1403566699', '1403566746', '1', '', '0');
INSERT INTO `wp_config` VALUES ('53', 'SYSTEM_CLOSE_REGISTER', '4', '前台注册开关', '6', '0:不关闭\r\n1:关闭', '关闭后在登录页面不再显示注册链接', '1403568006', '1403568006', '1', '0', '0');
INSERT INTO `wp_config` VALUES ('54', 'SYSTEM_CLOSE_ADMIN', '4', '后台管理开关', '0', '0:不关闭\r\n1:关闭', '关闭后在登录页面不再显示后台登录链接', '1403568006', '1464689374', '1', '0', '0');
INSERT INTO `wp_config` VALUES ('55', 'SYSTEM_CLOSE_WIKI', '4', '二次开发开关', '0', '0:不关闭\r\n1:关闭', '关闭后在登录页面不再显示二次开发链接', '1403568006', '1464689353', '1', '0', '0');
INSERT INTO `wp_config` VALUES ('56', 'SYSTEM_CLOSE_BBS', '4', '官方论坛开关', '0', '0:不关闭\r\n1:关闭', '关闭后在登录页面不再显示官方论坛链接', '1403568006', '1403568006', '1', '0', '0');
INSERT INTO `wp_config` VALUES ('57', 'LOGIN_BACKGROUP', '1', '登录界面背景图', '1', '', '请输入图片网址，为空时默认使用自带的背景图', '1403568006', '1403570059', '1', '', '0');
INSERT INTO `wp_config` VALUES ('60', 'TONGJI_CODE', '2', '第三方统计JS代码', '99', '', '', '1428634717', '1428634717', '1', '', '0');
INSERT INTO `wp_config` VALUES ('61', 'SENSITIVE_WORDS', '1', '敏感词', '1', '', '当出现有敏感词的地方，会用*号代替, (多个敏感词用 , 隔开 )', '1433125977', '1463195869', '1', 'bitch,shit', '11');
INSERT INTO `wp_config` VALUES ('63', 'PUBLIC_BIND', '4', '公众号第三方平台', '5', '0:关闭\r\n1:开启', '申请审核通过微信开放平台里的公众号第三方平台账号后，就可以开启体验了', '1434542818', '1434542818', '1', '0', '0');
INSERT INTO `wp_config` VALUES ('64', 'COMPONENT_APPID', '1', '公众号开放平台的AppID', '5', '', '公众号第三方平台开启后必填的参数', '1434542891', '1434542975', '1', '', '0');
INSERT INTO `wp_config` VALUES ('65', 'COMPONENT_APPSECRET', '1', '公众号开放平台的AppSecret', '5', '', '公众号第三方平台开启后必填的参数', '1434542936', '1434542984', '1', '', '0');
INSERT INTO `wp_config` VALUES ('62', 'REG_AUDIT', '4', '注册审核', '3', '0:需要审核\r\n1:不需要审核', '', '1439811099', '1439811099', '1', '1', '1');
INSERT INTO `wp_config` VALUES ('66', 'SCAN_LOGIN', '4', '扫码登录', '4', '0:关闭\r\n1:开启', '', '1460521364', '1463196104', '1', '0', '0');

-- -----------------------------
-- Table structure for `wp_coupon`
-- -----------------------------
DROP TABLE IF EXISTS `wp_coupon`;
;

-- -----------------------------
-- Records of `wp_coupon`
-- -----------------------------
INSERT INTO `wp_coupon` VALUES ('1', '105', '', '<p>随便拿</p>', '周年店庆', '', '1467795900', '', '1467706130', 'gh_89d5cf544493', '1467683100', '', '', '10', '1', '1', '0', '0', '', '2', '0', 'public', '', '0', '', '', '', '', '1480482000', '1467767100', '优惠商家', '', '#35a2dd', '#0dbd02', 'default', '0', '0');

-- -----------------------------
-- Table structure for `wp_coupon_shop`
-- -----------------------------
DROP TABLE IF EXISTS `wp_coupon_shop`;
;


-- -----------------------------
-- Table structure for `wp_coupon_shop_link`
-- -----------------------------
DROP TABLE IF EXISTS `wp_coupon_shop_link`;
;


-- -----------------------------
-- Table structure for `wp_credit_config`
-- -----------------------------
DROP TABLE IF EXISTS `wp_credit_config`;
;

-- -----------------------------
-- Records of `wp_credit_config`
-- -----------------------------
INSERT INTO `wp_credit_config` VALUES ('1', '关注公众号', 'subscribe', '1438587911', '100', '100', '0');
INSERT INTO `wp_credit_config` VALUES ('2', '取消关注公众号', 'unsubscribe', '1438596459', '-100', '-100', '0');
INSERT INTO `wp_credit_config` VALUES ('3', '参与投票', 'vote', '1398565597', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('4', '参与调研', 'survey', '1398565640', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('5', '参与考试', 'exam', '1398565659', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('6', '参与测试', 'test', '1398565681', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('7', '微信聊天', 'chat', '1398565740', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('8', '建议意见反馈', 'suggestions', '1398565798', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('9', '会员卡绑定', 'card_bind', '1438596438', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('10', '获取优惠卷', 'coupons', '1398565926', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('11', '访问微网站', 'weisite', '1398565973', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('12', '查看自定义回复内容', 'custom_reply', '1398566068', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('13', '填写通用表单', 'forms', '1398566118', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('14', '访问微商店', 'shop', '1398566206', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('32', '程序自由增加', 'auto_add', '1442659667', '￥', '￥', '0');
INSERT INTO `wp_credit_config` VALUES ('44', '访问微网站', 'weisite', '1467101349', '1', '1', 'gh_89d5cf544493');
INSERT INTO `wp_credit_config` VALUES ('45', '关注公众号', 'subscribe', '1467173105', '10', '10', 'gh_89d5cf544493');
INSERT INTO `wp_credit_config` VALUES ('46', '访问微网站', 'weisite', '1467633769', '5', '5', 'gh_89d5cf544493');
INSERT INTO `wp_credit_config` VALUES ('47', '参与投票', 'vote', '1467639906', '2', '2', 'gh_89d5cf544493');
INSERT INTO `wp_credit_config` VALUES ('48', '会员卡绑定', 'card_bind', '1467690362', '20', '20', 'gh_89d5cf544493');
INSERT INTO `wp_credit_config` VALUES ('15', '转发文章', 'resend_page', '1467639908', '2', '2', 'gh_89d5cf544493');

-- -----------------------------
-- Table structure for `wp_credit_data`
-- -----------------------------
DROP TABLE IF EXISTS `wp_credit_data`;
;

-- -----------------------------
-- Records of `wp_credit_data`
-- -----------------------------
INSERT INTO `wp_credit_data` VALUES ('1', '3', 'signin', '0', '2', '1467019861', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('2', '3', 'vote', '0', '0', '1467034876', '0', 'gh_89d5cf544493', '参与投票');
INSERT INTO `wp_credit_data` VALUES ('3', '3', 'signin', '0', '1', '1467045129', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('4', '3', 'signin', '0', '1', '1467102742', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('5', '3', 'signin', '0', '1', '1467103114', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('6', '3', 'signin', '0', '1', '1467103227', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('7', '3', 'signin', '0', '1', '1467103285', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('8', '3', 'signin', '0', '1', '1467103317', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('9', '3', 'signin', '0', '1', '1467103513', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('10', '3', 'signin', '0', '1', '1467103609', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('11', '3', 'signin', '0', '1', '1467103631', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('12', '3', 'signin', '0', '1', '1467103804', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('13', '3', 'signin', '0', '1', '1467103842', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('14', '3', 'signin', '0', '1', '1467103906', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('15', '3', 'signin', '0', '1', '1467104104', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('16', '3', 'signin', '0', '1', '1467104215', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('17', '3', 'signin', '0', '1', '1467104467', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('18', '3', 'signin', '0', '1', '1467104623', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('19', '3', 'signin', '0', '1', '1467104752', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('20', '3', 'signin', '0', '1', '1467104834', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('21', '3', 'signin', '0', '1', '1467104878', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('22', '3', 'signin', '0', '1', '1467104993', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('23', '8', 'signin', '0', '1', '1467105032', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('24', '8', 'signin', '0', '1', '1467105124', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('25', '3', 'signin', '0', '1', '1467133254', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('26', '3', 'signin', '0', '5', '1467133254', '0', 'gh_89d5cf544493', '连续签到3天');
INSERT INTO `wp_credit_data` VALUES ('27', '3', 'unsubscribe', '-100', '-100', '1467174254', '0', 'gh_89d5cf544493', '取消关注公众号');
INSERT INTO `wp_credit_data` VALUES ('28', '3', 'subscribe', '100', '100', '1467174313', '0', 'gh_89d5cf544493', '关注公众号');
INSERT INTO `wp_credit_data` VALUES ('29', '3', 'signin', '0', '1', '1467362777', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('30', '3', 'signin', '0', '1', '1467548461', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('31', '3', 'signin', '0', '1', '1467633604', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('32', '6', 'signin', '0', '1', '1467639974', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('33', '6', 'vote', '2', '2', '1467640260', '0', 'gh_89d5cf544493', '参与投票');
INSERT INTO `wp_credit_data` VALUES ('34', '3', 'signin', '0', '1', '1467683860', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('35', '8', 'signin', '0', '1', '1467684783', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('36', '3', 'card_bind', '0', '0', '1467690114', '0', 'gh_89d5cf544493', '会员卡绑定');
INSERT INTO `wp_credit_data` VALUES ('37', '8', 'card_bind', '20', '20', '1467690936', '0', 'gh_89d5cf544493', '会员卡绑定');
INSERT INTO `wp_credit_data` VALUES ('38', '-350', 'share', '0', '1', '1467691845', '0', '-1', '分享');
INSERT INTO `wp_credit_data` VALUES ('39', '3', 'share', '0', '1', '1467693364', '0', 'gh_89d5cf544493', '分享');
INSERT INTO `wp_credit_data` VALUES ('40', '8', 'share', '0', '1', '1467699633', '0', 'gh_89d5cf544493', '分享');
INSERT INTO `wp_credit_data` VALUES ('41', '3', 'signin', '0', '1', '1467782020', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('42', '8', 'signin', '0', '1', '1467782337', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('43', '1', 'share', '0', '1', '1467797057', '0', 'gh_89d5cf544493', '分享');
INSERT INTO `wp_credit_data` VALUES ('44', '3', 'share', '0', '1', '1467797395', '0', 'gh_89d5cf544493', '分享');
INSERT INTO `wp_credit_data` VALUES ('45', '3', 'share', '0', '0', '1467798118', '0', 'gh_89d5cf544493', '分享');
INSERT INTO `wp_credit_data` VALUES ('46', '3', 'share', '0', '0', '1467798213', '0', 'gh_89d5cf544493', '分享');
INSERT INTO `wp_credit_data` VALUES ('47', '3', 'share', '0', '0', '1467798413', '0', 'gh_89d5cf544493', '分享');
INSERT INTO `wp_credit_data` VALUES ('48', '3', 'share', '0', '1', '1467799001', '0', 'gh_89d5cf544493', '分享');
INSERT INTO `wp_credit_data` VALUES ('49', '3', 'share', '0', '1', '1467799075', '0', 'gh_89d5cf544493', '分享');
INSERT INTO `wp_credit_data` VALUES ('50', '3', 'signin', '0', '1', '1467822627', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('51', '3', 'share', '0', '1', '1467856491', '0', 'gh_89d5cf544493', '分享');
INSERT INTO `wp_credit_data` VALUES ('52', '8', 'share', '0', '1', '1467857038', '0', 'gh_89d5cf544493', '分享');
INSERT INTO `wp_credit_data` VALUES ('53', '-953', 'share', '0', '1', '1467945635', '0', 'gh_89d5cf544493', '分享');
INSERT INTO `wp_credit_data` VALUES ('54', '11', 'share', '0', '1', '1467945688', '0', 'gh_89d5cf544493', '分享');
INSERT INTO `wp_credit_data` VALUES ('55', '3', 'share', '0', '1', '1467945941', '0', 'gh_89d5cf544493', '宣传贴转发');
INSERT INTO `wp_credit_data` VALUES ('56', '-968', 'signin', '0', '1', '1467946669', '0', 'gh_89d5cf544493', '');
INSERT INTO `wp_credit_data` VALUES ('57', '3', 'signin', '0', '1', '1467947165', '0', 'gh_89d5cf544493', '');

-- -----------------------------
-- Table structure for `wp_custom_menu`
-- -----------------------------
DROP TABLE IF EXISTS `wp_custom_menu`;
;

-- -----------------------------
-- Records of `wp_custom_menu`
-- -----------------------------
INSERT INTO `wp_custom_menu` VALUES ('1', '', '', '慢城社区', '0', '0', 'gh_89d5cf544493', 'none', '9', 'Weiba', '-1', 'text:', '0');
INSERT INTO `wp_custom_menu` VALUES ('10', '', '会员卡', '会员中心', '1', '1', 'gh_89d5cf544493', 'click', '9', '0', '0', 'text:', '0');
INSERT INTO `wp_custom_menu` VALUES ('7', '', '签到', '签到', '1', '0', 'gh_89d5cf544493', 'click', '9', '0', '2', 'text:2', '0');
INSERT INTO `wp_custom_menu` VALUES ('8', 'http://mp.weixin.qq.com/mp/homepage?__biz=MzA4NTE4MjA4MQ==&hid=1&sn=c3d023d6f2189920d764eadd35446272#wechat_redirect', '', '悦慢课程', '0', '0', 'gh_89d5cf544493', 'view', '9', 'Card', '-1', 'text:', '1');
INSERT INTO `wp_custom_menu` VALUES ('9', '', '微官网', '悦慢咖啡', '0', '0', 'gh_89d5cf544493', 'click', '9', '0', '0', 'text:', '1');

-- -----------------------------
-- Table structure for `wp_custom_reply_mult`
-- -----------------------------
DROP TABLE IF EXISTS `wp_custom_reply_mult`;
;


-- -----------------------------
-- Table structure for `wp_custom_reply_news`
-- -----------------------------
DROP TABLE IF EXISTS `wp_custom_reply_news`;
;

-- -----------------------------
-- Records of `wp_custom_reply_news`
-- -----------------------------
INSERT INTO `wp_custom_reply_news` VALUES ('1', '往期回顾', '0', '往期回顾', '悦慢课程往期回顾', '1', '112', '', '1467770525', '0', '0', 'gh_89d5cf544493', 'http://mp.weixin.qq.com/s?__biz=MzA4NTE4MjA4MQ==&mid=2650732424&idx=3&sn=0b51f2025aa9a81d1f44be22f90b0c34&scene=18#wechat_redirect', '', '0', '1');
INSERT INTO `wp_custom_reply_news` VALUES ('2', '目前课程', '0', '目前课程', '目前课程', '1', '113', '', '1467770587', '0', '0', 'gh_89d5cf544493', 'http://mp.weixin.qq.com/s?__biz=MzA4NTE4MjA4MQ==&mid=503248799&idx=5&sn=dcbc12002f27c94100fa9e1bb9170ed1&scene=18#wechat_redirect', '', '0', '1');
INSERT INTO `wp_custom_reply_news` VALUES ('3', '即将推出', '0', '即将推出', '即将推出课程', '1', '114', '', '1467770626', '0', '0', 'gh_89d5cf544493', 'http://mp.weixin.qq.com/s?__biz=MzA4NTE4MjA4MQ==&mid=503248799&idx=2&sn=d79ad9ef590597ec7a0a2f037d599385&scene=18#wechat_redirect', '', '0', '1');
INSERT INTO `wp_custom_reply_news` VALUES ('4', '推广帖', '0', '你是悦慢（推广贴）', '是的是的', '1', '115', '<p>你好啊啊啊 啊啊啊</p>', '1467898521', '0', '19', 'gh_89d5cf544493', '', '', '0', '1');

-- -----------------------------
-- Table structure for `wp_custom_reply_text`
-- -----------------------------
DROP TABLE IF EXISTS `wp_custom_reply_text`;
;


-- -----------------------------
-- Table structure for `wp_custom_sendall`
-- -----------------------------
DROP TABLE IF EXISTS `wp_custom_sendall`;
;


-- -----------------------------
-- Table structure for `wp_customer`
-- -----------------------------
DROP TABLE IF EXISTS `wp_customer`;
;


-- -----------------------------
-- Table structure for `wp_draw_follow_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_draw_follow_log`;
;


-- -----------------------------
-- Table structure for `wp_exam`
-- -----------------------------
DROP TABLE IF EXISTS `wp_exam`;
;


-- -----------------------------
-- Table structure for `wp_exam_answer`
-- -----------------------------
DROP TABLE IF EXISTS `wp_exam_answer`;
;


-- -----------------------------
-- Table structure for `wp_exam_question`
-- -----------------------------
DROP TABLE IF EXISTS `wp_exam_question`;
;


-- -----------------------------
-- Table structure for `wp_file`
-- -----------------------------
DROP TABLE IF EXISTS `wp_file`;
;


-- -----------------------------
-- Table structure for `wp_forms`
-- -----------------------------
DROP TABLE IF EXISTS `wp_forms`;
;


-- -----------------------------
-- Table structure for `wp_forms_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `wp_forms_attribute`;
;


-- -----------------------------
-- Table structure for `wp_forms_value`
-- -----------------------------
DROP TABLE IF EXISTS `wp_forms_value`;
;


-- -----------------------------
-- Table structure for `wp_forum`
-- -----------------------------
DROP TABLE IF EXISTS `wp_forum`;
;


-- -----------------------------
-- Table structure for `wp_guess`
-- -----------------------------
DROP TABLE IF EXISTS `wp_guess`;
;

-- -----------------------------
-- Records of `wp_guess`
-- -----------------------------
INSERT INTO `wp_guess` VALUES ('1', '欧洲杯竞猜', '欧洲杯竞猜', '1467018000', '1467884400', '', '2', 'gh_89d5cf544493', 'default', '45');

-- -----------------------------
-- Table structure for `wp_guess_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_guess_log`;
;

-- -----------------------------
-- Records of `wp_guess_log`
-- -----------------------------
INSERT INTO `wp_guess_log` VALUES ('1', '0', '1', '-1', '1', '1467021176');
INSERT INTO `wp_guess_log` VALUES ('2', '3', '1', 'gh_89d5cf544493', '2', '1467095333');

-- -----------------------------
-- Table structure for `wp_guess_option`
-- -----------------------------
DROP TABLE IF EXISTS `wp_guess_option`;
;

-- -----------------------------
-- Records of `wp_guess_option`
-- -----------------------------
INSERT INTO `wp_guess_option` VALUES ('1', '1', '德国夺冠', '102', '1', '1');
INSERT INTO `wp_guess_option` VALUES ('2', '1', '德国不夺冠', '103', '2', '1');

-- -----------------------------
-- Table structure for `wp_help_open`
-- -----------------------------
DROP TABLE IF EXISTS `wp_help_open`;
;


-- -----------------------------
-- Table structure for `wp_help_open_prize`
-- -----------------------------
DROP TABLE IF EXISTS `wp_help_open_prize`;
;


-- -----------------------------
-- Table structure for `wp_help_open_user`
-- -----------------------------
DROP TABLE IF EXISTS `wp_help_open_user`;
;


-- -----------------------------
-- Table structure for `wp_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `wp_hooks`;
;

-- -----------------------------
-- Records of `wp_hooks`
-- -----------------------------
INSERT INTO `wp_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '');
INSERT INTO `wp_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'ReturnTop');
INSERT INTO `wp_hooks` VALUES ('3', 'documentEditForm', '添加编辑表单的 扩展内容钩子', '1', '0', '');
INSERT INTO `wp_hooks` VALUES ('4', 'documentDetailAfter', '文档末尾显示', '1', '0', 'SocialComment');
INSERT INTO `wp_hooks` VALUES ('5', 'documentDetailBefore', '页面内容前显示用钩子', '1', '0', '');
INSERT INTO `wp_hooks` VALUES ('6', 'documentSaveComplete', '保存文档数据后的扩展钩子', '2', '0', '');
INSERT INTO `wp_hooks` VALUES ('7', 'documentEditFormContent', '添加编辑表单的内容显示钩子', '1', '0', 'Editor');
INSERT INTO `wp_hooks` VALUES ('8', 'adminArticleEdit', '后台内容编辑页编辑器', '1', '1378982734', 'EditorForAdmin');
INSERT INTO `wp_hooks` VALUES ('13', 'AdminIndex', '首页小格子个性化显示', '1', '1382596073', 'SiteStat,SystemInfo,DevTeam');
INSERT INTO `wp_hooks` VALUES ('14', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', 'Editor');
INSERT INTO `wp_hooks` VALUES ('16', 'app_begin', '应用开始', '2', '1384481614', '');
INSERT INTO `wp_hooks` VALUES ('17', 'weixin', '微信插件必须加载的钩子', '1', '1388810858', 'Vote,Wecome,UserCenter,WeiSite,Hitegg,Leaflets,CustomReply,Survey,Diy,CustomMenu,Invite,Game,Ask,Forms,CardVouchers,RedBag,Guess,WishCard,RealPrize,ConfigureAccount,BusinessCard,AutoReply,Payment,Comment,ShopCoupon,Coupon,Card,SingIn,Reserve,Wuguai,Sms,Exam,Test,Draw,YaoTV,Analysis,Weiba,QrAdmin,PublicBind');
INSERT INTO `wp_hooks` VALUES ('18', 'cascade', '级联菜单', '1', '1398694587', 'Cascade');
INSERT INTO `wp_hooks` VALUES ('19', 'page_diy', '万能页面的钩子', '1', '1399040364', 'Diy');
INSERT INTO `wp_hooks` VALUES ('20', 'dynamic_select', '动态下拉菜单', '1', '1435223189', 'DynamicSelect');
INSERT INTO `wp_hooks` VALUES ('21', 'news', '图文素材选择', '1', '1439196828', 'News');
INSERT INTO `wp_hooks` VALUES ('22', 'dynamic_checkbox', '动态多选菜单', '1', '1464002882', 'DynamicCheckbox');
INSERT INTO `wp_hooks` VALUES ('23', 'material', '素材选择', '1', '1464060023', 'Material');
INSERT INTO `wp_hooks` VALUES ('24', 'prize', '奖品选择', '1', '1464060044', 'Prize');

-- -----------------------------
-- Table structure for `wp_import`
-- -----------------------------
DROP TABLE IF EXISTS `wp_import`;
;


-- -----------------------------
-- Table structure for `wp_invite`
-- -----------------------------
DROP TABLE IF EXISTS `wp_invite`;
;


-- -----------------------------
-- Table structure for `wp_invite_code`
-- -----------------------------
DROP TABLE IF EXISTS `wp_invite_code`;
;


-- -----------------------------
-- Table structure for `wp_invite_user`
-- -----------------------------
DROP TABLE IF EXISTS `wp_invite_user`;
;


-- -----------------------------
-- Table structure for `wp_join_count`
-- -----------------------------
DROP TABLE IF EXISTS `wp_join_count`;
;


-- -----------------------------
-- Table structure for `wp_keyword`
-- -----------------------------
DROP TABLE IF EXISTS `wp_keyword`;
;

-- -----------------------------
-- Records of `wp_keyword`
-- -----------------------------
INSERT INTO `wp_keyword` VALUES ('2', '吉他之神', 'gh_89d5cf544493', 'Vote', '1', '1467640172', '12', '0', '', '0', '0');
INSERT INTO `wp_keyword` VALUES ('3', '哈哈哈', 'gh_89d5cf544493', 'Vote', '2', '1467640241', '9', '0', '', '0', '0');
INSERT INTO `wp_keyword` VALUES ('4', '往期回顾', 'gh_89d5cf544493', 'WeiSite', '1', '1467770525', '12', '0', 'custom_reply_news', '0', '0');
INSERT INTO `wp_keyword` VALUES ('5', '目前课程', 'gh_89d5cf544493', 'WeiSite', '2', '1467770587', '12', '0', 'custom_reply_news', '0', '0');
INSERT INTO `wp_keyword` VALUES ('6', '即将推出', 'gh_89d5cf544493', 'WeiSite', '3', '1467770626', '12', '0', 'custom_reply_news', '0', '0');
INSERT INTO `wp_keyword` VALUES ('7', '没有良心', 'gh_89d5cf544493', 'Ask', '1', '1467794945', '12', '0', '', '0', '0');
INSERT INTO `wp_keyword` VALUES ('8', '推广帖', 'gh_89d5cf544493', 'WeiSite', '4', '1467898521', '9', '0', 'custom_reply_news', '0', '0');

-- -----------------------------
-- Table structure for `wp_lottery_games`
-- -----------------------------
DROP TABLE IF EXISTS `wp_lottery_games`;
;


-- -----------------------------
-- Table structure for `wp_lottery_games_award_link`
-- -----------------------------
DROP TABLE IF EXISTS `wp_lottery_games_award_link`;
;


-- -----------------------------
-- Table structure for `wp_lottery_prize_list`
-- -----------------------------
DROP TABLE IF EXISTS `wp_lottery_prize_list`;
;


-- -----------------------------
-- Table structure for `wp_lucky_follow`
-- -----------------------------
DROP TABLE IF EXISTS `wp_lucky_follow`;
;


-- -----------------------------
-- Table structure for `wp_lzwg_activities`
-- -----------------------------
DROP TABLE IF EXISTS `wp_lzwg_activities`;
;


-- -----------------------------
-- Table structure for `wp_lzwg_activities_vote`
-- -----------------------------
DROP TABLE IF EXISTS `wp_lzwg_activities_vote`;
;


-- -----------------------------
-- Table structure for `wp_lzwg_coupon`
-- -----------------------------
DROP TABLE IF EXISTS `wp_lzwg_coupon`;
;


-- -----------------------------
-- Table structure for `wp_lzwg_coupon_receive`
-- -----------------------------
DROP TABLE IF EXISTS `wp_lzwg_coupon_receive`;
;


-- -----------------------------
-- Table structure for `wp_lzwg_coupon_sn`
-- -----------------------------
DROP TABLE IF EXISTS `wp_lzwg_coupon_sn`;
;


-- -----------------------------
-- Table structure for `wp_lzwg_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_lzwg_log`;
;


-- -----------------------------
-- Table structure for `wp_lzwg_vote`
-- -----------------------------
DROP TABLE IF EXISTS `wp_lzwg_vote`;
;


-- -----------------------------
-- Table structure for `wp_lzwg_vote_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_lzwg_vote_log`;
;


-- -----------------------------
-- Table structure for `wp_lzwg_vote_option`
-- -----------------------------
DROP TABLE IF EXISTS `wp_lzwg_vote_option`;
;


-- -----------------------------
-- Table structure for `wp_manager`
-- -----------------------------
DROP TABLE IF EXISTS `wp_manager`;
;

-- -----------------------------
-- Records of `wp_manager`
-- -----------------------------
INSERT INTO `wp_manager` VALUES ('1', '0', '', '', '', '2016©越来越慢所有', '', '');
INSERT INTO `wp_manager` VALUES ('11', '1', '', '', '', '2016@越来悦慢', '', '');

-- -----------------------------
-- Table structure for `wp_manager_menu`
-- -----------------------------
DROP TABLE IF EXISTS `wp_manager_menu`;
;

-- -----------------------------
-- Records of `wp_manager_menu`
-- -----------------------------
INSERT INTO `wp_manager_menu` VALUES ('14', '0', '', '首页', '1', '', 'home/index/main', '_self', '0', '0', '1');
INSERT INTO `wp_manager_menu` VALUES ('15', '0', '', '用户管理', '0', 'UserCenter', '', '_self', '0', '1', '1');
INSERT INTO `wp_manager_menu` VALUES ('16', '1', '15', '微信用户', '0', 'UserCenter', '', '_self', '0', '0', '1');
INSERT INTO `wp_manager_menu` VALUES ('17', '0', '', '互动应用', '0', 'Vote', '', '_self', '0', '2', '1');
INSERT INTO `wp_manager_menu` VALUES ('18', '1', '17', '普通投票', '0', 'Vote', '', '_self', '0', '0', '1');
INSERT INTO `wp_manager_menu` VALUES ('19', '1', '17', '微调研', '0', 'Survey', '', '_self', '0', '3', '1');
INSERT INTO `wp_manager_menu` VALUES ('30', '1', '17', '微邀约', '0', 'Invite', '', '_self', '0', '10', '1');
INSERT INTO `wp_manager_menu` VALUES ('23', '1', '17', '通用表单', '0', 'Forms', '', '_self', '0', '2', '1');
INSERT INTO `wp_manager_menu` VALUES ('24', '1', '17', '竞猜', '0', 'Guess', '', '_self', '0', '11', '1');
INSERT INTO `wp_manager_menu` VALUES ('25', '1', '17', '微贺卡', '0', 'WishCard', '', '_self', '0', '8', '1');
INSERT INTO `wp_manager_menu` VALUES ('26', '1', '17', '微信卡券', '0', 'CardVouchers', '', '_self', '0', '16', '1');
INSERT INTO `wp_manager_menu` VALUES ('27', '1', '356', '优惠券', '0', 'Coupon', '', '_self', '0', '15', '1');
INSERT INTO `wp_manager_menu` VALUES ('28', '1', '356', '微信红包', '0', 'RedBag', '', '_self', '0', '17', '1');
INSERT INTO `wp_manager_menu` VALUES ('29', '1', '356', '实物奖励', '0', 'RealPrize', '', '_self', '0', '18', '1');
INSERT INTO `wp_manager_menu` VALUES ('31', '0', '', '微网站', '0', 'WeiSite', '', '_self', '0', '3', '1');
INSERT INTO `wp_manager_menu` VALUES ('32', '1', '31', '微信回复', '0', 'WeiSite', '', '_self', '0', '0', '1');
INSERT INTO `wp_manager_menu` VALUES ('46', '1', '45', '欢迎语设置', '0', 'Wecome', '', '_self', '0', '0', '1');
INSERT INTO `wp_manager_menu` VALUES ('33', '1', '31', '首页设置', '1', '', 'WeiSite://Template/index', '_self', '0', '1', '1');
INSERT INTO `wp_manager_menu` VALUES ('34', '1', '31', '内容页配置', '1', '', 'WeiSite://Template/lists', '_self', '0', '2', '1');
INSERT INTO `wp_manager_menu` VALUES ('35', '1', '31', '导航栏配置', '1', '', 'WeiSite://Template/footer', '_self', '0', '3', '1');
INSERT INTO `wp_manager_menu` VALUES ('44', '1', '15', '微信咨询', '1', '', 'home/WeixinMessage/lists', '_self', '0', '0', '1');
INSERT INTO `wp_manager_menu` VALUES ('45', '0', '', '公众号功能', '0', 'Wecome', '', '_self', '0', '1', '1');
INSERT INTO `wp_manager_menu` VALUES ('41', '1', '15', '用户分组', '1', '', 'home/AuthGroup/lists', '_self', '0', '2', '1');
INSERT INTO `wp_manager_menu` VALUES ('42', '1', '15', '用户积分', '1', '', 'home/CreditConfig/lists', '_self', '0', '3', '1');
INSERT INTO `wp_manager_menu` VALUES ('47', '1', '45', '自定义菜单', '0', 'CustomMenu', '', '_self', '0', '3', '1');
INSERT INTO `wp_manager_menu` VALUES ('48', '1', '45', '自动回复', '0', 'AutoReply', '', '_self', '0', '2', '1');
INSERT INTO `wp_manager_menu` VALUES ('49', '1', '45', '微信宣传页', '0', 'Leaflets', '', '_self', '0', '6', '1');
INSERT INTO `wp_manager_menu` VALUES ('50', '1', '45', '群发消息', '1', '', 'home/Message/add', '_self', '0', '4', '1');
INSERT INTO `wp_manager_menu` VALUES ('60', '0', '', '素材管理', '1', '', 'Home/Material/material_lists', '_self', '0', '0', '1');
INSERT INTO `wp_manager_menu` VALUES ('338', '1', '45', '工作授权', '1', '', 'Servicer://Servicer/lists', '_self', '0', '12', '1');
INSERT INTO `wp_manager_menu` VALUES ('339', '1', '45', '未识别回复', '0', 'NoAnswer', '', '_self', '0', '1', '1');
INSERT INTO `wp_manager_menu` VALUES ('342', '1', '15', '会员卡', '0', 'Card', '', '_self', '0', '0', '1');
INSERT INTO `wp_manager_menu` VALUES ('343', '1', '17', '帮拆礼包', '0', 'HelpOpen', '', '_self', '0', '13', '1');
INSERT INTO `wp_manager_menu` VALUES ('345', '1', '17', '比赛投票', '1', '', 'Vote://ShopVote/lists', '_self', '0', '1', '1');
INSERT INTO `wp_manager_menu` VALUES ('346', '1', '17', '微签到', '0', 'SingIn', '', '_self', '0', '14', '1');
INSERT INTO `wp_manager_menu` VALUES ('349', '1', '17', '微预约', '0', 'Reserve', '', '_self', '0', '9', '1');
INSERT INTO `wp_manager_menu` VALUES ('350', '1', '17', '抽奖游戏', '1', '', 'Draw://Games/lists', '_self', '0', '19', '1');
INSERT INTO `wp_manager_menu` VALUES ('351', '1', '17', '微考试', '0', 'Exam', '', '_self', '0', '4', '1');
INSERT INTO `wp_manager_menu` VALUES ('352', '1', '17', '微测试', '0', 'Test', '', '_self', '0', '5', '1');
INSERT INTO `wp_manager_menu` VALUES ('353', '1', '17', '微抢答', '0', 'Ask', '', '_self', '0', '12', '1');
INSERT INTO `wp_manager_menu` VALUES ('356', '0', '0', '奖品库', '0', 'Coupon', '', '_self', '0', '0', '1');
INSERT INTO `wp_manager_menu` VALUES ('357', '1', '356', '微信卡券', '0', 'CardVouchers', '', '_self', '0', '19', '1');
INSERT INTO `wp_manager_menu` VALUES ('358', '0', '0', '微社区', '0', 'Weiba', '', '_self', '0', '0', '1');
INSERT INTO `wp_manager_menu` VALUES ('359', '1', '358', '版块管理', '0', 'Weiba', '', '_self', '0', '0', '1');
INSERT INTO `wp_manager_menu` VALUES ('360', '1', '358', '版块分类', '1', '', 'Weiba://Category/lists', '_self', '0', '0', '1');
INSERT INTO `wp_manager_menu` VALUES ('361', '1', '358', '帖子管理', '1', '', 'Weiba://Post/lists', '_self', '0', '0', '1');
INSERT INTO `wp_manager_menu` VALUES ('362', '1', '15', '用户标签', '1', '', 'Home/UserTag/lists', '_self', '0', '0', '1');
INSERT INTO `wp_manager_menu` VALUES ('363', '1', '15', '扫码管理', '0', 'QrAdmin', '', '_self', '0', '0', '1');
INSERT INTO `wp_manager_menu` VALUES ('364', '1', '358', '首页帖子', '1', '', 'Weiba://Post/indexLists', '_self', '0', '4', '1');

-- -----------------------------
-- Table structure for `wp_material_file`
-- -----------------------------
DROP TABLE IF EXISTS `wp_material_file`;
;

-- -----------------------------
-- Records of `wp_material_file`
-- -----------------------------
INSERT INTO `wp_material_file` VALUES ('1', '', '', 'XKNQsN8KBoERHmPP3STny5-JAFRGmg3S_OeipWS_jWU', '', '1460115176', '1', 'gh_89d5cf544493', '让他降落.mp3', '1', '', '1', '', '');
INSERT INTO `wp_material_file` VALUES ('2', '', '', 'XKNQsN8KBoERHmPP3STny_dejyO2wIPSg0cXhs1vXw4', '', '1460115115', '1', 'gh_89d5cf544493', '让他降落.mp3', '1', '', '1', '', '');

-- -----------------------------
-- Table structure for `wp_material_image`
-- -----------------------------
DROP TABLE IF EXISTS `wp_material_image`;
;

-- -----------------------------
-- Records of `wp_material_image`
-- -----------------------------
INSERT INTO `wp_material_image` VALUES ('1', '', '', 'WcRMzKtlxmWOh4pA95f65JK372BdD0-o9ftUPPZtWmg', 'https://mmbiz.qlogo.cn/mmbiz/WXMjrJXNClxlibbxJiazSGW7twIm9PUC7wNWL7Zw2fmf895ABjQphGocayalLreesbWBQGgdtibx1yKdquQaqrTIA/0?wx_fmt=jpeg', '1467171786', '1', 'gh_89d5cf544493', '1', '', '');
INSERT INTO `wp_material_image` VALUES ('2', '', '', 'XKNQsN8KBoERHmPP3STny50q4cFsNjNSVriH1N_bBDg', 'http://mmbiz.qpic.cn/mmbiz/WXMjrJXNClymicibH8EKpH8GNTm6IibmVLpvCKS12zGkGMn7AYia0wjd7iaBaia7Rw9hIeDeXQbhuo3aFcj5YLJr2oxQ/0?wx_fmt=gif', '1467171786', '1', 'gh_89d5cf544493', '1', '', '');

-- -----------------------------
-- Table structure for `wp_material_news`
-- -----------------------------
DROP TABLE IF EXISTS `wp_material_news`;
;

-- -----------------------------
-- Records of `wp_material_news`
-- -----------------------------
INSERT INTO `wp_material_news` VALUES ('1', '让我降落', '阿追', '0', '你走过，唯独你走过， 让我停下了脚步。沉默，两颗心不再沉默。不管别人怎么看，你就是我心中最闪耀的光。抱着吉他', '<p><mpvoice frameborder=\"0\" class=\"res_iframe js_editor_audio audio_iframe\" src=\"https://mp.weixin.qq.com/cgi-bin/readtemplate?t=tmpl/audio_tmpl&amp;name=%E8%AE%A9%E5%A5%B9%E9%99%8D%E8%90%BD&amp;play_length=02:00\" name=\"%E8%AE%A9%E5%A5%B9%E9%99%8D%E8%90%BD\" play_length=\"120000\" voice_encode_fileid=\"MzAxNzg1Mzc5Ml80MDI2NzM3Mjg=\" style=\"width: 556px; line-height: 25.6px; white-space: normal;\"></mpvoice></p><section class=\"yead_editor\" label=\"Copyright © 2015 Yead All Rights Reserved.\" style=\"\"><section style=\"margin: 20px auto; width: 442.391px; text-align: center;\"><section style=\"border: 1px solid rgb(169, 169, 169); box-shadow: rgb(120, 120, 120) 0px 0px 8px;\"><section style=\"margin-top: -5px; margin-bottom: 4px; margin-left: -5px; border: 1px solid rgb(169, 169, 169); box-shadow: rgb(198, 198, 198) 0px 0px 8px; background-color: rgb(255, 255, 255);\"><section style=\"margin-top: -5px; margin-bottom: 4px; margin-left: -5px; padding: 10px; border: 1px solid rgb(169, 169, 169); box-shadow: rgb(198, 198, 198) 0px 0px 8px; background-color: rgb(254, 254, 254);\"><section style=\"clear: both; overflow: hidden; border: 0px; display: inline-block; width: 426.391px;\"><section style=\"width: 426.391px; border-color: rgb(117, 117, 118); color: inherit;\"><p><br  /></p><p><img data-s=\"300,640\" data-type=\"jpeg\" data-src=\"http://mmbiz.qpic.cn/mmbiz/WXMjrJXNClymicibH8EKpH8GNTm6IibmVLpDPg9RJNSVHhdoxTQVwAdSzek3woQcK524BSbPlkfSu00sPte4pxjng/0?wx_fmt=jpeg\" data-ratio=\"0.6666666666666666\" data-w=\"426\" style=\"line-height: 25.6px; white-space: normal;\"  /></p></section></section></section></section></section></section></section><section class=\"yead_editor\" label=\"Copyright © 2015 Yead All Rights Reserved.\" style=\"\"><section class=\"yead_editor\" label=\"Copyright © 2015 Yead All Rights Reserved.\" style=\"margin: 5px auto;\"><section style=\"margin: 8px auto -8px;\"><section class=\"yead_bdc\" style=\"margin-right: auto; margin-left: auto; width: 15px; height: 15px; border-width: 2px 2px 0px 0px; border-style: solid; border-color: rgb(226, 86, 27); transform: rotate(-45deg); background-color: rgb(255, 255, 255);\"></section></section><section class=\"yead_bdc\" style=\"margin-right: auto; margin-bottom: -2px; margin-left: auto; padding: 10px; border-radius: 5px; border: 2px solid rgb(226, 86, 27); border-image-source: none; color: inherit; line-height: 30px; text-indent: 2em;\"><p style=\"line-height: 25.6px; white-space: normal; text-align: left;\">你走过，唯独你走过， 让我停下了脚步。沉默，两颗心不再沉默。</p></section></section></section><p><br  /></p><section class=\"yead_editor\" label=\"Copyright © 2015 Yead All Rights Reserved.\" style=\"\"><section style=\"margin: 20px auto; width: 442.391px; text-align: center;\"><section style=\"border: 1px solid rgb(169, 169, 169); box-shadow: rgb(120, 120, 120) 0px 0px 8px;\"><section style=\"margin-top: -5px; margin-bottom: 4px; margin-left: -5px; border: 1px solid rgb(169, 169, 169); box-shadow: rgb(198, 198, 198) 0px 0px 8px; background-color: rgb(255, 255, 255);\"><section style=\"margin-top: -5px; margin-bottom: 4px; margin-left: -5px; padding: 10px; border: 1px solid rgb(169, 169, 169); box-shadow: rgb(198, 198, 198) 0px 0px 8px; background-color: rgb(254, 254, 254);\"><section style=\"clear: both; overflow: hidden; border: 0px; display: inline-block; width: 426.391px;\"><section style=\"width: 426.391px; border-color: rgb(117, 117, 118); color: inherit;\"><p><img data-s=\"300,640\" data-type=\"jpeg\" data-src=\"http://mmbiz.qpic.cn/mmbiz/WXMjrJXNClymicibH8EKpH8GNTm6IibmVLpiarWuV4x9kzU9QqPNFPoGXNo4dqM1YVlOicyvSbw3jkSz7icgFiaNdd8JQ/0?wx_fmt=jpeg\" data-ratio=\"1.335680751173709\" data-w=\"426\" style=\"line-height: 25.6px; white-space: normal;\"  /></p></section></section></section></section></section></section></section><section class=\"yead_bdc\" style=\"\"><section class=\"yead_editor\" label=\"Copyright © 2015 Yead All Rights Reserved.\" style=\"\"><section style=\"margin: 8px auto -8px;\"><section class=\"yead_bdc\" style=\"margin-right: auto; margin-left: auto; width: 15px; height: 15px; border-width: 2px 2px 0px 0px; border-style: solid; border-color: rgb(226, 86, 27); transform: rotate(-45deg); background-color: rgb(255, 255, 255);\"></section></section><section class=\"yead_bdc\" style=\"margin-right: auto; margin-bottom: -2px; margin-left: auto; padding: 10px; border-radius: 5px; border: 2px solid rgb(226, 86, 27); border-image-source: none; color: inherit; line-height: 30px; text-indent: 2em;\"><p style=\"text-align: left;\"><span style=\"line-height: 25.6px; text-align: center;\">不管别人怎么看，你就是我心中最闪耀的光。</span></p></section></section><p style=\"line-height: 25.6px; text-align: center;\"><span style=\"line-height: 25.6px;\"><br  /></span></p></section><section class=\"yead_editor\" label=\"Copyright © 2015 Yead All Rights Reserved.\" style=\"\"><section style=\"margin: 20px auto; width: 442.391px; text-align: center;\"><section style=\"border: 1px solid rgb(169, 169, 169); box-shadow: rgb(120, 120, 120) 0px 0px 8px;\"><section style=\"margin-top: -5px; margin-bottom: 4px; margin-left: -5px; border: 1px solid rgb(169, 169, 169); box-shadow: rgb(198, 198, 198) 0px 0px 8px; background-color: rgb(255, 255, 255);\"><section style=\"margin-top: -5px; margin-bottom: 4px; margin-left: -5px; padding: 10px; border: 1px solid rgb(169, 169, 169); box-shadow: rgb(198, 198, 198) 0px 0px 8px; background-color: rgb(254, 254, 254);\"><section style=\"clear: both; overflow: hidden; border: 0px; display: inline-block; width: 426.391px;\"><section style=\"width: 426.391px; border-color: rgb(117, 117, 118); color: inherit;\"><p><img data-s=\"300,640\" data-type=\"jpeg\" data-src=\"http://mmbiz.qpic.cn/mmbiz/WXMjrJXNClymicibH8EKpH8GNTm6IibmVLpTKw92A3Z7nUyUQzfH55nfNCohsYJpFBVaniabcWqK2Rgpo6qWRE02Zw/0?wx_fmt=jpeg\" data-ratio=\"0.7511737089201878\" data-w=\"426\" style=\"line-height: 25.6px; white-space: normal;\"  /></p></section></section></section></section></section></section></section><section class=\"yead_editor\" label=\"Copyright © 2015 Yead All Rights Reserved.\" style=\"\"><section class=\"yead_editor\" label=\"Copyright © 2015 Yead All Rights Reserved.\" style=\"margin: 5px auto;\"><section style=\"margin: 8px auto -8px;\"><section class=\"yead_bdc\" style=\"margin-right: auto; margin-left: auto; width: 15px; height: 15px; border-width: 2px 2px 0px 0px; border-style: solid; border-color: rgb(226, 86, 27); transform: rotate(-45deg); background-color: rgb(255, 255, 255);\"></section></section><section class=\"yead_bdc\" style=\"margin-right: auto; margin-bottom: -2px; margin-left: auto; padding: 10px; border-radius: 5px; border: 2px solid rgb(226, 86, 27); border-image-source: none; color: inherit; line-height: 30px; text-indent: 2em;\"><p style=\"text-align: left;\"><span style=\"line-height: 25.6px;\">抱着吉他的你是我能想到的，女孩最美的样子。</span></p></section></section></section><p><br  /></p><p><br  /></p><section class=\"yead_editor\" label=\"Copyright © 2015 Yead All Rights Reserved.\" style=\"\"><section style=\"margin: 20px auto; width: 442.391px; text-align: center;\"><section style=\"border: 1px solid rgb(169, 169, 169); box-shadow: rgb(120, 120, 120) 0px 0px 8px;\"><section style=\"margin-top: -5px; margin-bottom: 4px; margin-left: -5px; border: 1px solid rgb(169, 169, 169); box-shadow: rgb(198, 198, 198) 0px 0px 8px; background-color: rgb(255, 255, 255);\"><section style=\"margin-top: -5px; margin-bottom: 4px; margin-left: -5px; padding: 10px; border: 1px solid rgb(169, 169, 169); box-shadow: rgb(198, 198, 198) 0px 0px 8px; background-color: rgb(254, 254, 254);\"><section style=\"clear: both; overflow: hidden; border: 0px; display: inline-block; width: 426.391px;\"><section style=\"width: 426.391px; border-color: rgb(117, 117, 118); color: inherit;\"><p><img data-s=\"300,640\" data-type=\"png\" data-src=\"http://mmbiz.qpic.cn/mmbiz/WXMjrJXNClymicibH8EKpH8GNTm6IibmVLpyadrbdCTDDpoeGBAM1jDhtmWWSMuMiceE1EzeOMic48J60ECvlxFPGKg/0?wx_fmt=png\" data-ratio=\"1.202409638554217\" data-w=\"415\"  /><br  /></p></section></section></section></section></section></section></section><section class=\"yead_editor\" label=\"Copyright © 2015 Yead All Rights Reserved.\" style=\"\"><section style=\"margin: 8px auto -8px;\"><section class=\"yead_bdc\" style=\"margin-right: auto; margin-left: auto; width: 15px; height: 15px; border-width: 2px 2px 0px 0px; border-style: solid; border-color: rgb(226, 86, 27); transform: rotate(-45deg); background-color: rgb(255, 255, 255);\"></section></section><section class=\"yead_bdc\" style=\"margin-right: auto; margin-bottom: -2px; margin-left: auto; padding: 10px; border-radius: 5px; border: 2px solid rgb(226, 86, 27); border-image-source: none; color: inherit; line-height: 30px; text-indent: 2em;\"><p style=\"text-align: left;\">是不是还记得呢？我为你做的这个小时钟，它还在不停地走着，我幸运地等到了这个时刻，永远地记录了它。<br  /></p><p style=\"text-align: left;\">当然啊，我们的小时钟还会走下去的，对不对？</p></section></section><p style=\"text-align: center;\"><br  /></p><p style=\"text-align: center;\"><br  /></p><section class=\"yead_editor\" label=\"Copyright © 2015 Yead All Rights Reserved.\" style=\"\"><section style=\"max-width: 100%; box-sizing: border-box; color: rgb(62, 62, 62); line-height: 25px; border: 0px none; word-wrap: break-word !important;\"><section style=\"max-width: 100%; box-sizing: border-box; text-align: center; word-wrap: break-word !important;\"><section style=\"padding-right: 15px; padding-left: 15px; max-width: 100%; box-sizing: border-box; display: inline-block; word-wrap: break-word !important; background-color: rgb(254, 254, 254);\"><section class=\"yead_bgc\" style=\"padding: 8px 5px; max-width: 100%; box-sizing: border-box; width: 3.5em; height: 3.5em; border-radius: 50%; display: inline-block; color: rgb(255, 255, 255); word-wrap: break-word !important; background-color: rgb(216, 40, 33);\"><img data-type=\"gif\" data-src=\"http://mmbiz.qpic.cn/mmbiz/WXMjrJXNClymicibH8EKpH8GNTm6IibmVLpvCKS12zGkGMn7AYia0wjd7iaBaia7Rw9hIeDeXQbhuo3aFcj5YLJr2oxQ/0?wx_fmt=gif\" data-ratio=\"1\" data-w=\"46\" style=\"\"  /></section></section></section><section style=\"margin-top: -2em; padding: 30px 10px 10px; max-width: 100%; box-sizing: border-box; line-height: 30px; border: 1px solid rgb(198, 198, 198); word-wrap: break-word !important;\"><section class=\"yead_editor\" label=\"Copyright © 2015 Yead All Rights Reserved.\" style=\"\"><section style=\"box-sizing: border-box; margin-right: auto; margin-left: auto; border: 0px none; font-size: 16px; color: rgb(51, 51, 51); line-height: 30px; clear: both; overflow: hidden;\"><section style=\"box-sizing: border-box; margin-top: 0.5em; margin-bottom: 0.5em; border: 0px none; text-align: center;\"><section class=\"yead_editor\" label=\"Copyright © 2015 Yead All Rights Reserved.\" style=\"\"><section style=\"box-sizing: border-box; margin-right: auto; margin-left: auto; border: 0px none; font-size: 16px; color: rgb(51, 51, 51); line-height: 30px; clear: both; overflow: hidden;\"><section style=\"box-sizing: border-box; margin-top: 0.5em; margin-bottom: 0.5em; border: 0px none; text-align: center;\"><section class=\"yead_bdc\" style=\"box-sizing: border-box; display: inline-block; margin: 2px; padding-bottom: 3px; border: 1px solid rgb(127, 127, 127); width: 30px; border-radius: 8px;\"><section class=\"yead_bdbc\" style=\"box-sizing: border-box; padding-right: 5px; padding-left: 5px; border-width: 0px 0px 1px; border-style: none none solid; border-bottom-color: rgb(127, 127, 127); width: 30px; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px;\"><p style=\"box-sizing: border-box; border: 0px none; color: inherit; line-height: 1.6em;\"><span style=\"box-sizing: border-box; border: 0px none; color: inherit;\"><strong style=\"box-sizing: border-box; border: 0px none;\"><span style=\"box-sizing: border-box; border: 0px none; font-size: 22px;\">1</span></strong></span></p></section></section><section class=\"yead_bdc\" style=\"box-sizing: border-box; display: inline-block; margin: 2px; padding-bottom: 3px; border: 1px solid rgb(127, 127, 127); width: 30px; border-radius: 8px;\"><section class=\"yead_bdbc\" style=\"box-sizing: border-box; padding-right: 5px; padding-left: 5px; border-width: 0px 0px 1px; border-style: none none solid; border-bottom-color: rgb(127, 127, 127); width: 30px; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px;\"><p style=\"box-sizing: border-box; border: 0px none; color: inherit; line-height: 1.6em;\"><span style=\"box-sizing: border-box; border: 0px none; color: inherit;\"><strong style=\"box-sizing: border-box; border: 0px none;\"><span style=\"box-sizing: border-box; border: 0px none; font-size: 22px;\">0</span></strong></span></p></section></section><section class=\"yead_bdc\" style=\"box-sizing: border-box; display: inline-block; margin: 2px; padding-bottom: 3px; border: 1px solid rgb(127, 127, 127); width: 30px; border-radius: 8px;\"><section class=\"yead_bdbc\" style=\"box-sizing: border-box; padding-right: 5px; padding-left: 5px; border-width: 0px 0px 1px; border-style: none none solid; border-bottom-color: rgb(127, 127, 127); width: 30px; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px;\"><p style=\"box-sizing: border-box; border: 0px none; color: inherit; line-height: 1.6em;\"><span style=\"box-sizing: border-box; border: 0px none; color: inherit;\"><strong style=\"box-sizing: border-box; border: 0px none;\"><span style=\"box-sizing: border-box; border: 0px none; font-size: 22px;\">0</span></strong></span></p></section></section><section style=\"box-sizing: border-box; display: inline-block; margin: 2px; padding-bottom: 3px; border: none; width: 20px;\"><p style=\"box-sizing: border-box; border: 0px none; color: inherit; line-height: 1.6em;\"><span style=\"box-sizing: border-box; border: 0px none; font-size: 22px;\">:</span></p></section><section class=\"yead_bdc\" style=\"box-sizing: border-box; display: inline-block; margin: 2px; padding-bottom: 3px; border: 1px solid rgb(127, 127, 127); width: 30px; border-radius: 8px;\"><section class=\"yead_bdbc\" style=\"box-sizing: border-box; padding-right: 5px; padding-left: 5px; border-width: 0px 0px 1px; border-style: none none solid; border-bottom-color: rgb(127, 127, 127); width: 30px; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px;\"><p style=\"box-sizing: border-box; border: 0px none; color: inherit; line-height: 1.6em;\"><span style=\"box-sizing: border-box; border: 0px none; color: inherit;\"><strong style=\"box-sizing: border-box; border: 0px none;\"><span style=\"box-sizing: border-box; border: 0px none; font-size: 22px;\">0</span></strong></span></p></section></section><section class=\"yead_bdc\" style=\"box-sizing: border-box; display: inline-block; margin: 2px; padding-bottom: 3px; border: 1px solid rgb(127, 127, 127); width: 30px; border-radius: 8px;\"><section class=\"yead_bdbc\" style=\"box-sizing: border-box; padding-right: 5px; padding-left: 5px; border-width: 0px 0px 1px; border-style: none none solid; border-bottom-color: rgb(127, 127, 127); width: 30px; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px;\"><p style=\"box-sizing: border-box; border: 0px none; color: inherit; line-height: 1.6em;\"><span style=\"box-sizing: border-box; border: 0px none; color: inherit;\"><strong style=\"box-sizing: border-box; border: 0px none;\"><span style=\"box-sizing: border-box; border: 0px none; font-size: 22px;\">0</span></strong></span></p></section></section><section style=\"box-sizing: border-box; display: inline-block; margin: 2px; padding-bottom: 4px; border: none; width: 20px;\"><p style=\"box-sizing: border-box; border: 0px none; color: inherit; line-height: 1.6em;\"><span style=\"box-sizing: border-box; border: 0px none; font-size: 22px;\">:</span></p></section><section class=\"yead_bdc\" style=\"box-sizing: border-box; display: inline-block; margin: 2px; padding-bottom: 3px; border: 1px solid rgb(127, 127, 127); width: 30px; border-radius: 8px;\"><section class=\"yead_bdbc\" style=\"box-sizing: border-box; padding-right: 5px; padding-left: 5px; border-width: 0px 0px 1px; border-style: none none solid; border-bottom-color: rgb(127, 127, 127); width: 30px; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px;\"><p style=\"box-sizing: border-box; border: 0px none; color: inherit; line-height: 1.6em;\"><span style=\"box-sizing: border-box; border: 0px none; color: inherit;\"><strong style=\"box-sizing: border-box; border: 0px none;\"><span style=\"box-sizing: border-box; border: 0px none; font-size: 22px;\">0</span></strong></span></p></section></section><section class=\"yead_bdc\" style=\"box-sizing: border-box; display: inline-block; margin: 2px; padding-bottom: 3px; border: 1px solid rgb(127, 127, 127); width: 30px; border-radius: 8px;\"><section class=\"yead_bdbc\" style=\"box-sizing: border-box; padding-right: 5px; padding-left: 5px; border-width: 0px 0px 1px; border-style: none none solid; border-bottom-color: rgb(127, 127, 127); width: 30px; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px;\"><p style=\"box-sizing: border-box; border: 0px none; color: inherit; line-height: 1.6em;\"><span style=\"box-sizing: border-box; border: 0px none; color: inherit;\"><strong style=\"box-sizing: border-box; border: 0px none;\"><span style=\"box-sizing: border-box; border: 0px none; font-size: 22px;\">0</span></strong></span></p></section></section><section style=\"box-sizing: border-box; display: inline-block; margin: 2px; padding-bottom: 4px; border: none; width: 20px;\"><p style=\"box-sizing: border-box; border: 0px none; color: inherit; line-height: 1.6em;\"><span style=\"box-sizing: border-box; border: 0px none; font-size: 22px;\">:</span></p></section><section class=\"yead_bdc\" style=\"box-sizing: border-box; display: inline-block; margin: 2px; padding-bottom: 3px; border: 1px solid rgb(127, 127, 127); width: 30px; border-radius: 8px;\"><section class=\"yead_bdbc\" style=\"box-sizing: border-box; padding-right: 5px; padding-left: 5px; border-width: 0px 0px 1px; border-style: none none solid; border-bottom-color: rgb(127, 127, 127); width: 30px; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px;\"><p style=\"box-sizing: border-box; border: 0px none; color: inherit; line-height: 1.6em;\"><span style=\"box-sizing: border-box; border: 0px none; color: inherit;\"><strong style=\"box-sizing: border-box; border: 0px none;\"><span style=\"box-sizing: border-box; border: 0px none; font-size: 22px;\">0</span></strong></span></p></section></section><section class=\"yead_bdc\" style=\"box-sizing: border-box; display: inline-block; margin: 2px; padding-bottom: 3px; border: 1px solid rgb(127, 127, 127); width: 30px; border-radius: 8px;\"><section class=\"yead_bdbc\" style=\"box-sizing: border-box; padding-right: 5px; padding-left: 5px; border-width: 0px 0px 1px; border-style: none none solid; border-bottom-color: rgb(127, 127, 127); width: 30px; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px;\"><p style=\"box-sizing: border-box; border: 0px none; color: inherit; line-height: 1.6em;\"><span style=\"box-sizing: border-box; border: 0px none; color: inherit;\"><strong style=\"box-sizing: border-box; border: 0px none;\"><span style=\"box-sizing: border-box; border: 0px none; font-size: 22px;\">0</span></strong></span></p></section></section></section></section></section></section></section></section></section></section></section><p><br  /></p><p style=\"text-align: center;\"><span style=\"color: rgb(255, 41, 65);\">从这一秒开始，我们一起开始下一个百天。</span></p><p style=\"text-align: center;\"><br  /></p>', '', '1', 'XKNQsN8KBoERHmPP3STnyzqhazeLIlRtffTDb6xKbTc', 'XKNQsN8KBoERHmPP3STny1VovTdfheGftDhGs1xGpL0', '1', 'gh_89d5cf544493', '1467171905', 'http://mp.weixin.qq.com/s?__biz=MzAxNzg1Mzc5Mg==&mid=402673770&idx=1&sn=2476791566d4ccf1295c971835c6fc0a#rd', '1', '', '');
INSERT INTO `wp_material_news` VALUES ('2', '你好', '阿追', '2', '只是在人群中多看了你一眼', '<section style=\"border: 0px none; padding: 0px; box-sizing: border-box; margin: 0px; font-family: 微软雅黑;\"><section class=\"main\" style=\"border: none rgb(0,187,236); margin: 0.8em 5% 0.3em; box-sizing: border-box; padding: 0px;\"><section class=\"main2 wxqq-color wxqq-bordertopcolor wxqq-borderleftcolor wxqq-borderrightcolor wxqq-borderbottomcolor\" data-brushtype=\"text\" style=\"color: rgb(0,187,236); font-size: 20px; letter-spacing: 3px; padding: 9px 4px 14px; text-align: center; margin: 0px auto; border: 4px solid rgb(0,187,236); border-top-left-radius: 8px; border-top-right-radius: 8px; border-bottom-right-radius: 8px; border-bottom-left-radius: 8px; box-sizing: border-box;\">理念<p><span class=\"main3 wxqq-color\" data-brushtype=\"text\" style=\"display: block; font-size: 10px; line-height: 12px; border-color: rgb(0,187,236); color: inherit; box-sizing: border-box; padding: 0px; margin: 0px;\">PHILOSOPHY</span><span class=\"main3 wxqq-color\" data-brushtype=\"text\" style=\"display: block; font-size: 10px; line-height: 12px; border-color: rgb(0,187,236); color: inherit; box-sizing: border-box; padding: 0px; margin: 0px;\"><br/></span><span class=\"main3 wxqq-color\" data-brushtype=\"text\" style=\"display: block; font-size: 10px; line-height: 12px; border-color: rgb(0,187,236); color: inherit; box-sizing: border-box; padding: 0px; margin: 0px;\"><br/></span><span class=\"main3 wxqq-color\" data-brushtype=\"text\" style=\"display: block; font-size: 10px; line-height: 12px; border-color: rgb(0,187,236); color: inherit; box-sizing: border-box; padding: 0px; margin: 0px;\"><br/></span><span class=\"main3 wxqq-color\" data-brushtype=\"text\" style=\"display: block; font-size: 10px; line-height: 12px; border-color: rgb(0,187,236); color: inherit; box-sizing: border-box; padding: 0px; margin: 0px;\"></span></p></section><section class=\"main4 wxqq-bordertopcolor wxqq-borderbottomcolor\" style=\"width: 0px; margin-right: auto; margin-left: auto; border-top-width: 0.6em; border-top-style: solid; border-bottom-color: rgb(0,187,236); border-top-color: rgb(0,187,236); height: 10px; color: inherit; border-left-width: 0.7em !important; border-left-style: solid !important; border-left-color: transparent !important; border-right-width: 0.7em !important; border-right-style: solid !important; border-right-color: transparent !important; box-sizing: border-box; padding: 0px;\" data-width=\"0px\"></section></section></section><p><br/></p>', '', '2', '', 'WcRMzKtlxmWOh4pA95f65P9V8j-wOfjgyj37mqBNxl0', '1', 'gh_89d5cf544493', '1467172113', '', '1', '', '');

-- -----------------------------
-- Table structure for `wp_material_text`
-- -----------------------------
DROP TABLE IF EXISTS `wp_material_text`;
;

-- -----------------------------
-- Records of `wp_material_text`
-- -----------------------------
INSERT INTO `wp_material_text` VALUES ('1', '欢迎来到悦慢城，这是一个神奇的地方：\r\n首先的首先，请点击“积分相关”里的“签到”按钮，开始您的悦慢之旅！', 'gh_89d5cf544493', '1', '1', '', '');
INSERT INTO `wp_material_text` VALUES ('2', '收到您的留言, 我们会尽快回复您!', 'gh_89d5cf544493', '1', '1', '', '');

-- -----------------------------
-- Table structure for `wp_menu`
-- -----------------------------
DROP TABLE IF EXISTS `wp_menu`;
;

-- -----------------------------
-- Records of `wp_menu`
-- -----------------------------
INSERT INTO `wp_menu` VALUES ('4', '新增', '3', '0', 'article/add', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('5', '编辑', '3', '0', 'article/edit', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('6', '改变状态', '3', '0', 'article/setStatus', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('7', '保存', '3', '0', 'article/update', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('8', '保存草稿', '3', '0', 'article/autoSave', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('9', '移动', '3', '0', 'article/move', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('10', '复制', '3', '0', 'article/copy', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('11', '粘贴', '3', '0', 'article/paste', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('12', '导入', '3', '0', 'article/batchOperate', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('14', '还原', '13', '0', 'article/permit', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('15', '清空', '13', '0', 'article/clear', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('16', '用户', '0', '2', 'User/index', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('17', '用户信息', '16', '0', 'User/index', '0', '', '用户管理', '0');
INSERT INTO `wp_menu` VALUES ('18', '新增用户', '17', '0', 'User/add', '0', '添加新用户', '', '0');
INSERT INTO `wp_menu` VALUES ('19', '用户行为', '16', '0', 'User/action', '0', '', '行为管理', '0');
INSERT INTO `wp_menu` VALUES ('20', '新增用户行为', '19', '0', 'User/addaction', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('21', '编辑用户行为', '19', '0', 'User/editaction', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('22', '保存用户行为', '19', '0', 'User/saveAction', '0', '\"用户->用户行为\"保存编辑和新增的用户行为', '', '0');
INSERT INTO `wp_menu` VALUES ('23', '变更行为状态', '19', '0', 'User/setStatus', '0', '\"用户->用户行为\"中的启用,禁用和删除权限', '', '0');
INSERT INTO `wp_menu` VALUES ('24', '禁用会员', '19', '0', 'User/changeStatus?method=forbidUser', '0', '\"用户->用户信息\"中的禁用', '', '0');
INSERT INTO `wp_menu` VALUES ('25', '启用会员', '19', '0', 'User/changeStatus?method=resumeUser', '0', '\"用户->用户信息\"中的启用', '', '0');
INSERT INTO `wp_menu` VALUES ('26', '删除会员', '19', '0', 'User/changeStatus?method=deleteUser', '0', '\"用户->用户信息\"中的删除', '', '0');
INSERT INTO `wp_menu` VALUES ('27', '用户组管理', '16', '0', 'AuthManager/index', '0', '', '用户管理', '0');
INSERT INTO `wp_menu` VALUES ('28', '删除', '27', '0', 'AuthManager/changeStatus?method=deleteGroup', '0', '删除用户组', '', '0');
INSERT INTO `wp_menu` VALUES ('29', '禁用', '27', '0', 'AuthManager/changeStatus?method=forbidGroup', '0', '禁用用户组', '', '0');
INSERT INTO `wp_menu` VALUES ('30', '恢复', '27', '0', 'AuthManager/changeStatus?method=resumeGroup', '0', '恢复已禁用的用户组', '', '0');
INSERT INTO `wp_menu` VALUES ('31', '新增', '27', '0', 'AuthManager/createGroup', '0', '创建新的用户组', '', '0');
INSERT INTO `wp_menu` VALUES ('32', '编辑', '27', '0', 'AuthManager/editGroup', '0', '编辑用户组名称和描述', '', '0');
INSERT INTO `wp_menu` VALUES ('33', '保存用户组', '27', '0', 'AuthManager/writeGroup', '0', '新增和编辑用户组的\"保存\"按钮', '', '0');
INSERT INTO `wp_menu` VALUES ('34', '授权', '27', '0', 'AuthManager/group', '0', '\"后台 \\ 用户 \\ 用户信息\"列表页的\"授权\"操作按钮,用于设置用户所属用户组', '', '0');
INSERT INTO `wp_menu` VALUES ('35', '访问授权', '27', '0', 'AuthManager/access', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"访问授权\"操作按钮', '', '0');
INSERT INTO `wp_menu` VALUES ('36', '成员授权', '27', '0', 'AuthManager/user', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"成员授权\"操作按钮', '', '0');
INSERT INTO `wp_menu` VALUES ('37', '解除授权', '27', '0', 'AuthManager/removeFromGroup', '0', '\"成员授权\"列表页内的解除授权操作按钮', '', '0');
INSERT INTO `wp_menu` VALUES ('38', '保存成员授权', '27', '0', 'AuthManager/addToGroup', '0', '\"用户信息\"列表页\"授权\"时的\"保存\"按钮和\"成员授权\"里右上角的\"添加\"按钮)', '', '0');
INSERT INTO `wp_menu` VALUES ('39', '分类授权', '27', '0', 'AuthManager/category', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"分类授权\"操作按钮', '', '0');
INSERT INTO `wp_menu` VALUES ('40', '保存分类授权', '27', '0', 'AuthManager/addToCategory', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0');
INSERT INTO `wp_menu` VALUES ('41', '模型授权', '27', '0', 'AuthManager/modelauth', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"模型授权\"操作按钮', '', '0');
INSERT INTO `wp_menu` VALUES ('42', '保存模型授权', '27', '0', 'AuthManager/addToModel', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0');
INSERT INTO `wp_menu` VALUES ('43', '插件管理', '0', '7', 'Addons/index', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('44', '插件管理', '43', '1', 'Admin/Plugin/index', '0', '', '扩展', '0');
INSERT INTO `wp_menu` VALUES ('45', '创建', '44', '0', 'Addons/create', '0', '服务器上创建插件结构向导', '', '0');
INSERT INTO `wp_menu` VALUES ('46', '检测创建', '44', '0', 'Addons/checkForm', '0', '检测插件是否可以创建', '', '0');
INSERT INTO `wp_menu` VALUES ('47', '预览', '44', '0', 'Addons/preview', '0', '预览插件定义类文件', '', '0');
INSERT INTO `wp_menu` VALUES ('48', '快速生成插件', '44', '0', 'Addons/build', '0', '开始生成插件结构', '', '0');
INSERT INTO `wp_menu` VALUES ('49', '设置', '44', '0', 'Addons/config', '0', '设置插件配置', '', '0');
INSERT INTO `wp_menu` VALUES ('50', '禁用', '44', '0', 'Addons/disable', '0', '禁用插件', '', '0');
INSERT INTO `wp_menu` VALUES ('51', '启用', '44', '0', 'Addons/enable', '0', '启用插件', '', '0');
INSERT INTO `wp_menu` VALUES ('52', '安装', '44', '0', 'Addons/install', '0', '安装插件', '', '0');
INSERT INTO `wp_menu` VALUES ('53', '卸载', '44', '0', 'Addons/uninstall', '0', '卸载插件', '', '0');
INSERT INTO `wp_menu` VALUES ('54', '更新配置', '44', '0', 'Addons/saveconfig', '0', '更新插件配置处理', '', '0');
INSERT INTO `wp_menu` VALUES ('55', '插件后台列表', '44', '0', 'Addons/adminList', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('56', 'URL方式访问插件', '44', '0', 'Addons/execute', '0', '控制是否有权限通过url访问插件控制器方法', '', '0');
INSERT INTO `wp_menu` VALUES ('57', '钩子管理', '43', '3', 'Addons/hooks', '0', '', '扩展', '0');
INSERT INTO `wp_menu` VALUES ('58', '模型管理', '68', '3', 'Model/index', '0', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('59', '新增', '58', '0', 'model/add', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('60', '编辑', '58', '0', 'model/edit', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('61', '改变状态', '58', '0', 'model/setStatus', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('62', '保存数据', '58', '0', 'model/update', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('64', '新增', '63', '0', 'Attribute/add', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('65', '编辑', '63', '0', 'Attribute/edit', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('66', '改变状态', '63', '0', 'Attribute/setStatus', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('67', '保存数据', '63', '0', 'Attribute/update', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('68', '系统', '0', '1', 'Config/group', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('69', '网站设置', '68', '1', 'Config/group', '0', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('70', '配置管理', '68', '4', 'Config/index', '0', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('71', '编辑', '70', '0', 'Config/edit', '0', '新增编辑和保存配置', '', '0');
INSERT INTO `wp_menu` VALUES ('72', '删除', '70', '0', 'Config/del', '0', '删除配置', '', '0');
INSERT INTO `wp_menu` VALUES ('73', '新增', '70', '0', 'Config/add', '0', '新增配置', '', '0');
INSERT INTO `wp_menu` VALUES ('74', '保存', '70', '0', 'Config/save', '0', '保存配置', '', '0');
INSERT INTO `wp_menu` VALUES ('75', '菜单管理', '68', '5', 'Menu/index', '0', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('77', '新增', '76', '0', 'Channel/add', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('78', '编辑', '76', '0', 'Channel/edit', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('79', '删除', '76', '0', 'Channel/del', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('146', '权限节点', '16', '0', 'Admin/Rule/index', '0', '', '用户管理', '1');
INSERT INTO `wp_menu` VALUES ('81', '编辑', '80', '0', 'Category/edit', '0', '编辑和保存栏目分类', '', '0');
INSERT INTO `wp_menu` VALUES ('82', '新增', '80', '0', 'Category/add', '0', '新增栏目分类', '', '0');
INSERT INTO `wp_menu` VALUES ('83', '删除', '80', '0', 'Category/remove', '0', '删除栏目分类', '', '0');
INSERT INTO `wp_menu` VALUES ('84', '移动', '80', '0', 'Category/operate/type/move', '0', '移动栏目分类', '', '0');
INSERT INTO `wp_menu` VALUES ('85', '合并', '80', '0', 'Category/operate/type/merge', '0', '合并栏目分类', '', '0');
INSERT INTO `wp_menu` VALUES ('86', '备份数据库', '68', '0', 'Database/index?type=export', '0', '', '数据备份', '0');
INSERT INTO `wp_menu` VALUES ('87', '备份', '86', '0', 'Database/export', '0', '备份数据库', '', '0');
INSERT INTO `wp_menu` VALUES ('88', '优化表', '86', '0', 'Database/optimize', '0', '优化数据表', '', '0');
INSERT INTO `wp_menu` VALUES ('89', '修复表', '86', '0', 'Database/repair', '0', '修复数据表', '', '0');
INSERT INTO `wp_menu` VALUES ('90', '还原数据库', '68', '0', 'Database/index?type=import', '0', '', '数据备份', '0');
INSERT INTO `wp_menu` VALUES ('91', '恢复', '90', '0', 'Database/import', '0', '数据库恢复', '', '0');
INSERT INTO `wp_menu` VALUES ('92', '删除', '90', '0', 'Database/del', '0', '删除备份文件', '', '0');
INSERT INTO `wp_menu` VALUES ('96', '新增', '75', '0', 'Menu/add', '0', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('98', '编辑', '75', '0', 'Menu/edit', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('104', '下载管理', '102', '0', 'Think/lists?model=download', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('105', '配置管理', '102', '0', 'Think/lists?model=config', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('106', '行为日志', '16', '0', 'Action/actionlog', '0', '', '行为管理', '0');
INSERT INTO `wp_menu` VALUES ('108', '修改密码', '16', '0', 'User/updatePassword', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('109', '修改昵称', '16', '0', 'User/updateNickname', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('110', '查看行为日志', '106', '0', 'action/edit', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('112', '新增数据', '58', '0', 'think/add', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('113', '编辑数据', '58', '0', 'think/edit', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('114', '导入', '75', '0', 'Menu/import', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('115', '生成', '58', '0', 'Model/generate', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('116', '新增钩子', '57', '0', 'Addons/addHook', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('117', '编辑钩子', '57', '0', 'Addons/edithook', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('118', '文档排序', '3', '0', 'Article/sort', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('119', '排序', '70', '0', 'Config/sort', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('120', '排序', '75', '0', 'Menu/sort', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('121', '排序', '76', '0', 'Channel/sort', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('124', '微信插件', '43', '0', 'Admin/Addons/index', '0', '', '扩展', '0');
INSERT INTO `wp_menu` VALUES ('128', '在线升级', '68', '5', 'Admin/Update/index', '0', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('129', '清除缓存', '68', '10', 'Admin/Update/delcache', '0', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('130', '应用商店', '0', '8', 'admin/store/index', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('131', '素材图标', '130', '2', 'admin/store/index?type=material', '0', '', '应用类型', '0');
INSERT INTO `wp_menu` VALUES ('132', '微站模板', '130', '1', 'admin/store/index?type=template', '0', '', '应用类型', '0');
INSERT INTO `wp_menu` VALUES ('133', '我是开发者', '130', '1', '/index.php?s=/home/developer/myApps', '0', '', '开发者', '0');
INSERT INTO `wp_menu` VALUES ('134', '新手安装指南', '130', '0', 'admin/store/index?type=help', '0', '', '我是站长', '0');
INSERT INTO `wp_menu` VALUES ('135', '万能页面', '130', '3', 'admin/store/index?type=diy', '0', '', '应用类型', '0');
INSERT INTO `wp_menu` VALUES ('136', '上传新应用', '130', '2', '/index.php?s=/home/developer/submitApp', '0', '', '开发者', '0');
INSERT INTO `wp_menu` VALUES ('137', '二次开发教程', '130', '3', '/wiki', '0', '', '开发者', '0');
INSERT INTO `wp_menu` VALUES ('138', '网站信息', '130', '0', 'admin/store/index?type=home', '0', '', '我是站长', '0');
INSERT INTO `wp_menu` VALUES ('139', '充值记录', '130', '0', 'admin/store/index?type=recharge', '0', '', '我是站长', '0');
INSERT INTO `wp_menu` VALUES ('140', '消费记录', '130', '0', 'admin/store/index?type=bug', '0', '', '我是站长', '0');
INSERT INTO `wp_menu` VALUES ('141', '官方交流论坛', '130', '4', '/bbs', '0', '', '开发者', '0');
INSERT INTO `wp_menu` VALUES ('142', '在线充值', '130', '0', 'admin/store/index?type=online_recharge', '0', '', '我是站长', '0');
INSERT INTO `wp_menu` VALUES ('143', '微信插件', '130', '0', 'admin/store/index?type=addon', '0', '', '应用类型', '0');
INSERT INTO `wp_menu` VALUES ('144', '公告管理', '68', '4', 'Notice/lists', '0', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('147', '图文样式编辑', '68', '4', 'ArticleStyle/lists', '0', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('148', '增加', '147', '0', 'ArticleStyle/add', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('149', '分组管理', '147', '0', 'ArticleStyle/group', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('150', '微信接口节点', '16', '0', 'Admin/Rule/wechat', '0', '', '用户管理', '0');
INSERT INTO `wp_menu` VALUES ('151', '公众号组管理', '16', '0', 'Admin/AuthManager/wechat', '0', '', '用户管理', '0');
INSERT INTO `wp_menu` VALUES ('152', '积分选项管理', '16', '6', 'Admin/Credit/lists', '0', '', '用户管理', '1');
INSERT INTO `wp_menu` VALUES ('153', '默认管理菜单', '68', '2', 'Admin/ManagerMenu/lists/uid/1', '0', '', '系统设置', '0');

-- -----------------------------
-- Table structure for `wp_message`
-- -----------------------------
DROP TABLE IF EXISTS `wp_message`;
;


-- -----------------------------
-- Table structure for `wp_model`
-- -----------------------------
DROP TABLE IF EXISTS `wp_model`;
;

-- -----------------------------
-- Records of `wp_model`
-- -----------------------------
INSERT INTO `wp_model` VALUES ('1', 'user', '用户信息表', '0', '', '0', '[\"come_from\",\"nickname\",\"password\",\"truename\",\"mobile\",\"email\",\"sex\",\"headimgurl\",\"city\",\"province\",\"country\",\"language\",\"score\",\"experience\",\"unionid\",\"login_count\",\"reg_ip\",\"reg_time\",\"last_login_ip\",\"last_login_time\",\"status\",\"is_init\",\"is_audit\"]', '1:基础', '', '', '', '', 'headimgurl|url_img_html:头像\r\nlogin_name:登录账号\r\nlogin_password:登录密码\r\nnickname|deal_emoji:用户昵称\r\nsex|get_name_by_status:性别\r\ngroup:分组\r\nscore:金币值\r\nexperience:经历值\r\nids:操作:set_login?uid=[uid]|设置登录账号,detail?uid=[uid]|详细资料,[EDIT]|编辑', '20', '', '', '1436929111', '1441187405', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('2', 'manager', '公众号管理员配置', '0', '', '1', '', '1:基础', '', '', '', '', '', '20', '', '', '1436932532', '1436942362', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('3', 'manager_menu', '公众号管理员菜单', '0', '', '1', '[\"menu_type\",\"pid\",\"title\",\"url_type\",\"addon_name\",\"url\",\"target\",\"is_hide\",\"sort\"]', '1:基础', '', '', '', '', 'title:菜单名\r\nmenu_type|get_name_by_status:菜单类型\r\naddon_name:插件名\r\nurl:外链\r\ntarget|get_name_by_status:打开方式\r\nis_hide|get_name_by_status:隐藏\r\nsort:排序号\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '20', '', '', '1435215960', '1437623073', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('4', 'keyword', '关键词表', '0', '', '1', '[\"keyword\",\"keyword_type\",\"addon\",\"aim_id\",\"keyword_length\",\"cTime\",\"extra_text\",\"extra_int\"]', '1:基础', '', '', '', '', 'id:编号\r\nkeyword:关键词\r\naddon:所属插件\r\naim_id:插件数据ID\r\ncTime|time_format:增加时间\r\nrequest_count|intval:请求数\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '20', 'keyword', '', '1388815871', '1407251192', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('5', 'qr_code', '二维码表', '0', '', '1', '[\"qr_code\",\"addon\",\"aim_id\",\"cTime\",\"extra_text\",\"extra_int\",\"scene_id\",\"action_name\"]', '1:基础', '', '', '', '', 'scene_id:事件KEY值\r\nqr_code|get_code_img:二维码\r\naction_name|get_name_by_status: 	二维码类型\r\naddon:所属插件\r\naim_id:插件数据ID\r\ncTime|time_format:增加时间\r\nrequest_count|intval:请求数\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '20', 'qr_code', '', '1388815871', '1406130247', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('6', 'public', '公众号管理', '0', '', '1', '[\"public_name\",\"public_id\",\"wechat\",\"headface_url\",\"type\",\"appid\",\"secret\",\"encodingaeskey\",\"tips_url\",\"GammaAppId\",\"GammaSecret\",\"public_copy_right\"]', '1:基础', '', '', '', '', 'id:公众号ID\r\npublic_name:公众号名称\r\ntoken:Token\r\ncount:管理员数\r\nids:操作:[EDIT]|编辑,[DELETE]|删除,main&public_id=[id]|进入管理', '20', 'public_name', '', '1391575109', '1447231672', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('7', 'public_group', '公众号等级', '0', '', '1', '[\"title\",\"addon_status\"]', '1:基础', '', '', '', '', 'id:等级ID\r\ntitle:等级名\r\naddon_status:授权的插件\r\npublic_count:公众号数\r\nids:操作:editPublicGroup&id=[id]|编辑,delPublicGroup&id=[id]|删除', '20', 'title', '', '1393724788', '1393730663', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('8', 'public_link', '公众号与管理员的关联关系', '0', '', '1', '[\"uid\",\"addon_status\"]', '1:基础', '', '', '', '', 'uid|get_nickname|deal_emoji:15%管理员(不包括创始人)\r\naddon_status:授权的插件\r\nids:10%操作:[EDIT]|编辑,[DELETE]|删除', '20', '', '', '1398933192', '1447233745', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('9', 'import', '导入数据', '0', '', '1', '', '1:基础', '', '', '', '', '', '20', '', '', '1407554076', '1407554076', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('10', 'addon_category', '插件分类', '0', '', '1', '[\"icon\",\"title\",\"sort\"]', '1:基础', '', '', '', '', 'icon|get_img_html:分类图标\r\ntitle:分类名\r\nsort:排序号\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '20', 'title', '', '1400047655', '1437451028', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('11', 'auto_reply', '自动回复', '0', '', '1', '[\"keyword\",\"content\",\"group_id\",\"image_id\"]', '1:基础', '', '', '', '', 'keyword:关键词\r\ncontent:文件内容\r\ngroup_id:图文\r\nimage_id:图片\r\nvoice_id:语音\r\nvideo_id:视频\r\nids:操作:[EDIT]&type=[msg_type]|编辑,[DELETE]|删除', '10', 'keyword:请输入关键词', '', '1439194522', '1464148533', '1', 'MyISAM', 'AutoReply');
INSERT INTO `wp_model` VALUES ('12', 'common_category', '通用分类', '0', '', '1', '[\"pid\",\"title\",\"icon\",\"intro\",\"sort\",\"is_show\"]', '1:基础', '', '', '', '', 'code:编号\r\ntitle:标题\r\nicon|get_img_html:图标\r\nsort:排序号\r\nis_show|get_name_by_status:显示\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '20', 'title', '', '1397529095', '1404182789', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('13', 'common_category_group', '通用分类分组', '0', '', '1', '[\"name\",\"title\"]', '1:基础', '', '', '', '', 'name:分组标识\r\ntitle:分组标题\r\nids:操作:cascade?target=_blank&module=[name]|数据管理,[EDIT]|编辑,[DELETE]|删除', '20', 'title', '', '1396061373', '1403664378', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('14', 'credit_config', '积分配置', '0', '', '1', '[\"name\",\"title\",\"score\",\"experience\"]', '1:基础', '', '', '', '', 'title:积分描述\r\nname:积分标识\r\nexperience:经验值\r\nscore:金币值\r\nids:操作:[EDIT]|配置', '20', 'title', '', '1396061373', '1438591151', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('15', 'credit_data', '用户积分记录', '0', '', '1', '[\"uid\",\"experience\",\"score\",\"credit_name\"]', '1:基础', '', '', '', '', 'uid:用户\r\ncredit_title:积分来源\r\nexperience:经验值\r\nscore:金币值\r\ncTime|time_format:记录时间\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '20', 'uid', '', '1398564291', '1447250833', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('16', 'material_image', '图片素材', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1438684613', '1438684613', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('17', 'material_news', '图文素材', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1438670890', '1438670890', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('18', 'message', '群发消息', '0', '', '1', '[\"type\",\"bind_keyword\",\"media_id\",\"openid\",\"send_type\",\"group_id\",\"send_openids\"]', '1:基础', '', '', '', '', '', '20', '', '', '1437984111', '1438049406', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('19', 'visit_log', '网站访问日志', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1439448351', '1439448351', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('20', 'auth_group', '用户组', '0', '', '1', '[\"title\",\"description\"]', '1:基础', '', '', '', '', 'title:分组名称\r\ndescription:描述\r\nqr_code:二维码\r\nids:操作:export?id=[id]|导出用户,[EDIT]|编辑,[DELETE]|删除', '20', 'title', '', '1437633503', '1447660681', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('21', 'analysis', '统计分析', '0', '', '1', '', '1:基础', '', '', '', '', '', '20', '', '', '1432806941', '1432806941', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('22', 'article_style', '图文样式', '0', '', '1', '', '1:基础', '', '', '', '', '', '20', '', '', '1436845488', '1436845488', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('23', 'article_style_group', '图文样式分组', '0', '', '1', '', '1:基础', '', '', '', '', '', '20', '', '', '1436845186', '1436845186', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('24', 'ask', '抢答问卷', '0', '', '1', '[\"keyword\",\"keyword_type\",\"title\",\"cover\",\"intro\",\"finish_tip\",\"shop_address\",\"appids\",\"finish_button\",\"content\",\"card_id\",\"appsecre\",\"template\"]', '1:基础', '', '', '', '', 'id:微抢答ID\r\nkeyword:关键词\r\ntitle:标题\r\ncTime|time_format:发布时间\r\nids:操作:[EDIT]|编辑,[DELETE]|删除,ask_question&id=[id]|问题管理,ask_answer&id=[id]|数据管理,preview&id=[id]&target=_blank|预览', '20', 'title', '', '1396061373', '1437449751', '1', 'MyISAM', 'Ask');
INSERT INTO `wp_model` VALUES ('25', 'ask_answer', '抢答回答', '0', '', '1', '', '1:基础', '', '', '', '', 'uid:用户ID\r\nnickname|deal_emoji:昵称\r\nquestion_id:问题\r\nanswer:回答\r\nis_correct:是否正确\r\ntrue_answer:正确答案\r\ntimes:第几轮\r\ncTime|time_format:回答时间', '20', 'uid:请输入用户ID', '', '1396061373', '1430290975', '1', 'MyISAM', 'Ask');
INSERT INTO `wp_model` VALUES ('26', 'ask_question', '抢答问题', '0', '', '1', '[\"title\",\"type\",\"extra\",\"answer\",\"wait_time\",\"sort\",\"percent\",\"intro\"]', '1:基础', '', '', '', '', 'title:标题\r\ntype|get_name_by_status:问题类型\r\nwait_time:时间间隔\r\npercent:抢中概率\r\nanswer:正确答案\r\nsort:排序号\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '20', 'title', '', '1396061373', '1421749210', '1', 'MyISAM', 'Ask');
INSERT INTO `wp_model` VALUES ('27', 'business_card', '微名片', '0', '', '1', '[\"truename\",\"mobile\",\"company\",\"service\",\"position\",\"department\",\"company_url\",\"address\",\"telephone\",\"Email\",\"wechat\",\"qq\",\"weibo\",\"tag\",\"wishing\",\"interest\",\"personal_url\",\"intro\",\"permission\",\"token\"]', '1:基础', '', '', '', '', 'uid:用户ID\r\ntruename:名称\r\nposition:职位\r\naddress:地址\r\nmobile:电话\r\ncompany:公司\r\nqq:QQ号\r\nwechat:微信号\r\nemail:邮箱\r\nqrcode:二维码\r\nids:操作:[EDIT]|编辑', '10', 'truename:请输入名称搜索', '', '1438931238', '1439291025', '1', 'MyISAM', 'BusinessCard');
INSERT INTO `wp_model` VALUES ('28', 'business_card_collect', '名片收藏', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1439188441', '1439188441', '1', 'MyISAM', 'BusinessCard');
INSERT INTO `wp_model` VALUES ('29', 'card_vouchers', '微信卡券', '0', '', '1', '[\"appsecre\",\"code\",\"content\",\"background\",\"title\",\"button_color\",\"head_bg_color\",\"shop_name\",\"uid\",\"token\",\"shop_logo\",\"more_button\",\"template\"]', '1:基础', '', '', '', '', 'title:卡券名称\r\ncard_id:卡券ID\r\nappsecre:商家公众号密钥\r\nids:操作:[EDIT]|编辑,[DELETE]|删除,preview?id=[id]&target=_blank|预览', '20', 'card_id', '', '1421980317', '1437451096', '1', 'MyISAM', 'CardVouchers');
INSERT INTO `wp_model` VALUES ('130', 'comment', '评论互动', '0', '', '1', '[\"is_audit\"]', '1:基础', '', '', '', '', 'headimgurl|url_img_html:用户头像\r\nnickname|deal_emoji:用户姓名\r\ncontent:评论内容\r\ncTime|time_format:评论时间\r\nis_audit|get_name_by_status:审核状态\r\nids:操作:[DELETE]|删除', '20', 'content:请输入评论内容', '', '1432602310', '1435310857', '1', 'MyISAM', 'Comment');
INSERT INTO `wp_model` VALUES ('152', 'coupon', '优惠券', '0', '', '1', '[\"title\",\"cover\",\"use_tips\",\"start_time\",\"start_tips\",\"end_time\",\"end_tips\",\"end_img\",\"num\",\"max_num\",\"over_time\",\"empty_prize_tips\",\"pay_password\",\"background\",\"more_button\",\"use_start_time\",\"shop_name\",\"shop_logo\",\"head_bg_color\",\"button_color\",\"template\",\"member\"]', '1:基础', '', '', '', '', 'id:优惠券编号\r\ntitle:标题\r\nnum:计划发送数\r\ncollect_count:已领取数\r\nuse_count:已使用数\r\nstart_time|time_format:开始时间\r\nend_time|time_format:结束时间\r\nids:操作:[EDIT]|编辑,[DELETE]|删除,lists?target_id=[id]&target=_blank&_controller=Sn|成员管理,preview?id=[id]&target=_blank|预览', '20', 'title', '', '1396061373', '1447756274', '1', 'MyISAM', 'Coupon');
INSERT INTO `wp_model` VALUES ('153', 'coupon_shop', '适用门店', '0', '', '1', '[\"name\",\"address\",\"gps\",\"phone\"]', '1:基础', '', '', '', '', 'name:店名\r\nphone:联系电话\r\naddress:详细地址\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '20', 'name:店名搜索', '', '1427164604', '1439465222', '1', 'MyISAM', 'Coupon');
INSERT INTO `wp_model` VALUES ('154', 'coupon_shop_link', '门店关联', '0', '', '1', '', '1:基础', '', '', '', '', '', '20', '', '', '1427356350', '1427356350', '1', 'MyISAM', 'Coupon');
INSERT INTO `wp_model` VALUES ('34', 'custom_menu', '自定义菜单', '0', '', '1', '[\"pid\",\"title\",\"from_type\",\"type\",\"jump_type\",\"addon\",\"sucai_type\",\"keyword\",\"url\",\"sort\"]', '1:基础', '', '', '', '', 'title:10%菜单名\r\nkeyword:10%关联关键词\r\nurl:50%关联URL\r\nsort:5%排序号\r\nid:10%操作:[EDIT]|编辑,[DELETE]|删除', '20', 'title', '', '1394518309', '1447317015', '1', 'MyISAM', 'CustomMenu');
INSERT INTO `wp_model` VALUES ('35', 'custom_reply_mult', '多图文配置', '0', '', '1', '', '1:基础', '', '', '', '', '', '20', '', '', '1396602475', '1396602475', '1', 'MyISAM', 'CustomReply');
INSERT INTO `wp_model` VALUES ('36', 'custom_reply_news', '图文回复', '0', '', '1', '[\"keyword\",\"keyword_type\",\"title\",\"intro\",\"cate_id\",\"cover\",\"content\",\"sort\"]', '1:基础', '', '', '', '', 'id:5%ID\r\nkeyword:10%关键词\r\nkeyword_type|get_name_by_status:20%关键词类型\r\ntitle:30%标题\r\ncate_id:10%所属分类\r\nsort:7%排序号\r\nview_count:8%浏览数\r\nid:10%操作:[EDIT]|编辑,[DELETE]|删除', '20', 'title', '', '1396061373', '1401368247', '1', 'MyISAM', 'CustomReply');
INSERT INTO `wp_model` VALUES ('37', 'custom_reply_text', '文本回复', '0', '', '1', '[\"keyword\",\"keyword_type\",\"content\",\"sort\"]', '1:基础', '', '', '', '', 'id:ID\r\nkeyword:关键词\r\nkeyword_type|get_name_by_status:关键词类型\r\nsort:排序号\r\nview_count:浏览数\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '20', 'keyword', '', '1396578172', '1401017369', '1', 'MyISAM', 'CustomReply');
INSERT INTO `wp_model` VALUES ('38', 'draw_follow_log', '粉丝抽奖记录', '0', '', '1', '[\"follow_id\",\"sports_id\",\"count\",\"cTime\"]', '1:基础', '', '', '', '', '', '20', '', '', '1432619171', '1432719012', '1', 'MyISAM', 'Draw');
INSERT INTO `wp_model` VALUES ('39', 'forms', '通用表单', '0', '', '1', '[\"keyword\",\"keyword_type\",\"title\",\"intro\",\"cover\",\"can_edit\",\"finish_tip\",\"jump_url\",\"content\",\"template\"]', '1:基础', '', '', '', '', 'id:通用表单ID\r\nkeyword:关键词\r\nkeyword_type|get_name_by_status:关键词类型\r\ntitle:标题\r\ncTime|time_format:发布时间\r\nids:操作:[EDIT]|编辑,[DELETE]|删除,forms_attribute&id=[id]|字段管理,forms_value&id=[id]|数据管理,preview&id=[id]|预览', '20', 'title', '', '1396061373', '1437450012', '1', 'MyISAM', 'Forms');
INSERT INTO `wp_model` VALUES ('40', 'forms_attribute', '表单字段', '0', '', '1', '[\"name\",\"title\",\"type\",\"extra\",\"value\",\"remark\",\"is_must\",\"validate_rule\",\"error_info\",\"sort\"]', '1:基础', '', '', '', '', 'title:字段标题\r\nname:字段名\r\ntype|get_name_by_status:字段类型\r\nids:操作:[EDIT]&forms_id=[forms_id]|编辑,[DELETE]|删除', '20', 'title', '', '1396061373', '1396710959', '1', 'MyISAM', 'Forms');
INSERT INTO `wp_model` VALUES ('41', 'forms_value', '通用表单数据', '0', '', '1', '', '1:基础', '', '', '', '', '', '20', '', '', '1396687959', '1396687959', '1', 'MyISAM', 'Forms');
INSERT INTO `wp_model` VALUES ('42', 'guess', '竞猜', '0', '', '1', '[\"title\",\"desc\",\"start_time\",\"end_time\",\"template\",\"cover\"]', '1:基础', '', '', '', '', 'title:活动名称\r\nstart_time|time_format:开始时间\r\nend_time|time_format:结束时间\r\nguess_count:参与人数\r\nids:操作:[EDIT]|编辑,[DELETE]|删除,guessOption&guess_id=[id]&target=_blank|竞猜选项,guessLog&guess_id=[id]&target=_blank|竞猜记录,preview?id=[id]&target=_blank|预览', '20', 'title:活动名称', '', '1428654951', '1437450636', '1', 'MyISAM', 'Guess');
INSERT INTO `wp_model` VALUES ('43', 'guess_log', '竞猜记录', '0', '', '1', '[\"token\"]', '1:基础', '', '', '', '', 'optionIds:竞猜选项\r\nuser_id:用户id\r\nuser_name:用户昵称\r\ntoken:用户token\r\ncTime|time_format:竞猜时间\r\n', '20', '', '', '1428738271', '1430374436', '1', 'MyISAM', 'Guess');
INSERT INTO `wp_model` VALUES ('44', 'guess_option', '竞猜项目', '0', '', '1', '[\"name\",\"image\",\"order\"]', '1:基础', '', '', '', '', 'title:活动名称\r\nname:选项名称\r\nimage|get_img_html:选项图片\r\norder:选项顺序\r\nguess_count:竞猜人数\r\nids:操作:optionLog&guess_id=[guess_id]&option_id=[id]|查看选项竞猜记录', '20', '', '', '1428659140', '1430374342', '1', 'MyISAM', 'Guess');
INSERT INTO `wp_model` VALUES ('45', 'invite', '微邀约', '0', '', '1', '[\"keyword\",\"keyword_type\",\"title\",\"intro\",\"cover\",\"experience\",\"num\",\"coupon_id\",\"content\",\"template\"]', '1:基础', '', '', '', '', 'keyword:关键词\r\ntitle:标题\r\nexperience:消耗经验值\r\ncoupon_id:优惠券编号\r\ncoupon_name:优惠券标题\r\nids:操作:[EDIT]|编辑,[DELETE]|删除,lists?target_id=[coupon_id]&target=_blank&_addons=Coupon&_controller=Sn|领取记录,preview?id=[id]&target=_blank|预览', '20', 'title', '', '1396061373', '1437448319', '1', 'MyISAM', 'Invite');
INSERT INTO `wp_model` VALUES ('46', 'invite_user', '微邀约用户记录', '0', '', '1', '', '1:基础', '', '', '', '', '', '20', '', '', '1418192328', '1418192328', '1', 'MyISAM', 'Invite');
INSERT INTO `wp_model` VALUES ('47', 'lottery_prize_list', '抽奖奖品列表', '0', '', '1', '[\"sports_id\",\"award_id\",\"award_num\"]', '1:基础', '', '', '', '', 'sports_id:比赛场次\r\naward_id:奖品名称\r\naward_num:奖品数量\r\nid:编辑:[EDIT]|编辑,[DELETE]|删除,add?sports_id=[sports_id]|添加', '20', '', '', '1432613700', '1432710817', '1', 'MyISAM', 'Draw');
INSERT INTO `wp_model` VALUES ('48', 'lucky_follow', '中奖者信息', '0', '', '1', '[\"draw_id\",\"sport_id\",\"award_id\",\"follow_id\",\"address\",\"num\",\"state\",\"zjtime\",\"djtime\",\"remark\",\"scan_code\"]', '1:基础', '', '', '', '', 'draw_id:活动\r\naward_id:奖项\r\naward_name:奖品\r\nzjtime|time_format:中奖时间\r\nfollow_id|deal_emoji:8%微信昵称\r\nstate|get_name_by_status:发奖状态\r\nids:8%操作:do_fafang?id=[id]|发放奖品', '20', 'award_id:输入奖品名称', '', '1432618091', '1462358377', '1', 'MyISAM', 'Draw');
INSERT INTO `wp_model` VALUES ('49', 'lzwg_activities', '靓妆活动', '0', '', '1', '[\"title\",\"remark\",\"logo_img\",\"start_time\",\"end_time\",\"get_prize_tip\",\"no_prize_tip\",\"lottery_number\",\"get_prize_count\",\"comment_status\"]', '1:基础', '', '', '', '', 'title:活动名称\r\nremark:活动描述\r\nlogo_img|get_img_html:活动LOGO\r\nactivitie_time:活动时间\r\nget_prize_tip:中将提示信息\r\nno_prize_tip:未中将提示信息\r\ncomment_list:评论列表\r\nset_vote:设置投票\r\nset_award:设置奖品\r\nget_prize_list:中奖列表\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '20', '', '', '1435306468', '1436181872', '1', 'MyISAM', 'Draw');
INSERT INTO `wp_model` VALUES ('50', 'lzwg_activities_vote', '投票答题活动', '0', '', '1', '[\"lzwg_id\",\"vote_type\",\"vote_limit\",\"lzwg_type\",\"vote_id\"]', '1:基础', '', '', '', '', 'lzwg_name:活动名称\r\nstart_time|time_format:活动开始时间\r\nend_time|time_format:活动结束时间\r\nlzwg_type|get_name_by_status:活动类型\r\nvote_title:题目\r\nids:操作:[EDIT]|编辑,[DELETE]|删除,tongji&id=[id]|用户参与分析\r\n', '20', 'lzwg_id:活动名称', '', '1435734819', '1435825972', '1', 'MyISAM', 'Draw');
INSERT INTO `wp_model` VALUES ('60', 'payment_order', '订单支付记录', '0', '', '1', '[\"from\",\"orderName\",\"single_orderid\",\"price\",\"token\",\"wecha_id\",\"paytype\",\"showwxpaytitle\",\"status\"]', '1:基础', '', '', '', '', '', '20', '', '', '1420596259', '1423534012', '1', 'MyISAM', 'Payment');
INSERT INTO `wp_model` VALUES ('61', 'payment_set', '支付配置', '0', '', '1', '[\"wxappid\",\"wxappsecret\",\"wxpaysignkey\",\"zfbname\",\"pid\",\"key\",\"partnerid\",\"partnerkey\",\"wappartnerid\",\"wappartnerkey\",\"quick_security_key\",\"quick_merid\",\"quick_merabbr\",\"wxmchid\"]', '1:基础', '', '', '', '', '', '10', '', '', '1406958084', '1439364636', '1', 'MyISAM', 'Payment');
INSERT INTO `wp_model` VALUES ('63', 'prize_address', '奖品收货地址', '0', '', '1', '[\"address\",\"mobile\",\"turename\",\"remark\"]', '1:基础', '', '', '', '', 'prizeid:奖品名称\r\nturename:收货人\r\nmobile:联系方式\r\naddress:收货地址\r\nremark:备注\r\nids:操作:address_edit&id=[id]&_controller=RealPrize&_addons=RealPrize|编辑,[DELETE]|删除', '20', '', '', '1429521514', '1447831599', '1', 'MyISAM', 'RealPrize');
INSERT INTO `wp_model` VALUES ('64', 'real_prize', '实物奖励', '0', '', '1', '[\"prize_title\",\"prize_name\",\"prize_conditions\",\"prize_count\",\"prize_image\",\"prize_type\",\"use_content\",\"fail_content\",\"template\"]', '1:基础', '', '', '', '', 'prize_name:20%奖品名称\r\nprize_conditions:20%活动说明\r\nprize_count:10%奖品个数\r\nprize_type|get_name_by_status:10%奖品类型\r\nuse_content:20%使用说明\r\nid:20%操作:[EDIT]|编辑,[DELETE]|删除,address_lists?target_id=[id]|查看数据,preview?id=[id]&target=_blank|预览', '20', '', '', '1429515376', '1437452269', '1', 'MyISAM', 'RealPrize');
INSERT INTO `wp_model` VALUES ('65', 'redbag', '微信红包', '0', '', '1', '[\"mch_id\",\"wxappid\",\"nick_name\",\"send_name\",\"total_amount\",\"min_value\",\"max_value\",\"total_num\",\"wishing\",\"act_name\",\"remark\",\"collect_limit\",\"partner_key\",\"token\",\"uid\",\"template\"]', '1:基础', '', '', '', '', 'act_name:活动名称\r\nsend_name:商户名称\r\ntotal_amount:付款金额\r\nmin_value:最小红包\r\nmax_value:最大红包\r\ntotal_num:发放人数\r\nids:操作:[EDIT]|编辑,[DELETE]|删除,preview?id=[id]&target=_blank|预览', '20', 'act_name:活动名称', '', '1427701701', '1437451797', '1', 'MyISAM', 'RedBag');
INSERT INTO `wp_model` VALUES ('66', 'redbag_follow', '领取红包的用户', '0', '', '1', '[\"redbag_id\",\"follow_id\",\"amount\",\"cTime\"]', '1:基础', '', '', '', '', 'follow_id|get_follow_name:粉丝\r\namount:领取金额（分）\r\ncTime|time_format:领取时间', '20', '', '', '1427703365', '1427703721', '1', 'MyISAM', 'RedBag');
INSERT INTO `wp_model` VALUES ('81', 'sn_code', 'SN码', '0', '', '1', '[\"prize_title\"]', '1:基础', '', '', '', '', 'sn:SN码\r\nuid|get_nickname|deal_emoji:昵称\r\nprize_title:奖项\r\ncTime|time_format:创建时间\r\nis_use|get_name_by_status:是否已使用\r\nuse_time|time_format:使用时间\r\nids:操作:[DELETE]|删除,set_use?id=[id]|改变使用状态', '20', 'sn', '', '1399272054', '1401013099', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('82', 'sport_award', '抽奖奖品', '0', '', '1', '[\"award_type\",\"name\",\"count\",\"img\",\"price\",\"score\",\"explain\",\"coupon_id\",\"money\"]', '1:基础', '', '', '', '', 'id:6%编号\r\nname:23%奖项名称\r\nimg|get_img_html:8%商品图片\r\nprice:8%商品价格\r\nexplain:24%奖品说明\r\ncount:8%奖品数量\r\nids:20%操作:[EDIT]|编辑,[DELETE]|删除,getlistByAwardId?awardId=[id]&_controller=LuckyFollow|中奖者列表', '20', 'name:请输入抽奖名称', '', '1432607100', '1462358042', '1', 'MyISAM', 'Draw');
INSERT INTO `wp_model` VALUES ('83', 'sports', '体育赛事', '0', '', '1', '[\"home_team\",\"visit_team\",\"start_time\",\"score\",\"content\",\"countdown\",\"comment_status\"]', '1:基础', '', '', '', '', 'start_time|time_format:20%比赛场次\r\nvs_team:20%对战球队（主场VS客场）\r\nscore_title:8%比分\r\ncontent|lists_msubstr:27%对战球队的介绍\r\nids:23%操作:add?sports_id=[id]&_controller=LotteryPrizeList&_addons=Draw&target=_blank|奖品配置,lists?sports_id=[id]&_addons=Draw&_controller=LuckyFollow&target=_blank|中奖列表,lists?sports_id=[id]&_addons=Comment&_controller=Comment&target=_blank|评论列表,package?id=[id]&_controller=Sucai&_addons=Sucai&source=Sports&is_preview=1&target=_blank|预览,package?id=[id]&_controller=Sucai&_addons=Sucai&source=Sports&is_download=1&target=_blank|下载素材,[EDIT]|编辑,[DELETE]|删除', '20', 'home_team:请输入球队名', '', '1432556238', '1436173617', '1', 'MyISAM', 'Draw');
INSERT INTO `wp_model` VALUES ('84', 'sports_drum', '擂鼓记录', '0', '', '1', '', '1:基础', '', '', '', '', '', '20', '', '', '1432642253', '1432642253', '1', 'MyISAM', 'Draw');
INSERT INTO `wp_model` VALUES ('85', 'sports_support', '球队支持记录', '0', '', '1', '', '1:基础', '', '', '', '', '', '20', '', '', '1432635084', '1432635084', '1', 'MyISAM', 'Draw');
INSERT INTO `wp_model` VALUES ('86', 'sports_team', '比赛球队', '0', '', '1', '[\"title\",\"logo\",\"intro\"]', '1:基础', '', '', '', '', 'logo|get_img_html:球队图标\r\ntitle:球队名称\r\nintro|lists_msubstr:球队说明\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '20', 'title:请输入球队名', '', '1432556797', '1432886417', '1', 'MyISAM', 'Draw');
INSERT INTO `wp_model` VALUES ('87', 'store', '应用商店', '0', '', '1', '[\"type\",\"title\",\"price\",\"attach\",\"logo\",\"content\",\"img_1\",\"img_2\",\"img_3\",\"img_4\",\"is_top\",\"audit\",\"audit_time\"]', '1:基础', '', '', '', '', 'id:ID值\r\ntype|get_name_by_status:应用类型\r\ntitle:应用标题\r\nprice:价格\r\nlogo|get_img_html:应用LOGO\r\nmTime|time_format:更新时间\r\naudit|get_name_by_status:审核状态\r\naudit_time|time_format:审核时间\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '20', 'title', '', '1394033250', '1402885526', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('88', 'sucai', '素材管理', '0', '', '1', '[\"name\",\"status\",\"cTime\",\"url\",\"type\",\"detail\",\"reason\",\"create_time\",\"checked_time\",\"source\",\"source_id\"]', '1:基础', '', '', '', '', 'name:素材名称\r\nstatus|get_name_by_status:状态\r\nurl:页面URL\r\ncreate_time|time_format:申请时间\r\nchecked_time|time_format:入库时间\r\nids:操作', '20', 'name', '', '1424611702', '1425386629', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('89', 'sucai_template', '素材模板库', '0', '', '1', '', '1:基础', '', '', '', '', '', '20', '', '', '1431575544', '1431575544', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('90', 'survey', '调研问卷', '0', '', '1', '[\"keyword\",\"keyword_type\",\"title\",\"cover\",\"intro\",\"finish_tip\",\"template\",\"start_time\",\"end_time\"]', '1:基础', '', '', '', '', 'id:微调研ID\r\nkeyword:关键词\r\nkeyword_type|get_name_by_status:关键词类型\r\ntitle:标题\r\ncTime|time_format:发布时间\r\nids:操作:[EDIT]|编辑,[DELETE]|删除,survey_answer&id=[id]|数据管理,preview?id=[id]&target=_blank|预览', '20', 'title', '', '1396061373', '1447640225', '1', 'MyISAM', 'Survey');
INSERT INTO `wp_model` VALUES ('91', 'survey_answer', '调研回答', '0', '', '1', '', '1:基础', '', '', '', '', 'openid:OpenId\r\nnickname:昵称\r\nmobile:手机号\r\ncTime|time_format:参与时间\r\nids:操作:detail?uid=[uid]&survey_id=[survey_id]|回答内容', '20', 'title', '', '1396061373', '1447645551', '1', 'MyISAM', 'Survey');
INSERT INTO `wp_model` VALUES ('92', 'survey_question', '调研问题', '0', '', '1', '[\"title\",\"type\",\"extra\",\"intro\",\"is_must\",\"sort\"]', '1:基础', '', '', '', '', 'title:标题\r\ntype|get_name_by_status:问题类型\r\nis_must|get_name_by_status:是否必填\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '20', 'title', '', '1396061373', '1396955090', '1', 'MyISAM', 'Survey');
INSERT INTO `wp_model` VALUES ('93', 'system_notice', '系统公告表', '0', '', '1', '', '1:基础', '', '', '', '', '', '20', '', '', '1431141043', '1431141043', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('94', 'update_version', '系统版本升级', '0', '', '1', '[\"version\",\"title\",\"description\",\"create_date\",\"package\"]', '1:基础', '', '', '', '', 'version:版本号\r\ntitle:升级包名\r\ndescription:描述\r\ncreate_date|time_format:创建时间\r\ndownload_count:下载统计数\r\nids:操作:[EDIT]&id=[id]|编辑,[DELETE]&id=[id]|删除', '20', '', '', '1393770420', '1393771807', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('95', 'vote', '投票', '0', '', '1', '[\"keyword\",\"title\",\"description\",\"picurl\",\"start_date\",\"end_date\",\"template\"]', '1:基础', '', '', '', '', 'id:投票ID\r\nkeyword:关键词\r\ntitle:投票标题\r\ntype|get_name_by_status:类型\r\nis_img|get_name_by_status:状态\r\nvote_count:投票数\r\nids:操作:[EDIT]&id=[id]|编辑,[DELETE]|删除,showLog&id=[id]|投票记录,showCount&id=[id]|选项票数,preview?id=[id]&target=_blank|预览', '20', 'title', 'description', '1388930292', '1437446751', '1', 'MyISAM', 'Vote');
INSERT INTO `wp_model` VALUES ('96', 'vote_log', '投票记录', '0', '', '1', '[\"vote_id\",\"user_id\",\"options\"]', '1:基础', '', '', '', '', 'vote_id:25%用户头像\r\nuser_id:25%用户\r\noptions:25%投票选项\r\ncTime|time_format:25%创建时间\r\n\r\n\r\n\r\n', '20', '', '', '1388934136', '1447743392', '1', 'MyISAM', 'Vote');
INSERT INTO `wp_model` VALUES ('123', 'vote_option', '投票选项', '0', '', '1', '[\"name\",\"opt_count\",\"order\"]', '1:基础', '', '', '', '', 'image|get_img_html:选项图片\r\nname:选项标题\r\nopt_count:投票数', '20', '', '', '1388933346', '1447745055', '1', 'MyISAM', 'Vote');
INSERT INTO `wp_model` VALUES ('99', 'weisite_category', '微官网分类', '0', '', '1', '[\"title\",\"icon\",\"url\",\"is_show\",\"sort\",\"pid\"]', '1:基础', '', '', '', '', 'title:15%分类标题\r\nicon|get_img_html:分类图片\r\nurl:30%外链\r\nsort:10%排序号\r\npid:10%一级目录\r\nis_show|get_name_by_status:10%显示\r\nid:10%操作:[EDIT]|编辑,[DELETE]|删除', '20', 'title', '', '1395987942', '1439522869', '1', 'MyISAM', 'WeiSite');
INSERT INTO `wp_model` VALUES ('100', 'weisite_cms', '文章管理', '0', '', '1', '[\"keyword\",\"keyword_type\",\"title\",\"intro\",\"cate_id\",\"cover\",\"content\",\"sort\"]', '1:基础', '', '', '', '', 'keyword:关键词\r\nkeyword_type|get_name_by_status:关键词类型\r\ntitle:标题\r\ncate_id:所属分类\r\nsort:排序号\r\nview_count:浏览数\r\nids:操作:[EDIT]&module_id=[pid]|编辑,[DELETE]|删除', '20', 'title', '', '1396061373', '1408326292', '1', 'MyISAM', 'WeiSite');
INSERT INTO `wp_model` VALUES ('101', 'weisite_footer', '底部导航', '0', '', '1', '[\"pid\",\"title\",\"url\",\"sort\",\"icon\"]', '1:基础', '', '', '', '', 'title:15%菜单名\r\nicon:10%图标\r\nurl:50%关联URL\r\nsort:8%排序号\r\nids:20%操作:[EDIT]|编辑,[DELETE]|删除', '20', 'title', '', '1394518309', '1464705675', '1', 'MyISAM', 'WeiSite');
INSERT INTO `wp_model` VALUES ('102', 'weisite_slideshow', '幻灯片', '0', '', '1', '[\"title\",\"img\",\"url\",\"is_show\",\"sort\"]', '1:基础', '', '', '', '', 'title:标题\r\nimg:图片\r\nurl:链接地址\r\nis_show|get_name_by_status:显示\r\nsort:排序\r\nids:操作:[EDIT]&module_id=[pid]|编辑,[DELETE]|删除', '20', 'title', '', '1396098264', '1408323347', '1', 'MyISAM', 'WeiSite');
INSERT INTO `wp_model` VALUES ('103', 'weixin_message', '微信消息管理', '0', '', '1', '', '1:基础', '', '', '', '', 'FromUserName:用户\r\ncontent:内容\r\nCreateTime:时间', '20', '', '', '1438142999', '1438151555', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('104', 'wish_card', '微贺卡', '0', '', '1', '[\"send_name\",\"receive_name\",\"content\",\"template\"]', '1:基础', '', '', '', '', 'send_name:10%发送人\r\nreceive_name:10%接收人\r\ncontent:40%祝福语\r\ncreate_time|time_format:15%创建时间\r\nread_count:10%浏览次数\r\nid:15%操作:[EDIT]|编辑,card_show?id=[id]&target=_blank&_controller=Wap|预览,[DELETE]|删除', '20', 'content:祝福语', '', '1429346197', '1429760720', '1', 'MyISAM', 'WishCard');
INSERT INTO `wp_model` VALUES ('105', 'wish_card_content', '祝福语', '0', '', '1', '[\"content_cate\",\"content\"]', '1:基础', '', '', '', '', 'content_cate_id:10%类别Id\r\ncontent_cate:20%类别\r\ncontent:50%祝福语\r\nid:20%操作:[EDIT]|编辑,[DELETE]|删除', '20', '', '', '1429348863', '1429841596', '1', 'MyISAM', 'WishCard');
INSERT INTO `wp_model` VALUES ('106', 'wish_card_content_cate', '祝福语类别', '0', '', '1', '[\"content_cate_name\",\"content_cate_icon\"]', '1:基础', '', '', '', '', 'content_cate_name:类别\r\ncontent_cate_icon|get_img_html:图标\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '20', 'content_cate_name:类别', '', '1429348818', '1429598114', '1', 'MyISAM', 'WishCard');
INSERT INTO `wp_model` VALUES ('201', 'custom_sendall', '客服群发消息', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1447241925', '1447241925', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('148', 'material_text', '文本素材', '0', '', '1', '[\"content\"]', '1:基础', '', '', '', '', 'id:编号\r\ncontent:文本内容\r\nids:操作:text_edit?id=[id]|编辑,text_del?id=[id]|删除', '10', 'content:请输入文本内容搜索', '', '1442976119', '1442977453', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('149', 'material_file', '文件素材', '0', '', '1', '[\"title\",\"file_id\"]', '1:基础', '', '', '', '', '', '10', '', '', '1438684613', '1442982212', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('202', 'sms', '短信记录', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1446107661', '1446107661', '1', 'MyISAM', 'Sms');
INSERT INTO `wp_model` VALUES ('143', 'shop_coupon', '代金券', '0', '', '1', '[\"title\",\"num\",\"money\",\"money_max\",\"is_money_rand\",\"order_money\",\"limit_num\",\"start_time\",\"end_time\",\"limit_goods\",\"limit_goods_ids\",\"is_market_price\",\"content\",\"member\",\"type\"]', '1:基础', '', '', '', '', 'title:代金券名称\r\nmoney:面值\r\nlimit_num:领取限制\r\nstart_time:有效期\r\ncollect_count:已领取\r\nuse_count:已使用\r\nids:操作:preview?id=[id]|预览,lists?_controller=Sn&target_id=[id]|领取记录,sncode_lists?id=[id]|核销记录,[EDIT]|编辑,[DELETE]|删除,index&_addons=ShopCoupon&_controller=Wap&id=[id]|复制链接', '10', 'title:请输入代金券名称搜索', '', '1442390631', '1445565340', '1', 'MyISAM', 'ShopCoupon');
INSERT INTO `wp_model` VALUES ('194', 'help_open_prize', '礼包奖项', '0', '', '1', '[\"sort\",\"name\",\"prize_type\",\"coupon_id\",\"shop_coupon_id\",\"money\"]', '1:基础', '', '', '', '', 'userface:获得用户\r\nnickname:名称\r\ntype:类型\r\nprize:获得礼包\r\ncTime:获取时间\r\ndeal:操作', '10', 'title:请输入用户名称', '', '1445080823', '1445241336', '1', 'MyISAM', 'HelpOpen');
INSERT INTO `wp_model` VALUES ('190', 'reserve', '微预约', '0', '', '1', '[\"title\",\"intro\",\"cover\",\"can_edit\",\"finish_tip\",\"jump_url\",\"content\",\"template\",\"status\",\"start_time\",\"end_time\",\"pay_online\"]', '1:基础', '', '', '', '', 'title:标题\r\nstatus|get_name_by_status:状态\r\nstart_time:报名时间\r\nids:操作:preview&id=[id]|预览,[EDIT]|编辑,reserve_value&id=[id]|预约列表,[DELETE]|删除,index&_addons=Reserve&_controller=Wap&reserve_id=[id]|复制链接', '20', 'title', '', '1396061373', '1445409060', '1', 'MyISAM', 'Reserve');
INSERT INTO `wp_model` VALUES ('128', 'business_card_column', '名片栏目', '0', '', '1', '[\"type\",\"cate_id\",\"title\",\"url\",\"sort\"]', '1:基础', '', '', '', '', 'type|get_name_by_status:栏目类型\r\ncate_id:分类名\r\ntitle:标题\r\nurl:url\r\nsort:排序\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', '', '', '1441511425', '1441782615', '1', 'MyISAM', 'BusinessCard');
INSERT INTO `wp_model` VALUES ('155', 'help_open', '帮拆礼包', '0', '', '1', '[\"title\",\"start_time\",\"end_time\",\"limit_num\",\"content\",\"prize_num\",\"status\",\"collect_tips\",\"share_icon\",\"share_title\",\"share_intro\"]', '1:基础', '', '', '', '', 'title:礼包名称\r\nstatus:状态\r\nprize_num:大礼包总数\r\ncollect_num:大礼包领取\r\nlimit_num:分享要求\r\ntotal:领取总数\r\nstart_time:有效期\r\nid:操作:[EDIT]|编辑,prize_lists?id=[id]|获奖查询,share_lists?id=[id]|分享记录,sncode_lists?id=[id]|核销记录,[DELETE]|删除,preview?id=[id]|预览,index&_addons=HelpOpen&_controller=Wap&id=[id]&invite_uid=1|复制链接', '10', 'title:请输入活动名称', '', '1443108580', '1446429456', '1', 'MyISAM', 'HelpOpen');
INSERT INTO `wp_model` VALUES ('156', 'help_open_user', '帮拆参与人记录', '0', '', '1', '[\"cTime\",\"join_count\"]', '1:基础', '', '', '', '', 'userface: 用户头像\r\nnickname:分享用户\r\njoin_count:获取数量\r\ncTime:分享时间\r\nids:操作:collect_lists?invite_uid=[invite_uid]&help_id=[help_id]|获取人列表', '10', 'title:请输入分享用户名称', '', '1443141956', '1464421255', '1', 'MyISAM', 'HelpOpen');
INSERT INTO `wp_model` VALUES ('176', 'update_score_log', '修改积分记录', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1444302325', '1444302325', '1', 'MyISAM', 'Core');
INSERT INTO `wp_model` VALUES ('177', 'SignIn_Log', '签到记录', '0', '', '1', '{\"1\":[\"uid\",\"score\"]}', '1:基础', '', '', '', '', 'uid:用户ID\r\nnickname:呢称\r\nsTime|time_format:签到时间\r\nscore:积分\r\n', '10', 'uid', '', '1396061373', '1404694493', '1', 'MyISAM', 'SingIn');
INSERT INTO `wp_model` VALUES ('175', 'buy_log', '会员消费记录', '0', '', '1', '[\"pay\",\"pay_type\",\"branch_id\",\"cTime\",\"token\",\"manager_id\",\"sn_id\"]', '1:基础', '', '', '', '', 'member_id:会员名称\r\nphone:电话\r\ncTime|time_format:消费时间\r\nbranch_id:消费门店\r\npay:消费金额\r\nsn_id:优惠金额\r\npay_type|get_name_by_status:消费方式', '10', 'member:请输入会员名称或手机号', '', '1444289843', '1444392724', '1', 'MyISAM', 'Card');
INSERT INTO `wp_model` VALUES ('174', 'recharge_log', '会员充值记录', '0', '', '1', '[\"recharge\",\"branch_id\",\"operator\",\"cTime\",\"token\",\"manager_id\"]', '1:基础', '', '', '', '', 'member_id:会员卡号\r\ntruename:姓名\r\nphone:手机号\r\nrecharge:充值金额\r\ncTime|time_format:充值时间\r\nbranch_id:充值门店\r\noperator:操作员', '10', 'operator:请输入姓名或手机号或操作员', '', '1444275985', '1444387901', '1', 'MyISAM', 'Card');
INSERT INTO `wp_model` VALUES ('163', 'shop_vote', '商城微投票', '0', '', '1', '[\"title\",\"select_type\",\"multi_num\",\"start_time\",\"end_time\",\"is_verify\",\"remark\"]', '1:基础', '', '', '', '', 'title:活动名称\r\nselect_type|get_name_by_status:投票类型\r\nstart_time|time_format:开始时间\r\nend_time|time_format:结束时间\r\nremark:活动说明\r\nids:操作:[EDIT]&id=[id]|编辑,[DELETE]|删除,option_lists&vote_id=[id]|投票选项,show_log&vote_id=[id]|投票记录,preview&vote_id=[id]|预览,index&_addons=Vote&_controller=Wap&vote_id=[id]|复制链接', '10', 'title:请输入活动名称', '', '1443148496', '1445997045', '1', 'MyISAM', 'Vote');
INSERT INTO `wp_model` VALUES ('164', 'shop_vote_option', '投票选项表', '0', '', '1', '[\"truename\",\"image\",\"manifesto\",\"introduce\"]', '1:基础', '', '', '', '', 'truename:10%参赛者\r\nimage|get_img_html:10%参赛图片\r\nmanifesto:30%参赛宣言\r\nintroduce:25%选手介绍\r\nopt_count:8%得票数\r\nids:17%操作:option_edit&id=[id]|编辑,option_del&id=[id]|删除,show_log&option_id=[id]|投票记录', '10', 'truename:请输入姓名', '', '1443149182', '1447817257', '1', 'MyISAM', 'Vote');
INSERT INTO `wp_model` VALUES ('165', 'shop_vote_log', '商城投票记录', '0', '', '1', '[\"vote_id\",\"option_id\",\"uid\"]', '1:基础', '', '', '', '', 'vote_id:25%用户头像\r\nuid:25%用户\r\noption_id:25%投票选项\r\nctime|time_format:25%投票时间', '10', 'truename:请输入用户名字', '', '1443150057', '1447749584', '1', 'MyISAM', 'Vote');
INSERT INTO `wp_model` VALUES ('166', 'card_privilege', '会员卡特权', '0', '', '1', '[\"title\",\"grade\",\"start_time\",\"end_time\",\"intro\",\"enable\"]', '1:基础', '', '', '', '', 'start_time|time_format:特权开始时间\r\nend_time|time_format:特权结束时间\r\ntitle:特权标题\r\ngrade:适用人群\r\nintro:特权内容\r\nenable|get_name_by_status:是否开启\r\nstatus:状态\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', '', '', '1443153625', '1443167441', '1', 'MyISAM', 'Card');
INSERT INTO `wp_model` VALUES ('167', 'card_level', '会员等级', '0', '', '1', '[\"level\",\"score\",\"recharge\",\"discount\"]', '1:基础', '', '', '', '', 'level:会员等级\r\nscore:累计积分\r\nrecharge:累计充值\r\ndiscount:享受折扣\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '10', '', '', '1443163048', '1443164698', '1', 'MyISAM', 'Card');
INSERT INTO `wp_model` VALUES ('171', 'card_coupons', '会员卡优惠券', '0', '', '1', '{\"1\":[\"title\",\"give_type\",\"start_date\",\"end_date\",\"content\"]}', '1:基础', '', '', '', '', 'title:标题\r\ngive_type|get_name_by_status:发放方式\r\nstart_date|time_format:开始时间\r\nend_date|time_format:结束时间\r\ncTime|time_format:发布时间\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1395485774', '1395486719', '1', 'MyISAM', 'Card');
INSERT INTO `wp_model` VALUES ('172', 'card_notice', '会员卡通知', '0', '', '1', '[\"title\",\"img\",\"grade\",\"content\"]', '1:基础', '', '', '', '', 'title:标题\r\ncTime|time_format:发布时间\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1395485156', '1444798538', '1', 'MyISAM', 'Card');
INSERT INTO `wp_model` VALUES ('173', 'card_member', '会员卡成员', '0', '', '1', '[\"phone\",\"username\",\"recharge\"]', '1:基础', '', '', '', '', 'number:卡号\r\nuid:uid\r\nusername:姓名\r\nphone:手机号\r\nscore:剩余积分\r\nrecharge:余额\r\nlevel:等级\r\ncTime|time_format:加入时间\r\nstatus|get_name_by_status:状态\r\nid:操作:[EDIT]|编辑,[DELETE]|删除,do_recharge&id=[id]|会员充值,do_buy&id=[id]|会员消费,update_score&id=[id]|手动修改积分', '10', 'username:请输入姓名', '', '1395482804', '1444633312', '1', 'MyISAM', 'Card');
INSERT INTO `wp_model` VALUES ('179', 'card_marketing', '会员营销活动', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1444482353', '1444482364', '1', 'MyISAM', 'Card');
INSERT INTO `wp_model` VALUES ('180', 'card_reward', '开卡即送活动', '0', '', '1', '[\"title\",\"start_time\",\"end_time\",\"type\",\"score\",\"is_show\",\"content\",\"coupon_id\"]', '1:基础', '', '', '', '', 'title:活动名称\r\ntype:活动策略\r\nstart_time:有效期\r\nstatus:活动状态\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title:请输入活动名称搜索', '', '1442457808', '1444640724', '1', 'MyISAM', 'Card');
INSERT INTO `wp_model` VALUES ('181', 'card_score', '积分兑换活动', '0', '', '1', '[\"title\",\"start_time\",\"end_time\",\"num_limit\",\"coupon_id\",\"score_limit\",\"member\",\"coupon_type\"]', '1:基础', '', '', '', '', 'title:活动名称\r\ncoupon_id:兑换内容\r\nstart_time:有效期\r\nstatus:活动状态\r\nmember:适用人群\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title:请输入活动名称搜索', '', '1442457808', '1444798256', '1', 'MyISAM', 'Card');
INSERT INTO `wp_model` VALUES ('183', 'card_recharge', '充值赠送活动', '0', '', '1', '[\"title\",\"start_time\",\"end_time\",\"is_mult\",\"is_all_goods\"]', '1:基础', '', '', '', '', 'title:活动名称\r\nstart_time:有效期\r\nstatus:活动状态\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title:请输入活动名称搜索', '', '1442457808', '1442544407', '1', 'MyISAM', 'Card');
INSERT INTO `wp_model` VALUES ('184', 'card_recharge_condition', '充值赠送条件', '0', '', '1', '[\"postage\",\"money_param\",\"sort\",\"condition\",\"score\",\"score_param\",\"shop_coupon\",\"shop_coupon_param\"]', '1:基础', '', '', '', '', '', '10', '', '', '1442458767', '1444641566', '1', 'MyISAM', 'Card');
INSERT INTO `wp_model` VALUES ('185', 'card_custom', '客户关怀活动', '0', '', '1', '[\"title\",\"start_time\",\"end_time\",\"type\",\"score\",\"is_show\",\"content\",\"coupon_id\",\"member\",\"is_birthday\",\"before_day\"]', '1:基础', '', '', '', '', 'title:节日名称\r\nstart_time:节日时间\r\nmember:目标人群\r\nend_time:赠送时间\r\ntype:赠送内容\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title:请输入活动名称搜索', '', '1442457808', '1444647144', '1', 'MyISAM', 'Card');
INSERT INTO `wp_model` VALUES ('186', 'score_exchange_log', '兑换记录', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1444731340', '1444731340', '1', 'MyISAM', 'Card');
INSERT INTO `wp_model` VALUES ('187', 'share_log', '分享记录', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1444789662', '1444789662', '1', 'MyISAM', 'Card');
INSERT INTO `wp_model` VALUES ('188', 'lottery_games', '抽奖游戏', '0', '', '1', '[\"title\",\"keyword\",\"game_type\",\"start_time\",\"end_time\",\"status\",\"day_attend_limit\",\"attend_limit\",\"day_win_limit\",\"win_limit\",\"day_winners_count\",\"remark\"]', '1:基础', '', '', '', '', 'id:序号\r\ntitle:活动名称\r\ngame_type|get_name_by_status:游戏类型\r\nkeyword:关键词\r\nstart_time|time_format:开始时间\r\nend_time|time_format:结束时间\r\nstatus:活动状态\r\nattend_num:参与人数\r\nwinners_list:中奖人列表\r\nids:操作:[EDIT]|编辑,[DELETE]|删除,preview&games_id=[id]|预览,index&_addons=Draw&_controller=Wap&games_id=[id]|复制链接', '10', '', '', '1444877287', '1445482517', '1', 'MyISAM', 'Draw');
INSERT INTO `wp_model` VALUES ('189', 'lottery_games_award_link', '抽奖游戏奖品设置', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1444900969', '1444900969', '1', 'MyISAM', 'Draw');
INSERT INTO `wp_model` VALUES ('193', 'reserve_option', '预约选项', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1444962050', '1444962050', '1', 'MyISAM', 'Reserve');
INSERT INTO `wp_model` VALUES ('191', 'reserve_attribute', '微预约字段', '0', '', '1', '[\"name\",\"title\",\"type\",\"extra\",\"value\",\"remark\",\"is_must\",\"validate_rule\",\"error_info\",\"sort\"]', '1:基础', '', '', '', '', 'title:字段标题\r\nname:字段名\r\ntype|get_name_by_status:字段类型\r\nids:操作:[EDIT]&reserve_id=[reserve_id]|编辑,[DELETE]|删除', '20', 'title', '', '1396061373', '1396710959', '1', 'MyISAM', 'Reserve');
INSERT INTO `wp_model` VALUES ('192', 'reserve_value', '微预约数据', '0', '', '1', '', '1:基础', '', '', '', '', '', '20', '', '', '1396687959', '1396687959', '1', 'MyISAM', 'Reserve');
INSERT INTO `wp_model` VALUES ('1134', 'exam', '考试试卷', '0', '', '1', '[\"keyword\",\"keyword_type\",\"title\",\"intro\",\"cover\",\"finish_tip\"]', '1:基础', '', '', '', '', 'keyword:关键词\r\nkeyword_type|get_name_by_status:关键词匹配类型\r\ntitle:试卷标题\r\nstart_time|time_format:开始时间\r\nend_time|time_format:结束时间\r\nid:操作:[EDIT]|编辑,[DELETE]|删除,exam_question&target=_blank&id=[id]|题目管理,exam_answer&target=_blank&id=[id]|考生成绩,preview&id=[id]&target=_blank|试卷预览', '10', 'title:请输入试卷标题搜索', '', '1396061373', '1447755312', '1', 'MyISAM', 'Exam');
INSERT INTO `wp_model` VALUES ('1135', 'exam_question', '考试题目', '0', '', '1', '{\"1\":[\"title\",\"type\",\"extra\",\"intro\",\"is_must\",\"sort\"]}', '1:基础', '', '', '', '', 'title:标题\r\ntype|get_name_by_status:题目类型\r\nscore:分值\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1396061373', '1397035409', '1', 'MyISAM', 'Exam');
INSERT INTO `wp_model` VALUES ('1136', 'exam_answer', '考试回答', '0', '', '1', '', '1:基础', '', '', '', '', 'openid:OpenId\r\ntruename:姓名\r\nmobile:手机号\r\nscore:成绩\r\ncTime|time_format:考试时间\r\nid:操作:detail?uid=[uid]&exam_id=[exam_id]|答题详情', '10', 'title', '', '1396061373', '1397036455', '1', 'MyISAM', 'Exam');
INSERT INTO `wp_model` VALUES ('1137', 'test', '测试问卷', '0', '', '1', '[\"keyword\",\"keyword_type\",\"title\",\"intro\",\"cover\",\"finish_tip\"]', '1:基础', '', '', '', '', 'keyword:关键词\r\nkeyword_type|get_name_by_status:关键词匹配类型\r\ntitle:问卷标题\r\nid:操作:[EDIT]|编辑,[DELETE]|删除,test_question&target=_blank&id=[id]|题目管理,test_answer&target=_blank&id=[id]|用户记录,preview&target=_blank&id=[id]|问卷预览', '10', 'title:请输入问卷标题搜索', '', '1396061373', '1463726031', '1', 'MyISAM', 'Test');
INSERT INTO `wp_model` VALUES ('1138', 'test_question', '测试题目', '0', '', '1', '{\"1\":[\"title\",\"extra\",\"intro\",\"sort\"]}', '1:基础', '', '', '', '', 'id:问题编号\r\ntitle:标题\r\nextra:参数\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1396061373', '1397145854', '1', 'MyISAM', 'Test');
INSERT INTO `wp_model` VALUES ('1139', 'test_answer', '测试回答', '0', '', '1', '', '1:基础', '', '', '', '', 'openid:OpenId\r\ntruename:姓名\r\nmobile:手机号\r\nscore:得分\r\ncTime|time_format:测试时间\r\nid:操作:detail?uid=[uid]&test_id=[test_id]|答题详情', '10', 'title', '', '1396061373', '1397145984', '1', 'MyISAM', 'Test');
INSERT INTO `wp_model` VALUES ('1147', 'weiba_category', '微吧分类', '0', '', '1', '[\"name\"]', '1:基础', '', '', '', '', 'id:分类编号\r\nname:分类名称\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'name:请输入分类名称搜索', '', '1463800207', '1463801532', '1', 'MyISAM', 'Weiba');
INSERT INTO `wp_model` VALUES ('1148', 'weiba', '微社区', '0', '', '1', '[\"weiba_name\",\"cid\",\"logo\",\"who_can_post\",\"recommend\",\"admin_uid\",\"intro\",\"notify\"]', '1:基础', '', '', '', '', 'id:微吧ID\r\nweiba_name:版块名称\r\ncid:版块分类\r\nthread_count:帖子数\r\nfollower_count:成员数\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'weiba_name:请输入版块名称搜索', '', '1463802099', '1463821750', '1', 'MyISAM', 'Weiba');
INSERT INTO `wp_model` VALUES ('1149', 'weiba_post', '微社区帖子', '0', '', '1', '[\"weiba_id\",\"title\",\"content\"]', '1:基础', '', '', '', '', 'id:帖子编号\r\ntitle:帖子标题\r\nweiba_id:所属版块\r\npost_uid:发帖人\r\nread_count:浏览数\r\nreply_count:回复数\r\npost_time|time_format:发帖时间\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title:请输入标题搜索', '', '1463803589', '1464405700', '1', 'MyISAM', 'Weiba');
INSERT INTO `wp_model` VALUES ('1150', 'user_tag', '用户标签', '0', '', '1', '[\"title\"]', '1:基础', '', '', '', '', 'id:标签编号\r\ntitle:标签名称\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title:请输入标签名称搜索', '', '1463990100', '1463993574', '1', 'MyISAM', 'UserCenter');
INSERT INTO `wp_model` VALUES ('1151', 'user_tag_link', '用户标签关系表', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1463992911', '1463992911', '1', 'MyISAM', 'UserCenter');
INSERT INTO `wp_model` VALUES ('1152', 'qr_admin', '扫码管理', '0', '', '1', '[\"action_name\",\"group_id\",\"tag_ids\"]', '1:基础', '', '', '', '', 'qr_code:二维码\r\naction_name:类型\r\ngroup_id:用户组\r\ntag_ids:标签\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '10', '', '', '1463999052', '1464002422', '1', 'MyISAM', 'QrAdmin');
INSERT INTO `wp_model` VALUES ('1153', 'servicer', '授权用户', '0', '', '1', '[\"uid\",\"truename\",\"mobile\",\"role\",\"enable\"]', '1:基础', '', '', '', '', 'truename:姓名\r\nrole:权限列表\r\nnickname:微信名称\r\nenable|get_name_by_status:是否启用\r\nids:操作:set_enable?id=[id]&enable=[enable]|改变启用状态,[EDIT]|编辑,[DELETE]|删除', '10', 'truename', '', '1443066649', '1445932371', '1', 'MyISAM', 'Shop');
INSERT INTO `wp_model` VALUES ('1154', 'shop_address', '收货地址', '0', '', '1', '', '1:基础', '', '', '', '', '', '20', '', '', '1423477477', '1423477477', '1', 'MyISAM', 'Shop');
INSERT INTO `wp_model` VALUES ('1155', 'card_coupons', '会员卡优惠券', '0', '', '1', '{\"1\":[\"title\",\"give_type\",\"start_date\",\"end_date\",\"content\"]}', '1:基础', '', '', '', '', 'title:标题\r\ngive_type|get_name_by_status:发放方式\r\nstart_date|time_format:开始时间\r\nend_date|time_format:结束时间\r\ncTime|time_format:发布时间\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1395485774', '1395486719', '1', 'MyISAM', '');
INSERT INTO `wp_model` VALUES ('1156', 'card_notice', '会员卡通知', '0', '', '1', '{\"1\":[\"title\",\"content\"]}', '1:基础', '', '', '', '', 'title:标题\r\ncTime|time_format:发布时间\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1395485156', '1395485486', '1', 'MyISAM', '');
INSERT INTO `wp_model` VALUES ('1157', 'card_member', '会员卡成员', '0', '', '1', '{\"1\":[\"username\",\"phone\"]}', '1:基础', '', '', '', '', 'number:卡号\r\nusername:姓名\r\nphone:手机号\r\ncTime|time_format:加入时间\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'username', '', '1395482804', '1395484751', '1', 'MyISAM', '');

-- -----------------------------
-- Table structure for `wp_online_count`
-- -----------------------------
DROP TABLE IF EXISTS `wp_online_count`;
;


-- -----------------------------
-- Table structure for `wp_payment_order`
-- -----------------------------
DROP TABLE IF EXISTS `wp_payment_order`;
;


-- -----------------------------
-- Table structure for `wp_payment_set`
-- -----------------------------
DROP TABLE IF EXISTS `wp_payment_set`;
;


-- -----------------------------
-- Table structure for `wp_picture`
-- -----------------------------
DROP TABLE IF EXISTS `wp_picture`;
;

-- -----------------------------
-- Records of `wp_picture`
-- -----------------------------
INSERT INTO `wp_picture` VALUES ('1', '/Uploads/Picture/2016-06-27/5770eefadaa71.jpg', '', '0', '8969288f4245120e7c3870287cce0ff3', '1b4605b0e20ceccf91aa278d10e81fad64e24e27', '1', '1467019002', 'gh_89d5cf544493', '0');
INSERT INTO `wp_picture` VALUES ('2', '/Public/static/icon/colors/1187203.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('3', '/Public/static/icon/colors/1187204.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('4', '/Public/static/icon/colors/1187205.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('5', '/Public/static/icon/colors/1187206.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('6', '/Public/static/icon/colors/1187207.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('7', '/Public/static/icon/colors/1187208.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('8', '/Public/static/icon/colors/1187209.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('9', '/Public/static/icon/colors/1187210.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('10', '/Public/static/icon/colors/1187211.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('11', '/Public/static/icon/colors/1187212.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('12', '/Public/static/icon/colors/1187213.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('13', '/Public/static/icon/colors/1187214.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('14', '/Public/static/icon/colors/1187215.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('15', '/Public/static/icon/colors/1187216.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('16', '/Public/static/icon/colors/1187217.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('17', '/Public/static/icon/colors/1187218.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('18', '/Public/static/icon/colors/1187219.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('19', '/Public/static/icon/colors/1187220.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('20', '/Public/static/icon/colors/1187221.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('21', '/Public/static/icon/colors/1187222.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('22', '/Public/static/icon/colors/1187223.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('23', '/Public/static/icon/colors/1187224.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('24', '/Public/static/icon/colors/1187225.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('25', '/Public/static/icon/colors/1187226.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('26', '/Public/static/icon/colors/1187227.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('27', '/Public/static/icon/colors/1187228.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('28', '/Public/static/icon/colors/1187229.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('29', '/Public/static/icon/colors/1187230.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('30', '/Public/static/icon/colors/1187231.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('31', '/Public/static/icon/colors/1187232.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('32', '/Public/static/icon/colors/1187233.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('33', '/Public/static/icon/colors/1187234.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('34', '/Public/static/icon/colors/1187235.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('35', '/Public/static/icon/colors/1187236.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('36', '/Public/static/icon/colors/1187237.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('37', '/Public/static/icon/colors/1187238.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('38', '/Public/static/icon/colors/1187239.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('39', '/Public/static/icon/colors/1187240.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('40', '/Public/static/icon/colors/1187241.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('41', '/Public/static/icon/colors/1187242.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('42', '/Public/static/icon/colors/1187243.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('43', '/Public/static/icon/colors/1187244.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('44', '/Public/static/icon/colors/1187245.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('45', '/Public/static/icon/colors/1187246.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('46', '/Public/static/icon/colors/1187247.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('47', '/Public/static/icon/colors/1187248.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('48', '/Public/static/icon/colors/1187249.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('49', '/Public/static/icon/colors/1187250.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('50', '/Public/static/icon/colors/1187251.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('51', '/Public/static/icon/colors/1187252.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('52', '/Public/static/icon/colors/1187253.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('53', '/Public/static/icon/colors/1187254.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('54', '/Public/static/icon/colors/1187255.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('55', '/Public/static/icon/colors/1187256.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('56', '/Public/static/icon/colors/1187257.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('57', '/Public/static/icon/colors/1187258.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('58', '/Public/static/icon/colors/1187259.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('59', '/Public/static/icon/colors/1187260.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('60', '/Public/static/icon/colors/1187261.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('61', '/Public/static/icon/colors/1187262.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('62', '/Public/static/icon/colors/1187263.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('63', '/Public/static/icon/colors/1187264.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('64', '/Public/static/icon/colors/1187265.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('65', '/Public/static/icon/colors/1187266.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('66', '/Public/static/icon/colors/1187267.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('67', '/Public/static/icon/colors/1187268.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('68', '/Public/static/icon/colors/1187269.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('69', '/Public/static/icon/colors/1187270.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('70', '/Public/static/icon/colors/1187271.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('71', '/Public/static/icon/colors/1187272.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('72', '/Public/static/icon/colors/1187273.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('73', '/Public/static/icon/colors/1187274.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('74', '/Public/static/icon/colors/1187275.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('75', '/Public/static/icon/colors/1187276.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('76', '/Public/static/icon/colors/1187277.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('77', '/Public/static/icon/colors/1187278.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('78', '/Public/static/icon/colors/1187279.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('79', '/Public/static/icon/colors/1187280.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('80', '/Public/static/icon/colors/1187281.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('81', '/Public/static/icon/colors/1187282.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('82', '/Public/static/icon/colors/1187283.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('83', '/Public/static/icon/colors/1187284.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('84', '/Public/static/icon/colors/1187285.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('85', '/Public/static/icon/colors/1187286.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('86', '/Public/static/icon/colors/1187287.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('87', '/Public/static/icon/colors/1187288.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('88', '/Public/static/icon/colors/1187289.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('89', '/Public/static/icon/colors/1187290.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('90', '/Public/static/icon/colors/1187291.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('91', '/Public/static/icon/colors/1187292.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('92', '/Public/static/icon/colors/1187293.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('93', '/Public/static/icon/colors/1187294.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('94', '/Public/static/icon/colors/1187295.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('95', '/Public/static/icon/colors/1187296.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('96', '/Public/static/icon/colors/1187297.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('97', '/Public/static/icon/colors/1187298.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('98', '/Public/static/icon/colors/1187299.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('99', '/Public/static/icon/colors/1187300.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('100', '/Public/static/icon/colors/1187301.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('101', '/Public/static/icon/colors/1187302.png', '', '0', '', '', '1', '1467019704', '', '1');
INSERT INTO `wp_picture` VALUES ('102', '/Uploads/Picture/2016-06-27/5770f5240df45.jpg', '', '0', '076e3caed758a1c18c91a0e9cae3368f', 'f5f8ad26819a471318d24631fa5055036712a87e', '1', '1467020578', 'gh_89d5cf544493', '0');
INSERT INTO `wp_picture` VALUES ('103', '/Uploads/Picture/2016-06-27/5770f54304a43.jpg', '', '0', '9d377b10ce778c4938b3c7e2c63a229a', 'df7be9dc4f467187783aca68c7ce98e4df2172d0', '1', '1467020609', 'gh_89d5cf544493', '0');
INSERT INTO `wp_picture` VALUES ('104', '/Uploads/Picture/2016-06-27/57712693cc6b4.jpg', '', '0', 'a3ddb4d1ea442c6c654133415cd679c5', 'fc5017ac16732f750f365c4ee3f16dd6fed0cb7c', '1', '1467033235', 'gh_89d5cf544493', '0');
INSERT INTO `wp_picture` VALUES ('105', '/Uploads/Picture/2016-06-27/577126e686bd1.jpg', '', '0', 'b3d210edef129679e0ffdb9a9ae4ab47', 'f7ed5f1384d4e416e97c2e601cb87fec5456b4d1', '1', '1467033318', 'gh_89d5cf544493', '0');
INSERT INTO `wp_picture` VALUES ('106', '/Uploads/Picture/2016-06-27/5771271c853fb.jpg', '', '0', '1e099206035121c38d9f7e39956cf429', '35b2cd24908fe4bc1b28c6db85256ae4e301cdd0', '1', '1467033372', 'gh_89d5cf544493', '0');
INSERT INTO `wp_picture` VALUES ('107', '/Uploads/Picture/2016-06-27/5771276cb9832.jpg', '', '0', 'caa7c9932e1c1c6e92501dc84f32f466', '416a8150e9a4ec72f82671597ced1414f0998724', '1', '1467033452', 'gh_89d5cf544493', '0');
INSERT INTO `wp_picture` VALUES ('108', '/Uploads/Picture/2016-06-27/5771282777836.jpg', '', '0', 'c2f24064a3f5a13e42165cd64109211f', 'f6bc852c6f0cd10965df23c1f9e52e329b22bdeb', '1', '1467033639', 'gh_89d5cf544493', '0');
INSERT INTO `wp_picture` VALUES ('109', '/Uploads/Picture/2016-06-27/577128fe61379.jpg', '', '0', 'd2f04c2d132425ca9b0eeebc0721d0c1', '8cbed9ba5311adf24933c3f1e6490741c46944a4', '1', '1467033854', 'gh_89d5cf544493', '0');
INSERT INTO `wp_picture` VALUES ('110', '/Uploads/Picture/2016-06-27/5771293ce6422.jpg', '', '0', 'a6bf3c8ec45a432bef9b855fe991f682', '91608064b3ca2f1de29a2bcc6414971ea940259e', '1', '1467033916', 'gh_89d5cf544493', '0');
INSERT INTO `wp_picture` VALUES ('111', '/Uploads/Picture/2016-07-06/577c65a153fbc.jpg', '', '0', 'f16d6a581b2d9d6d9bf8918060712415', '391cba02bad466c4a369fe3a12ab70c7844e0678', '1', '1467770273', 'gh_89d5cf544493', '0');
INSERT INTO `wp_picture` VALUES ('112', '/Uploads/Picture/2016-07-06/577c667bcbbbb.jpg', '', '0', '52ad63d73126c5e163697155533bdda6', '83c69248ff0dac03fe5c3cc3074e85175fe6cfb4', '1', '1467770491', 'gh_89d5cf544493', '0');
INSERT INTO `wp_picture` VALUES ('113', '/Uploads/Picture/2016-07-06/577c66d19fc91.jpg', '', '0', 'e0fdc149283d4a62fd69f93eaa5cd56b', '5afd37f27c37c7f0936f1142e5c28d2d277ba8d8', '1', '1467770577', 'gh_89d5cf544493', '0');
INSERT INTO `wp_picture` VALUES ('114', '/Uploads/Picture/2016-07-06/577c66ff2c27b.jpg', '', '0', '9357d3b4de58cad9b8dbab73c95020ec', '63b1333aa781bbc9f0cbd6849a0f71f863fead4d', '1', '1467770622', 'gh_89d5cf544493', '0');
INSERT INTO `wp_picture` VALUES ('115', '/Uploads/Picture/2016-07-06/577c6f6d9682a.jpg', '', '0', '3b300061ca1e1f518e35796e9e3375eb', '9fdbe446dbb8bf48e80dcba1146e876ef9a9ddf7', '1', '1467772781', 'gh_89d5cf544493', '0');

-- -----------------------------
-- Table structure for `wp_picture_category`
-- -----------------------------
DROP TABLE IF EXISTS `wp_picture_category`;
;


-- -----------------------------
-- Table structure for `wp_plugin`
-- -----------------------------
DROP TABLE IF EXISTS `wp_plugin`;
;

-- -----------------------------
-- Records of `wp_plugin`
-- -----------------------------
INSERT INTO `wp_plugin` VALUES ('15', 'EditorForAdmin', '后台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"2\",\"editor_height\":\"500px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1383126253', '0', '', '1');
INSERT INTO `wp_plugin` VALUES ('2', 'SiteStat', '站点统计信息', '统计站点的基础信息', '0', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512015', '0', '', '1');
INSERT INTO `wp_plugin` VALUES ('22', 'DevTeam', '开发团队信息', '开发团队成员信息', '0', '{\"title\":\"OneThink\\u5f00\\u53d1\\u56e2\\u961f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1391687096', '0', '', '1');
INSERT INTO `wp_plugin` VALUES ('4', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512036', '0', '', '1');
INSERT INTO `wp_plugin` VALUES ('5', 'Editor', '前台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"300px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1379830910', '0', '', '1');
INSERT INTO `wp_plugin` VALUES ('9', 'SocialComment', '通用社交化评论', '集成了各种社交化评论插件，轻松集成到系统中。', '1', '{\"comment_type\":\"1\",\"comment_uid_youyan\":\"1669260\",\"comment_short_name_duoshuo\":\"\",\"comment_form_pos_duoshuo\":\"buttom\",\"comment_data_list_duoshuo\":\"10\",\"comment_data_order_duoshuo\":\"asc\"}', 'thinkphp', '0.1', '1380273962', '0', '', '1');
INSERT INTO `wp_plugin` VALUES ('58', 'Cascade', '级联菜单', '支持无级级联菜单，用于地区选择、多层分类选择等场景。菜单的数据来源支持查询数据库和直接用户按格式输入两种方式', '1', 'null', '凡星', '0.1', '1398694996', '0', '', '1');
INSERT INTO `wp_plugin` VALUES ('120', 'DynamicSelect', '动态下拉菜单', '支持动态从数据库里取值显示', '1', 'null', '凡星', '0.1', '1435223177', '0', '', '1');
INSERT INTO `wp_plugin` VALUES ('125', 'News', '图文素材选择器', '', '1', 'null', '凡星', '0.1', '1439198046', '0', '', '1');
INSERT INTO `wp_plugin` VALUES ('127', 'DynamicCheckbox', '动态多选菜单', '支持动态从数据库里取值显示', '1', 'null', '凡星', '0.1', '1464002908', '0', '', '1');
INSERT INTO `wp_plugin` VALUES ('128', 'Prize', '奖品选择', '支持多种奖品选择', '1', 'null', '凡星', '0.1', '1464060178', '0', '', '1');
INSERT INTO `wp_plugin` VALUES ('129', 'Material', '素材选择', '支持动态从素材库里选择素材', '1', 'null', '凡星', '0.1', '1464060381', '0', '', '1');

-- -----------------------------
-- Table structure for `wp_prize_address`
-- -----------------------------
DROP TABLE IF EXISTS `wp_prize_address`;
;


-- -----------------------------
-- Table structure for `wp_public`
-- -----------------------------
DROP TABLE IF EXISTS `wp_public`;
;

-- -----------------------------
-- Records of `wp_public`
-- -----------------------------
INSERT INTO `wp_public` VALUES ('1', '1', '越来悦慢', 'gh_89d5cf544493', 'UmindTown', '', '', '', '{\"Card\":{\"background\":\"11\",\"bg\":\"115\",\"title\":\"\\u6162\\u57ce\\u4f1a\\u5458\\u4e2d\\u5fc3\",\"length\":\"undefined0001\",\"instruction\":\"1\\u3001\\u6162\\u57ce\\u662f\\u4e00\\u4e2a\\u7406\\u60f3\\u57ce\\u90a6\\uff0c\\u8fd9\\u91cc\\u7684\\u5c45\\u6c11\\u90fd\\u662f\\u72ec\\u7acb\\u4e14\\u6709\\u8ffd\\u6c42\\u7684\\u3002\\r\\n2\\u3001\\u9996\\u6b21\\u767b\\u9646\\u5c31\\u53ef\\u76f4\\u63a5\\u7533\\u8bf7\\u5165\\u4f4f\\u4f53\\u9a8c\\u3002\\r\\n3\\u3001\\u8bf7\\u79ef\\u6781\\u53c2\\u52a0\\u57ce\\u4e2d\\u76f8\\u5173\\u6d3b\\u52a8\\uff0c\\u6253\\u9020O2O\\u6162\\u751f\\u6d3b\\u3002\",\"address\":\"\\u4e0a\\u6d77\\u5e02\\u6d66\\u4e1c\\u65b0\\u533a\\u5f20\\u6768\\u8def400\\u53f7\",\"phone\":\"18616742186\",\"url\":\"\",\"background_custom\":\"http:\\/\\/jasongan.cn\\/php\\/weiphp3\\/Uploads\\/Picture\\/2016-07-06\\/577c6f6d9682a.jpg\",\"bg_id\":\"115\"},\"SingIn\":{\"random\":\"1\",\"score\":\"1\",\"score1\":\"1\",\"score2\":\"2\",\"hour\":\"0\",\"minute\":\"0\",\"continue_day\":\"30\",\"continue_score\":\"5\",\"share_score\":\"1\",\"share_limit\":\"1\",\"notstart\":\"\\u4eb2\\uff0c\\u4f60\\u8d77\\u5f97\\u592a\\u65e9\\u4e86,\\u7b7e\\u5230\\u4ece[\\u5f00\\u59cb\\u65f6\\u95f4]\\u5f00\\u59cb,\\u73b0\\u5728\\u624d[\\u5f53\\u524d\\u65f6\\u95f4]\\uff01\",\"done\":\"\\u4eb2\\uff0c\\u4eca\\u5929\\u5df2\\u7ecf\\u7b7e\\u5230\\u8fc7\\u4e86\\uff0c\\u8bf7\\u660e\\u5929\\u518d\\u6765\\u54e6\\uff0c\\u8c22\\u8c22\\uff01\",\"reply\":\"\\u606d\\u559c\\u60a8,\\u7b7e\\u5230\\u6210\\u529f\\r\\n\\r\\n\\u672c\\u6b21\\u7b7e\\u5230\\u83b7\\u5f97[\\u672c\\u6b21\\u79ef\\u5206]\\u79ef\\u5206\\r\\n\\r\\n\\u5f53\\u524d\\u603b\\u79ef\\u5206[\\u79ef\\u5206\\u4f59\\u989d]\\r\\n\\r\\n[\\u7b7e\\u5230\\u65f6\\u95f4]\\r\\n\\r\\n\\u60a8\\u4eca\\u5929\\u662f\\u7b2c[\\u6392\\u540d]\\u4f4d\\u7b7e\\u5230\\r\\n\\r\\n\\u6392\\u884c\\u699c\\uff1a\\r\\n[\\u6392\\u884c\\u699c]\",\"content\":\"\"},\"NoAnswer\":{\"stype\":\"text:2\"},\"WeiSite\":{\"title\":\"\\u60a6\\u6162\\u57ce\\u6b22\\u8fce\\u60a8\",\"cover\":\"104\",\"info\":\"\",\"background\":null,\"template_index\":\"ColorV4\",\"template_lists\":\"V1\",\"template_detail\":\"V2\"},\"UserCenter\":{\"score\":\"10\",\"experience\":\"10\",\"need_bind\":\"1\",\"bind_start\":\"2\",\"jumpurl\":\"\"},\"Leaflets\":{\"title\":\"\\u8d8a\\u6765\\u60a6\\u6162\",\"img\":\"112\",\"info\":\"\\u6253\\u9020\\u6162\\u751f\\u6d3b\\u793e\\u533a\",\"copyright\":\"\\u00a92016 \\u8d8a\\u6765\\u60a6\\u6162\\u7248\\u6743\\u6240\\u6709\"}}', '', 'gh_89d5cf544493', '0', '1', 'wx2da54501250e2a6e', 'bf75b5ff4181061f4c29bafb81c9a985', '0', '', '', '', '0');

-- -----------------------------
-- Table structure for `wp_public_auth`
-- -----------------------------
DROP TABLE IF EXISTS `wp_public_auth`;
;

-- -----------------------------
-- Records of `wp_public_auth`
-- -----------------------------
INSERT INTO `wp_public_auth` VALUES ('1', 'GET_ACCESS_TOKEN', '基础支持-获取access_token', '1', '1', '1', '1');
INSERT INTO `wp_public_auth` VALUES ('2', 'GET_WECHAT_IP', '基础支持-获取微信服务器IP地址', '1', '1', '1', '1');
INSERT INTO `wp_public_auth` VALUES ('3', 'GET_MSG', '接收消息-验证消息真实性、接收普通消息、接收事件推送、接收语音识别结果', '1', '1', '1', '1');
INSERT INTO `wp_public_auth` VALUES ('4', 'SEND_REPLY_MSG', '发送消息-被动回复消息', '1', '1', '1', '1');
INSERT INTO `wp_public_auth` VALUES ('5', 'SEND_CUSTOM_MSG', '发送消息-客服接口', '0', '1', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('6', 'SEND_GROUP_MSG', '发送消息-群发接口', '0', '1', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('7', 'SEND_NOTICE', '发送消息-模板消息接口（发送业务通知）', '0', '0', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('8', 'USER_GROUP', '用户管理-用户分组管理', '0', '1', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('9', 'USER_REMARK', '用户管理-设置用户备注名', '0', '1', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('10', 'USER_BASE_INFO', '用户管理-获取用户基本信息', '0', '1', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('11', 'USER_LIST', '用户管理-获取用户列表', '0', '1', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('12', 'USER_LOCATION', '用户管理-获取用户地理位置', '0', '0', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('13', 'USER_OAUTH', '用户管理-网页授权获取用户openid/用户基本信息', '0', '0', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('14', 'QRCODE', '推广支持-生成带参数二维码', '0', '0', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('15', 'LONG_URL', '推广支持-长链接转短链接口', '0', '0', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('16', 'MENU', '界面丰富-自定义菜单', '0', '1', '1', '1');
INSERT INTO `wp_public_auth` VALUES ('17', 'MATERIAL', '素材管理-素材管理接口', '0', '1', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('18', 'SEMANTIC', '智能接口-语义理解接口', '0', '0', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('19', 'CUSTOM_SERVICE', '多客服-获取多客服消息记录、客服管理', '0', '0', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('20', 'PAYMENT', '微信支付接口', '0', '0', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('21', 'SHOP', '微信小店接口', '0', '0', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('22', 'CARD', '微信卡券接口', '0', '1', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('23', 'DEVICE', '微信设备功能接口', '0', '0', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('24', 'JSSKD_BASE', '微信JS-SDK-基础接口', '1', '1', '1', '1');
INSERT INTO `wp_public_auth` VALUES ('25', 'JSSKD_SHARE', '微信JS-SDK-分享接口', '0', '1', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('26', 'JSSKD_IMG', '微信JS-SDK-图像接口', '1', '1', '1', '1');
INSERT INTO `wp_public_auth` VALUES ('27', 'JSSKD_AUDIO', '微信JS-SDK-音频接口', '1', '1', '1', '1');
INSERT INTO `wp_public_auth` VALUES ('28', 'JSSKD_SEMANTIC', '微信JS-SDK-智能接口（网页语音识别）', '1', '1', '1', '1');
INSERT INTO `wp_public_auth` VALUES ('29', 'JSSKD_DEVICE', '微信JS-SDK-设备信息', '1', '1', '1', '1');
INSERT INTO `wp_public_auth` VALUES ('30', 'JSSKD_LOCATION', '微信JS-SDK-地理位置', '1', '1', '1', '1');
INSERT INTO `wp_public_auth` VALUES ('31', 'JSSKD_MENU', '微信JS-SDK-界面操作', '1', '1', '1', '1');
INSERT INTO `wp_public_auth` VALUES ('32', 'JSSKD_SCAN', '微信JS-SDK-微信扫一扫', '1', '1', '1', '1');
INSERT INTO `wp_public_auth` VALUES ('33', 'JSSKD_SHOP', '微信JS-SDK-微信小店', '0', '0', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('34', 'JSSKD_CARD', '微信JS-SDK-微信卡券', '0', '1', '0', '1');
INSERT INTO `wp_public_auth` VALUES ('35', 'JSSKD_PAYMENT', '微信JS-SDK-微信支付', '0', '0', '0', '1');

-- -----------------------------
-- Table structure for `wp_public_check`
-- -----------------------------
DROP TABLE IF EXISTS `wp_public_check`;
;


-- -----------------------------
-- Table structure for `wp_public_follow`
-- -----------------------------
DROP TABLE IF EXISTS `wp_public_follow`;
;

-- -----------------------------
-- Records of `wp_public_follow`
-- -----------------------------
INSERT INTO `wp_public_follow` VALUES ('oYMvgs-QpwuhTabhQGVxm_G-9VDc', 'gh_89d5cf544493', '2', '1', '2', '');
INSERT INTO `wp_public_follow` VALUES ('oYMvgs0F5Z8twiMk0-_2k7NqlLaA', 'gh_89d5cf544493', '3', '1', '2', '');
INSERT INTO `wp_public_follow` VALUES ('oYMvgszVmqhX195mQeDDN6LOkJA8', 'gh_89d5cf544493', '4', '1', '2', '');
INSERT INTO `wp_public_follow` VALUES ('oYMvgs57sUAFrL-h_pTwN7cqeHi0', 'gh_89d5cf544493', '5', '1', '2', '');
INSERT INTO `wp_public_follow` VALUES ('oYMvgsyEDncCLibJPRbvIwNPGsNA', 'gh_89d5cf544493', '6', '1', '2', '');
INSERT INTO `wp_public_follow` VALUES ('oYMvgs3LmvC57U44M9EkdBYZH1NA', 'gh_89d5cf544493', '7', '1', '2', '');
INSERT INTO `wp_public_follow` VALUES ('oYMvgs7n2HMHKM-9uQTocr3Ausvo', 'gh_89d5cf544493', '8', '1', '2', '');
INSERT INTO `wp_public_follow` VALUES ('oYMvgs5hCavfz-MNOtQgM-_Nrek4', 'gh_89d5cf544493', '9', '1', '2', '');
INSERT INTO `wp_public_follow` VALUES ('oYMvgs8VZHuvdA9ErlGyNuDxw_ds', 'gh_89d5cf544493', '10', '1', '2', '');

-- -----------------------------
-- Table structure for `wp_public_group`
-- -----------------------------
DROP TABLE IF EXISTS `wp_public_group`;
;


-- -----------------------------
-- Table structure for `wp_public_link`
-- -----------------------------
DROP TABLE IF EXISTS `wp_public_link`;
;

-- -----------------------------
-- Records of `wp_public_link`
-- -----------------------------
INSERT INTO `wp_public_link` VALUES ('1', '1', '1', '1', '', '0');

-- -----------------------------
-- Table structure for `wp_qr_admin`
-- -----------------------------
DROP TABLE IF EXISTS `wp_qr_admin`;
;


-- -----------------------------
-- Table structure for `wp_qr_code`
-- -----------------------------
DROP TABLE IF EXISTS `wp_qr_code`;
;


-- -----------------------------
-- Table structure for `wp_real_prize`
-- -----------------------------
DROP TABLE IF EXISTS `wp_real_prize`;
;

-- -----------------------------
-- Records of `wp_real_prize`
-- -----------------------------
INSERT INTO `wp_real_prize` VALUES ('1', '悦慢订制马克杯', '本轮奖品只有5份，请收到邀请的朋友们赶紧下手哦', '5', '10', 'gh_89d5cf544493', '1', '来店内领取即可', '店庆拿马克杯', '失败，请联系店内', 'default');

-- -----------------------------
-- Table structure for `wp_recharge_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_recharge_log`;
;


-- -----------------------------
-- Table structure for `wp_redbag`
-- -----------------------------
DROP TABLE IF EXISTS `wp_redbag`;
;


-- -----------------------------
-- Table structure for `wp_redbag_follow`
-- -----------------------------
DROP TABLE IF EXISTS `wp_redbag_follow`;
;


-- -----------------------------
-- Table structure for `wp_reserve`
-- -----------------------------
DROP TABLE IF EXISTS `wp_reserve`;
;


-- -----------------------------
-- Table structure for `wp_reserve_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `wp_reserve_attribute`;
;


-- -----------------------------
-- Table structure for `wp_reserve_option`
-- -----------------------------
DROP TABLE IF EXISTS `wp_reserve_option`;
;


-- -----------------------------
-- Table structure for `wp_reserve_value`
-- -----------------------------
DROP TABLE IF EXISTS `wp_reserve_value`;
;


-- -----------------------------
-- Table structure for `wp_score_exchange_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_score_exchange_log`;
;


-- -----------------------------
-- Table structure for `wp_servicer`
-- -----------------------------
DROP TABLE IF EXISTS `wp_servicer`;
;

-- -----------------------------
-- Records of `wp_servicer`
-- -----------------------------
INSERT INTO `wp_servicer` VALUES ('1', '3', '干诚远', '18616742186', '1,2,3', '1', 'gh_89d5cf544493');

-- -----------------------------
-- Table structure for `wp_share_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_share_log`;
;

-- -----------------------------
-- Records of `wp_share_log`
-- -----------------------------
INSERT INTO `wp_share_log` VALUES ('4', '1', '1467797056', 'gh_89d5cf544493', '1');
INSERT INTO `wp_share_log` VALUES ('10', '3', '1467799075', 'gh_89d5cf544493', '1');
INSERT INTO `wp_share_log` VALUES ('11', '3', '1467856491', 'gh_89d5cf544493', '1');
INSERT INTO `wp_share_log` VALUES ('12', '8', '1467857038', 'gh_89d5cf544493', '1');
INSERT INTO `wp_share_log` VALUES ('13', '0', '1467945635', 'gh_89d5cf544493', '1');
INSERT INTO `wp_share_log` VALUES ('14', '11', '1467945688', 'gh_89d5cf544493', '1');
INSERT INTO `wp_share_log` VALUES ('15', '3', '1467945941', 'gh_89d5cf544493', '1');

-- -----------------------------
-- Table structure for `wp_shop_address`
-- -----------------------------
DROP TABLE IF EXISTS `wp_shop_address`;
;


-- -----------------------------
-- Table structure for `wp_shop_coupon`
-- -----------------------------
DROP TABLE IF EXISTS `wp_shop_coupon`;
;


-- -----------------------------
-- Table structure for `wp_shop_vote`
-- -----------------------------
DROP TABLE IF EXISTS `wp_shop_vote`;
;

-- -----------------------------
-- Records of `wp_shop_vote`
-- -----------------------------
INSERT INTO `wp_shop_vote` VALUES ('1', '吉他之神评选', '1', '0', '1467005400', '1467379800', '只能选一个心中的吉他大神哦\r\n只能选一个心中的吉他大神哦\r\n只能选一个心中的吉他大神哦\r\n只能选一个心中的吉他大神哦\r\n只能选一个心中的吉他大神哦\r\n只能选一个心中的吉他大神哦', 'gh_89d5cf544493', '1', '1');

-- -----------------------------
-- Table structure for `wp_shop_vote_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_shop_vote_log`;
;


-- -----------------------------
-- Table structure for `wp_shop_vote_option`
-- -----------------------------
DROP TABLE IF EXISTS `wp_shop_vote_option`;
;

-- -----------------------------
-- Records of `wp_shop_vote_option`
-- -----------------------------
INSERT INTO `wp_shop_vote_option` VALUES ('1', '阿追', '12', '', '我最屌', '哈哈哈', '1467034512', '1', '0', 'gh_89d5cf544493', '1');
INSERT INTO `wp_shop_vote_option` VALUES ('2', '何桑', '10', '', '我最可爱', '我最可爱', '1467034534', '1', '0', 'gh_89d5cf544493', '2');

-- -----------------------------
-- Table structure for `wp_signin_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_signin_log`;
;

-- -----------------------------
-- Records of `wp_signin_log`
-- -----------------------------
INSERT INTO `wp_signin_log` VALUES ('1', '2', 'gh_89d5cf544493', '1467019861', '3');
INSERT INTO `wp_signin_log` VALUES ('21', '1', 'gh_89d5cf544493', '1467104993', '3');
INSERT INTO `wp_signin_log` VALUES ('23', '1', 'gh_89d5cf544493', '1467105124', '8');
INSERT INTO `wp_signin_log` VALUES ('24', '1', 'gh_89d5cf544493', '1467133254', '3');
INSERT INTO `wp_signin_log` VALUES ('25', '1', 'gh_89d5cf544493', '1467362777', '3');
INSERT INTO `wp_signin_log` VALUES ('26', '1', 'gh_89d5cf544493', '1467548461', '3');
INSERT INTO `wp_signin_log` VALUES ('27', '1', 'gh_89d5cf544493', '1467633604', '3');
INSERT INTO `wp_signin_log` VALUES ('28', '1', 'gh_89d5cf544493', '1467639974', '6');
INSERT INTO `wp_signin_log` VALUES ('29', '1', 'gh_89d5cf544493', '1467683860', '3');
INSERT INTO `wp_signin_log` VALUES ('30', '1', 'gh_89d5cf544493', '1467684783', '8');
INSERT INTO `wp_signin_log` VALUES ('31', '1', 'gh_89d5cf544493', '1467782020', '3');
INSERT INTO `wp_signin_log` VALUES ('32', '1', 'gh_89d5cf544493', '1467782337', '8');
INSERT INTO `wp_signin_log` VALUES ('33', '1', 'gh_89d5cf544493', '1467822627', '3');
INSERT INTO `wp_signin_log` VALUES ('34', '1', 'gh_89d5cf544493', '1467946669', '0');
INSERT INTO `wp_signin_log` VALUES ('35', '1', 'gh_89d5cf544493', '1467947165', '3');

-- -----------------------------
-- Table structure for `wp_smalltools`
-- -----------------------------
DROP TABLE IF EXISTS `wp_smalltools`;
;


-- -----------------------------
-- Table structure for `wp_sms`
-- -----------------------------
DROP TABLE IF EXISTS `wp_sms`;
;


-- -----------------------------
-- Table structure for `wp_sn_code`
-- -----------------------------
DROP TABLE IF EXISTS `wp_sn_code`;
;

-- -----------------------------
-- Records of `wp_sn_code`
-- -----------------------------
INSERT INTO `wp_sn_code` VALUES ('1', '577b70b47e336', '8', '1467707572', '0', '', 'Coupon', '1', '', '1', '', 'gh_89d5cf544493', '1', '120.27.104.159', '');
INSERT INTO `wp_sn_code` VALUES ('2', '577b7163a01c7', '3', '1467707747', '0', '', 'Coupon', '1', '', '1', '', 'gh_89d5cf544493', '1', '120.27.104.159', '');

-- -----------------------------
-- Table structure for `wp_sport_award`
-- -----------------------------
DROP TABLE IF EXISTS `wp_sport_award`;
;


-- -----------------------------
-- Table structure for `wp_sports`
-- -----------------------------
DROP TABLE IF EXISTS `wp_sports`;
;


-- -----------------------------
-- Table structure for `wp_sports_drum`
-- -----------------------------
DROP TABLE IF EXISTS `wp_sports_drum`;
;


-- -----------------------------
-- Table structure for `wp_sports_join`
-- -----------------------------
DROP TABLE IF EXISTS `wp_sports_join`;
;


-- -----------------------------
-- Table structure for `wp_sports_support`
-- -----------------------------
DROP TABLE IF EXISTS `wp_sports_support`;
;


-- -----------------------------
-- Table structure for `wp_sports_team`
-- -----------------------------
DROP TABLE IF EXISTS `wp_sports_team`;
;


-- -----------------------------
-- Table structure for `wp_store`
-- -----------------------------
DROP TABLE IF EXISTS `wp_store`;
;


-- -----------------------------
-- Table structure for `wp_sucai`
-- -----------------------------
DROP TABLE IF EXISTS `wp_sucai`;
;


-- -----------------------------
-- Table structure for `wp_sucai_template`
-- -----------------------------
DROP TABLE IF EXISTS `wp_sucai_template`;
;

-- -----------------------------
-- Records of `wp_sucai_template`
-- -----------------------------
INSERT INTO `wp_sucai_template` VALUES ('5', '1', '', 'CardVouchers', 'card_style');
INSERT INTO `wp_sucai_template` VALUES ('6', '1', '', 'Coupon', 'card_style');
INSERT INTO `wp_sucai_template` VALUES ('7', '1', '', 'RedBag', 'default');
INSERT INTO `wp_sucai_template` VALUES ('8', '1', '', 'RealPrize', 'default');
INSERT INTO `wp_sucai_template` VALUES ('9', '1', '', 'Invite', 'default');
INSERT INTO `wp_sucai_template` VALUES ('10', '1', '', 'RedBag', 'weixin');
INSERT INTO `wp_sucai_template` VALUES ('11', '1', '', 'Survey', 'default');

-- -----------------------------
-- Table structure for `wp_survey`
-- -----------------------------
DROP TABLE IF EXISTS `wp_survey`;
;


-- -----------------------------
-- Table structure for `wp_survey_answer`
-- -----------------------------
DROP TABLE IF EXISTS `wp_survey_answer`;
;


-- -----------------------------
-- Table structure for `wp_survey_question`
-- -----------------------------
DROP TABLE IF EXISTS `wp_survey_question`;
;


-- -----------------------------
-- Table structure for `wp_system_notice`
-- -----------------------------
DROP TABLE IF EXISTS `wp_system_notice`;
;


-- -----------------------------
-- Table structure for `wp_test`
-- -----------------------------
DROP TABLE IF EXISTS `wp_test`;
;


-- -----------------------------
-- Table structure for `wp_test_answer`
-- -----------------------------
DROP TABLE IF EXISTS `wp_test_answer`;
;


-- -----------------------------
-- Table structure for `wp_test_question`
-- -----------------------------
DROP TABLE IF EXISTS `wp_test_question`;
;


-- -----------------------------
-- Table structure for `wp_update_score_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_update_score_log`;
;


-- -----------------------------
-- Table structure for `wp_update_version`
-- -----------------------------
DROP TABLE IF EXISTS `wp_update_version`;
;


-- -----------------------------
-- Table structure for `wp_user`
-- -----------------------------
DROP TABLE IF EXISTS `wp_user`;
;

-- -----------------------------
-- Records of `wp_user`
-- -----------------------------
INSERT INTO `wp_user` VALUES ('2', '\"%E6%AF%85\"', '', '', '', '', '1', 'http://wx.qlogo.cn/mmopen/5zibC8jyGqiaTIAQc7zuMxFeeT3iaiaxOiaiaXicXtwuA3pT5mvLY6kbvibbKC7DMKUD9uQAgqlDsOmEfQYIrS14reCkEZ6l7MExiaNtW/0', 'Ningbo', 'Zhejiang', 'China', 'zh_CN', '10', '100', 'oLVhIxA3bj25Uuob70iWTaoW3lfo', '0', '', '1463304795', '', '', '1', '1', '1', '1463304795', '', '0', '0', '', '', '0', '0', '0');
INSERT INTO `wp_user` VALUES ('3', '\"%E9%98%BF%E8%BF%BD%28J%29\"', '', '干诚远', '18616742186', '', '1', 'http://wx.qlogo.cn/mmopen/PiajxSqBRaEL0DwUTCj5C1ylh66icRsqIiaKY9ibJqHkU7ZyMyJCnYSKTBdEchNNDkQGHpRFk4Sicqcd9qiaSRdmWQog/0', 'Yangpu', 'Shanghai', 'China', 'zh_CN', '49', '100', 'oLVhIxIxXtyt6wFF86WVAhHVmapI', '0', '', '1462350977', '', '', '1', '1', '1', '1467174312', '', '0', '0', '', '', '0', '0', '0');
INSERT INTO `wp_user` VALUES ('4', '\"l%E7%BF%8E%E6%99%A8\"', '', '', '', '', '0', '', '', '', '', 'zh_CN', '10', '100', 'oLVhIxEmjXpVKeKgEm_Z7tkyoSwA', '0', '', '1463825602', '', '', '1', '1', '1', '1463825602', '', '0', '0', '', '', '0', '0', '0');
INSERT INTO `wp_user` VALUES ('5', '\"%E5%85%89\"', '', '', '', '', '1', 'http://wx.qlogo.cn/mmopen/PiajxSqBRaEJ4YKzQqQDtfXyg0a2JNoWgm7TzG7uxAH4ZXOic1obMA3zNJ8VcMDGGuMibyFwE9XfcNdichcuA4VPrA/0', '', '', 'Andorra', 'zh_CN', '10', '100', 'oLVhIxNXqGuoQNP6-CqbO_2StoeY', '0', '', '1463292626', '', '', '1', '1', '1', '1463292626', '', '0', '0', '', '', '0', '0', '0');
INSERT INTO `wp_user` VALUES ('6', '\"Sandy+%E6%A1%91\"', '', '', '', '', '2', 'http://wx.qlogo.cn/mmopen/ajNVdqHZLLDDt9opkmeqaPlnz6px2BCvGL82nIW48dECzUsVNQtx0V1llwJXr617SY4icicS1R5tSom8XtrZIdmQ/0', 'Changning', 'Shanghai', 'China', 'zh_CN', '13', '102', 'oLVhIxEoADuLvt_jbT6VxSfs9ZMU', '0', '', '1461948197', '', '', '1', '1', '1', '1461948197', '', '0', '0', '', '', '0', '0', '0');
INSERT INTO `wp_user` VALUES ('7', '\"%E9%AB%98%E6%81%BA%E9%98%B3\"', '', '', '', '', '1', 'http://wx.qlogo.cn/mmopen/NSftsiajL4xpoPEysPvICLsfo7gvhKcOA3qwOSMCGXkO4KwQJAIgxaZl6jhviaNvpia7zRH0my0AhicHxnXvWPDW4Eho1xt2tFOr/0', '', '', 'China', 'zh_CN', '10', '100', 'oLVhIxOi8E-4GRGzJuQZ2sb6x0J4', '0', '', '1463489398', '', '', '1', '1', '1', '1463489398', '', '0', '0', '', '', '0', '0', '0');
INSERT INTO `wp_user` VALUES ('8', '\"%E4%B8%BB%E6%B2%BB%E5%8C%BB%E5%B8%88\"', '', '你好', '13732201252', '', '1', 'http://wx.qlogo.cn/mmopen/5zibC8jyGqiaQFh2CgcjkSudLoxZUdNTHs4RJL3HOSVUVVxAohTCFfXJ1UVWGtA2vV96YxKg4CpOwCneTCkZROEn0HIGfkuzlO/0', '', 'Shanghai', 'China', 'zh_CN', '36', '120', 'oLVhIxFaGuBKb3xxRdmNYJnuTe50', '0', '', '1460103169', '', '', '1', '1', '1', '1460103169', '', '0', '0', '', '', '0', '0', '0');
INSERT INTO `wp_user` VALUES ('9', '\"Helen\"', '', '', '', '', '2', 'http://wx.qlogo.cn/mmopen/7OSHt8LK2r0XF1yOtCsM3BDzZt0ZXNHTM2UXyCqshs1sgxqKxxyl3A2V2p5UHRaDiacVVEDIqRPeU49NicsBa007V3wKqkLgeK/0', '', '', 'Andorra', 'zh_CN', '10', '100', 'oLVhIxBR-eSapHrwuItaTamubCks', '0', '', '1466640510', '', '', '1', '1', '1', '1466640510', '', '0', '0', '', '', '0', '0', '0');
INSERT INTO `wp_user` VALUES ('10', '\"%E4%B8%89%E5%93%A5%7C%E4%B8%89%E8%A8%80%E4%B8%A4%E7%94%BB%7C%E6%82%A6%E6%85%A2\"', '', '', '', '', '1', 'http://wx.qlogo.cn/mmopen/NSftsiajL4xpoPEysPvICLuaPoqJlWEVicdN2eEpYB8z3TxR9RWr1fplbQve1q3DShqKcwObiaXIx1reTyx3d8RHHB9so8kqBg3/0', '', 'Shanghai', 'China', 'zh_CN', '10', '100', 'oLVhIxHS8vFhXkwGcqlLGgRWjqPw', '0', '', '1463304592', '', '', '1', '1', '1', '1463304592', '', '0', '0', '', '', '0', '0', '0');
INSERT INTO `wp_user` VALUES ('11', '\"Administrator\"', '41531e5b163beaad10177ea71006bed4', '干诚远', '18616742186', '714375410@qq.com', '', '', '', '', '', 'zh-cn', '0', '0', '', '5', '1988370232', '1467897848', '1988370232', '1467944210', '1', '1', '1', '', '', '', '0', 'Administrator', '', '0', '0', '0');

-- -----------------------------
-- Table structure for `wp_user_follow`
-- -----------------------------
DROP TABLE IF EXISTS `wp_user_follow`;
;


-- -----------------------------
-- Table structure for `wp_user_tag`
-- -----------------------------
DROP TABLE IF EXISTS `wp_user_tag`;
;


-- -----------------------------
-- Table structure for `wp_user_tag_link`
-- -----------------------------
DROP TABLE IF EXISTS `wp_user_tag_link`;
;


-- -----------------------------
-- Table structure for `wp_visit_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_visit_log`;
;

-- -----------------------------
-- Records of `wp_visit_log`
-- -----------------------------
INSERT INTO `wp_visit_log` VALUES ('471', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467639980');
INSERT INTO `wp_visit_log` VALUES ('470', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467639938');
INSERT INTO `wp_visit_log` VALUES ('469', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"credit_config\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists/model/credit_config.html', '1467639909');
INSERT INTO `wp_visit_log` VALUES ('468', '1', 'Home', 'CreditConfig', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"3\",\"model\":\"14\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/edit/id/3/model/14.html', '1467639899');
INSERT INTO `wp_visit_log` VALUES ('467', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists.html', '1467639896');
INSERT INTO `wp_visit_log` VALUES ('466', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists/uid/10.html', '1467639892');
INSERT INTO `wp_visit_log` VALUES ('465', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467639886');
INSERT INTO `wp_visit_log` VALUES ('464', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467639869');
INSERT INTO `wp_visit_log` VALUES ('463', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467639863');
INSERT INTO `wp_visit_log` VALUES ('462', '1', 'Home', 'Public', 'lists', '1', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467639858');
INSERT INTO `wp_visit_log` VALUES ('461', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467638548');
INSERT INTO `wp_visit_log` VALUES ('460', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467638006');
INSERT INTO `wp_visit_log` VALUES ('459', '1', 'Home', 'Public', 'lists', '1', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467638002');
INSERT INTO `wp_visit_log` VALUES ('458', '1', 'Weiba', 'Weiba', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Weiba/Weiba/lists.html&mdm=358', '1467637996');
INSERT INTO `wp_visit_log` VALUES ('457', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467637990');
INSERT INTO `wp_visit_log` VALUES ('456', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467637238');
INSERT INTO `wp_visit_log` VALUES ('455', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/CreditConfig/lists.html&mdm=15|42', '1467637233');
INSERT INTO `wp_visit_log` VALUES ('454', '1', 'Home', 'AuthGroup', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/AuthGroup/lists.html&mdm=15|41', '1467637230');
INSERT INTO `wp_visit_log` VALUES ('453', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists.html', '1467637227');
INSERT INTO `wp_visit_log` VALUES ('452', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467637219');
INSERT INTO `wp_visit_log` VALUES ('451', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists.html', '1467633880');
INSERT INTO `wp_visit_log` VALUES ('450', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists/uid/8.html', '1467633876');
INSERT INTO `wp_visit_log` VALUES ('449', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists/uid/8.html', '1467633869');
INSERT INTO `wp_visit_log` VALUES ('448', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15|16', '1467633866');
INSERT INTO `wp_visit_log` VALUES ('447', '1', 'UserCenter', 'UserCenter', 'detail', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/detail/uid/8.html', '1467633865');
INSERT INTO `wp_visit_log` VALUES ('446', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15|16', '1467633857');
INSERT INTO `wp_visit_log` VALUES ('445', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467633852');
INSERT INTO `wp_visit_log` VALUES ('444', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467633848');
INSERT INTO `wp_visit_log` VALUES ('443', '1', 'WeiSite', 'WeiSite', 'index', '0', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs7n2HMHKM-9uQTocr3Ausvo\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs7n2HMHKM-9uQTocr3Ausvo.html&openid=oYMvgs7n2HMHKM-9uQTocr3Ausvo', '1467633845');
INSERT INTO `wp_visit_log` VALUES ('442', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467633778');
INSERT INTO `wp_visit_log` VALUES ('441', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"credit_config\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists/model/credit_config.html', '1467633772');
INSERT INTO `wp_visit_log` VALUES ('440', '1', 'Home', 'CreditConfig', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"44\",\"model\":\"14\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/edit/id/44/model/14.html', '1467633763');
INSERT INTO `wp_visit_log` VALUES ('439', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists.html', '1467633755');
INSERT INTO `wp_visit_log` VALUES ('438', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', '{\"sidenav\":\"home_creditconfig_lists\",\"p\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists/sidenav/home_creditconfig_lists/p/2.html', '1467633741');
INSERT INTO `wp_visit_log` VALUES ('437', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467633726');
INSERT INTO `wp_visit_log` VALUES ('436', '1', 'Home', 'CreditConfig', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"44\",\"model\":\"14\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/edit/id/44/model/14/mdm/15|42.html', '1467633722');
INSERT INTO `wp_visit_log` VALUES ('435', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/CreditConfig/lists.html&mdm=15|42', '1467633714');
INSERT INTO `wp_visit_log` VALUES ('434', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists.html', '1467633706');
INSERT INTO `wp_visit_log` VALUES ('433', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467633701');
INSERT INTO `wp_visit_log` VALUES ('432', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467633694');
INSERT INTO `wp_visit_log` VALUES ('431', '1', 'WeiSite', 'WeiSite', 'index', '0', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467633689');
INSERT INTO `wp_visit_log` VALUES ('430', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467633652');
INSERT INTO `wp_visit_log` VALUES ('429', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists.html', '1467633638');
INSERT INTO `wp_visit_log` VALUES ('428', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists/uid/10.html', '1467633635');
INSERT INTO `wp_visit_log` VALUES ('427', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467633627');
INSERT INTO `wp_visit_log` VALUES ('426', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"8\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/8.html', '1467633486');
INSERT INTO `wp_visit_log` VALUES ('425', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467633470');
INSERT INTO `wp_visit_log` VALUES ('424', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467633463');
INSERT INTO `wp_visit_log` VALUES ('423', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"9\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/9.html', '1467633453');
INSERT INTO `wp_visit_log` VALUES ('422', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"34\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/34.html', '1467633443');
INSERT INTO `wp_visit_log` VALUES ('421', '1', 'CustomMenu', 'CustomMenu', 'add', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/add.html', '1467633406');
INSERT INTO `wp_visit_log` VALUES ('420', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467633317');
INSERT INTO `wp_visit_log` VALUES ('419', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467633311');
INSERT INTO `wp_visit_log` VALUES ('418', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"8\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/8.html', '1467633287');
INSERT INTO `wp_visit_log` VALUES ('417', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467633267');
INSERT INTO `wp_visit_log` VALUES ('416', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467633262');
INSERT INTO `wp_visit_log` VALUES ('415', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"8\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/8.html', '1467633256');
INSERT INTO `wp_visit_log` VALUES ('414', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467633249');
INSERT INTO `wp_visit_log` VALUES ('413', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"8\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/8.html', '1467633208');
INSERT INTO `wp_visit_log` VALUES ('412', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467633166');
INSERT INTO `wp_visit_log` VALUES ('411', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467633160');
INSERT INTO `wp_visit_log` VALUES ('410', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"8\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/8.html', '1467633125');
INSERT INTO `wp_visit_log` VALUES ('409', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"34\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/34.html', '1467633118');
INSERT INTO `wp_visit_log` VALUES ('408', '1', 'CustomMenu', 'CustomMenu', 'add', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/add.html', '1467633099');
INSERT INTO `wp_visit_log` VALUES ('407', '1', 'CustomMenu', 'CustomMenu', 'add', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/add.html', '1467632985');
INSERT INTO `wp_visit_log` VALUES ('406', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632980');
INSERT INTO `wp_visit_log` VALUES ('405', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"7\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/7.html', '1467632966');
INSERT INTO `wp_visit_log` VALUES ('404', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists.html&mdm=45|47', '1467632962');
INSERT INTO `wp_visit_log` VALUES ('403', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467632959');
INSERT INTO `wp_visit_log` VALUES ('402', '1', 'SingIn', 'SingIn', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/SingIn/SingIn/config.html', '1467632795');
INSERT INTO `wp_visit_log` VALUES ('401', '1', 'SingIn', 'SingIn', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/SingIn/SingIn/config.html', '1467632775');
INSERT INTO `wp_visit_log` VALUES ('400', '1', 'SingIn', 'SingIn', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/SingIn/SingIn/config.html', '1467632757');
INSERT INTO `wp_visit_log` VALUES ('399', '1', 'SingIn', 'SingIn', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/SingIn/SingIn/lists.html', '1467632747');
INSERT INTO `wp_visit_log` VALUES ('398', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467632726');
INSERT INTO `wp_visit_log` VALUES ('397', '1', 'Home', 'Public', 'lists', '1', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467632722');
INSERT INTO `wp_visit_log` VALUES ('396', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632694');
INSERT INTO `wp_visit_log` VALUES ('395', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632688');
INSERT INTO `wp_visit_log` VALUES ('394', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632684');
INSERT INTO `wp_visit_log` VALUES ('393', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632618');
INSERT INTO `wp_visit_log` VALUES ('392', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/4.html', '1467632605');
INSERT INTO `wp_visit_log` VALUES ('391', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632596');
INSERT INTO `wp_visit_log` VALUES ('390', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/2.html', '1467632579');
INSERT INTO `wp_visit_log` VALUES ('389', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"34\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/34.html', '1467632573');
INSERT INTO `wp_visit_log` VALUES ('388', '1', 'CustomMenu', 'CustomMenu', 'add', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/add.html', '1467632545');
INSERT INTO `wp_visit_log` VALUES ('387', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632530');
INSERT INTO `wp_visit_log` VALUES ('386', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632509');
INSERT INTO `wp_visit_log` VALUES ('385', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/2.html', '1467632484');
INSERT INTO `wp_visit_log` VALUES ('384', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632470');
INSERT INTO `wp_visit_log` VALUES ('383', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"3\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/3.html', '1467632459');
INSERT INTO `wp_visit_log` VALUES ('382', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632396');
INSERT INTO `wp_visit_log` VALUES ('381', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/4.html', '1467632388');
INSERT INTO `wp_visit_log` VALUES ('380', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632385');
INSERT INTO `wp_visit_log` VALUES ('379', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/2.html', '1467632377');
INSERT INTO `wp_visit_log` VALUES ('378', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632367');
INSERT INTO `wp_visit_log` VALUES ('377', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"3\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/3.html', '1467632354');
INSERT INTO `wp_visit_log` VALUES ('376', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632333');
INSERT INTO `wp_visit_log` VALUES ('375', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/4.html', '1467632300');
INSERT INTO `wp_visit_log` VALUES ('374', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632297');
INSERT INTO `wp_visit_log` VALUES ('373', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632286');
INSERT INTO `wp_visit_log` VALUES ('372', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632278');
INSERT INTO `wp_visit_log` VALUES ('371', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/2.html', '1467632253');
INSERT INTO `wp_visit_log` VALUES ('370', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632239');
INSERT INTO `wp_visit_log` VALUES ('369', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"3\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/3.html', '1467632221');
INSERT INTO `wp_visit_log` VALUES ('368', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467632215');
INSERT INTO `wp_visit_log` VALUES ('367', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/1.html', '1467632171');
INSERT INTO `wp_visit_log` VALUES ('366', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists.html&mdm=45|47', '1467632154');
INSERT INTO `wp_visit_log` VALUES ('365', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467632151');
INSERT INTO `wp_visit_log` VALUES ('133', '1', 'WeiSite', 'WeiSite', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/config.html&mdm=31', '1467033025');
INSERT INTO `wp_visit_log` VALUES ('134', '1', 'WeiSite', 'WeiSite', 'index', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/publicid/1.html', '1467033075');
INSERT INTO `wp_visit_log` VALUES ('135', '1', 'WeiSite', 'WeiSite', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/config.html&mdm=31', '1467033246');
INSERT INTO `wp_visit_log` VALUES ('136', '1', 'WeiSite', 'Template', 'index', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/index.html&mdm=31|33', '1467033249');
INSERT INTO `wp_visit_log` VALUES ('137', '1', 'WeiSite', 'Slideshow', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Slideshow/lists.html&mdm=31|33', '1467033257');
INSERT INTO `wp_visit_log` VALUES ('138', '1', 'WeiSite', 'Slideshow', 'add', '1', '118.132.208.72', 'Google', '{\"model\":\"102\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Slideshow/add/model/102/mdm/31%7C33.html', '1467033263');
INSERT INTO `wp_visit_log` VALUES ('139', '1', 'WeiSite', 'Slideshow', 'lists', '1', '118.132.208.72', 'Google', '{\"model\":\"102\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Slideshow/lists/model/102/mdm/31%7C33.html', '1467033328');
INSERT INTO `wp_visit_log` VALUES ('140', '1', 'WeiSite', 'Category', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Category/lists/mdm/31%7C33.html', '1467033332');
INSERT INTO `wp_visit_log` VALUES ('141', '1', 'WeiSite', 'Category', 'add', '1', '118.132.208.72', 'Google', '{\"model\":\"99\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Category/add/model/99/mdm/31%7C33.html', '1467033336');
INSERT INTO `wp_visit_log` VALUES ('142', '1', 'WeiSite', 'Category', 'lists', '1', '118.132.208.72', 'Google', '{\"model\":\"99\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Category/lists/model/99/mdm/31%7C33.html', '1467033386');
INSERT INTO `wp_visit_log` VALUES ('143', '1', 'WeiSite', 'WeiSite', 'index', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/publicid/1.html', '1467033391');
INSERT INTO `wp_visit_log` VALUES ('144', '1', 'WeiSite', 'Template', 'index', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/index/mdm/31%7C33.html', '1467033398');
INSERT INTO `wp_visit_log` VALUES ('145', '1', 'WeiSite', 'Slideshow', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Slideshow/lists.html&mdm=31|33', '1467033402');
INSERT INTO `wp_visit_log` VALUES ('146', '1', 'WeiSite', 'WeiSite', 'index', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/publicid/1.html', '1467033403');
INSERT INTO `wp_visit_log` VALUES ('147', '1', 'WeiSite', 'Slideshow', 'edit', '1', '118.132.208.72', 'Google', '{\"id\":\"1\",\"model\":\"102\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Slideshow/edit/id/1/model/102/mdm/31|33.html', '1467033413');
INSERT INTO `wp_visit_log` VALUES ('148', '1', 'WeiSite', 'WeiSite', 'index', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/publicid/1.html', '1467033457');
INSERT INTO `wp_visit_log` VALUES ('149', '1', 'WeiSite', 'Slideshow', 'lists', '1', '118.132.208.72', 'Google', '{\"model\":\"102\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Slideshow/lists/model/102/mdm/31%7C33.html', '1467033459');
INSERT INTO `wp_visit_log` VALUES ('150', '1', 'WeiSite', 'Template', 'index', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/index/mdm/31%7C33.html', '1467033466');
INSERT INTO `wp_visit_log` VALUES ('151', '1', 'WeiSite', 'Slideshow', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Slideshow/lists.html&mdm=31|33', '1467033472');
INSERT INTO `wp_visit_log` VALUES ('152', '1', 'WeiSite', 'WeiSite', 'index', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/publicid/1.html', '1467033475');
INSERT INTO `wp_visit_log` VALUES ('153', '1', 'WeiSite', 'Category', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Category/lists/mdm/31%7C33.html', '1467033630');
INSERT INTO `wp_visit_log` VALUES ('154', '1', 'WeiSite', 'Category', 'edit', '1', '118.132.208.72', 'Google', '{\"id\":\"1\",\"model\":\"99\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Category/edit/id/1/model/99/mdm/31|33.html', '1467033632');
INSERT INTO `wp_visit_log` VALUES ('155', '1', 'WeiSite', 'Category', 'lists', '1', '118.132.208.72', 'Google', '{\"model\":\"99\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Category/lists/model/99/mdm/31%7C33.html', '1467033647');
INSERT INTO `wp_visit_log` VALUES ('156', '1', 'WeiSite', 'WeiSite', 'index', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/publicid/1.html', '1467033668');
INSERT INTO `wp_visit_log` VALUES ('157', '1', 'WeiSite', 'Category', 'add', '1', '118.132.208.72', 'Google', '{\"model\":\"99\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Category/add/model/99/mdm/31%7C33.html', '1467033739');
INSERT INTO `wp_visit_log` VALUES ('158', '1', 'WeiSite', 'Category', 'lists', '1', '118.132.208.72', 'Google', '{\"model\":\"99\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Category/lists/model/99/mdm/31%7C33.html', '1467033861');
INSERT INTO `wp_visit_log` VALUES ('159', '1', 'WeiSite', 'WeiSite', 'index', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/publicid/1.html', '1467033862');
INSERT INTO `wp_visit_log` VALUES ('160', '1', 'WeiSite', 'Category', 'edit', '1', '118.132.208.72', 'Google', '{\"id\":\"2\",\"model\":\"99\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Category/edit/id/2/model/99/mdm/31|33.html', '1467033909');
INSERT INTO `wp_visit_log` VALUES ('161', '1', 'WeiSite', 'WeiSite', 'index', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/publicid/1.html', '1467033932');
INSERT INTO `wp_visit_log` VALUES ('162', '1', 'WeiSite', 'Category', 'lists', '1', '118.132.208.72', 'Google', '{\"model\":\"99\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Category/lists/model/99/mdm/31%7C33.html', '1467033932');
INSERT INTO `wp_visit_log` VALUES ('163', '1', 'WeiSite', 'WeiSite', 'index', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/publicid/1.html', '1467034025');
INSERT INTO `wp_visit_log` VALUES ('164', '1', 'Vote', 'ShopVote', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/lists.html&mdm=17|345', '1467034031');
INSERT INTO `wp_visit_log` VALUES ('165', '1', 'Vote', 'ShopVote', 'add', '1', '118.132.208.72', 'Google', '{\"model\":\"163\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/add/model/163/mdm/17%7C345.html', '1467034041');
INSERT INTO `wp_visit_log` VALUES ('166', '1', 'Vote', 'ShopVote', 'add', '1', '118.132.208.72', 'Google', '{\"model\":\"163\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/add/model/163/mdm/17%7C345.html', '1467034412');
INSERT INTO `wp_visit_log` VALUES ('167', '1', 'WishCard', 'WishCard', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WishCard/WishCard/lists.html&mdm=17|25', '1467034420');
INSERT INTO `wp_visit_log` VALUES ('168', '1', 'Vote', 'ShopVote', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/lists.html&mdm=17|345', '1467034425');
INSERT INTO `wp_visit_log` VALUES ('169', '1', 'Vote', 'Vote', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/lists.html&mdm=17|18', '1467034427');
INSERT INTO `wp_visit_log` VALUES ('170', '1', 'Vote', 'ShopVote', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/lists.html&mdm=17|345', '1467034430');
INSERT INTO `wp_visit_log` VALUES ('171', '1', 'Vote', 'ShopVote', 'add', '1', '118.132.208.72', 'Google', '{\"model\":\"163\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/add/model/163/mdm/17%7C345.html', '1467034432');
INSERT INTO `wp_visit_log` VALUES ('172', '1', 'Vote', 'ShopVote', 'lists', '1', '118.132.208.72', 'Google', '{\"model\":\"163\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/lists/model/163/mdm/17%7C345.html', '1467034471');
INSERT INTO `wp_visit_log` VALUES ('173', '1', 'Vote', 'ShopVote', 'option_lists', '1', '118.132.208.72', 'Google', '{\"vote_id\":\"1\",\"model\":\"163\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/option_lists/vote_id/1/model/163/mdm/17|345.html', '1467034484');
INSERT INTO `wp_visit_log` VALUES ('174', '1', 'Vote', 'ShopVote', 'option_add', '1', '118.132.208.72', 'Google', '{\"vote_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/option_add/mdm/17%7C345/vote_id/1.html', '1467034486');
INSERT INTO `wp_visit_log` VALUES ('175', '1', 'Vote', 'ShopVote', 'option_lists', '1', '118.132.208.72', 'Google', '{\"model\":\"shop_vote_option\",\"vote_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/option_lists/model/shop_vote_option/vote_id/1/mdm/17%7C345.html', '1467034515');
INSERT INTO `wp_visit_log` VALUES ('176', '1', 'Vote', 'ShopVote', 'option_add', '1', '118.132.208.72', 'Google', '{\"vote_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/option_add/mdm/17%7C345/vote_id/1.html', '1467034518');
INSERT INTO `wp_visit_log` VALUES ('177', '1', 'Vote', 'ShopVote', 'option_lists', '1', '118.132.208.72', 'Google', '{\"model\":\"shop_vote_option\",\"vote_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/option_lists/model/shop_vote_option/vote_id/1/mdm/17%7C345.html', '1467034537');
INSERT INTO `wp_visit_log` VALUES ('178', '1', 'Vote', 'ShopVote', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/lists/mdm/17%7C345.html', '1467034541');
INSERT INTO `wp_visit_log` VALUES ('179', '1', 'Vote', 'ShopVote', 'edit', '1', '118.132.208.72', 'Google', '{\"id\":\"1\",\"model\":\"163\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/edit/id/1/model/163/mdm/17|345.html', '1467034545');
INSERT INTO `wp_visit_log` VALUES ('180', '1', 'Vote', 'ShopVote', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/lists/mdm/17%7C345.html', '1467034548');
INSERT INTO `wp_visit_log` VALUES ('181', '1', 'Vote', 'ShopVote', 'edit', '1', '118.132.208.72', 'Google', '{\"id\":\"1\",\"model\":\"163\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/edit/id/1/model/163/mdm/17|345.html', '1467034567');
INSERT INTO `wp_visit_log` VALUES ('182', '1', 'Vote', 'ShopVote', 'lists', '1', '118.132.208.72', 'Google', '{\"model\":\"163\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/ShopVote/lists/model/163/mdm/17%7C345.html', '1467034577');
INSERT INTO `wp_visit_log` VALUES ('183', '1', 'Vote', 'Vote', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/lists.html&mdm=17|18', '1467034772');
INSERT INTO `wp_visit_log` VALUES ('184', '1', 'Vote', 'Vote', 'add', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/add.html', '1467034775');
INSERT INTO `wp_visit_log` VALUES ('185', '1', 'Vote', 'Vote', 'lists', '1', '118.132.208.72', 'Google', '{\"model\":\"vote\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/lists/model/vote.html', '1467034843');
INSERT INTO `wp_visit_log` VALUES ('186', '1', 'Vote', 'Vote', 'index', '3', '118.132.208.72', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/index/id/1.html', '1467034872');
INSERT INTO `wp_visit_log` VALUES ('187', '1', 'Reserve', 'Reserve', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Reserve/Reserve/lists.html&mdm=17|349', '1467035069');
INSERT INTO `wp_visit_log` VALUES ('188', '1', 'HelpOpen', 'HelpOpen', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/HelpOpen/HelpOpen/lists.html&mdm=17|343', '1467035072');
INSERT INTO `wp_visit_log` VALUES ('189', '1', 'Ask', 'Ask', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/lists.html&mdm=17|353', '1467035078');
INSERT INTO `wp_visit_log` VALUES ('190', '1', 'Home', 'Public', 'lists', '1', '118.132.208.72', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467035107');
INSERT INTO `wp_visit_log` VALUES ('191', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467035112');
INSERT INTO `wp_visit_log` VALUES ('192', '1', 'Comment', 'Comment', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Comment/Comment/lists.html', '1467035118');
INSERT INTO `wp_visit_log` VALUES ('193', '1', 'Comment', 'Comment', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Comment/Comment/config.html', '1467035121');
INSERT INTO `wp_visit_log` VALUES ('194', '1', 'Comment', 'Comment', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Comment/Comment/lists.html', '1467035127');
INSERT INTO `wp_visit_log` VALUES ('195', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467035128');
INSERT INTO `wp_visit_log` VALUES ('196', '1', 'Servicer', 'Servicer', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Servicer/Servicer/lists.html', '1467035145');
INSERT INTO `wp_visit_log` VALUES ('197', '1', 'Servicer', 'Servicer', 'add', '1', '118.132.208.72', 'Google', '{\"model\":\"1153\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Servicer/Servicer/add/model/1153.html', '1467035168');
INSERT INTO `wp_visit_log` VALUES ('198', '1', 'Servicer', 'Servicer', 'lists', '1', '118.132.208.72', 'Google', '{\"model\":\"1153\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Servicer/Servicer/lists/model/1153.html', '1467035194');
INSERT INTO `wp_visit_log` VALUES ('199', '1', 'Home', 'Public', 'lists', '1', '118.132.208.72', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467035223');
INSERT INTO `wp_visit_log` VALUES ('200', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467035229');
INSERT INTO `wp_visit_log` VALUES ('201', '1', 'Game', 'Game', 'nulldeal', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Game/Game/nulldeal.html', '1467035240');
INSERT INTO `wp_visit_log` VALUES ('202', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467035242');
INSERT INTO `wp_visit_log` VALUES ('203', '1', 'RedBag', 'RedBag', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/RedBag/RedBag/lists.html', '1467035246');
INSERT INTO `wp_visit_log` VALUES ('204', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467035250');
INSERT INTO `wp_visit_log` VALUES ('205', '1', 'WishCard', 'WishCard', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WishCard/WishCard/lists.html', '1467035253');
INSERT INTO `wp_visit_log` VALUES ('206', '1', 'WishCard', 'WishCard', 'add', '1', '118.132.208.72', 'Google', '{\"model\":\"104\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WishCard/WishCard/add/model/104.html', '1467035258');
INSERT INTO `wp_visit_log` VALUES ('207', '1', 'WishCard', 'WishCardContent', 'add', '1', '118.132.208.72', 'Google', '{\"model\":\"wish_card_content\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WishCard/WishCardContent/add/model/wish_card_content.html', '1467035265');
INSERT INTO `wp_visit_log` VALUES ('208', '1', 'WishCard', 'WishCard', 'lists', '1', '118.132.208.72', 'Google', '{\"model\":\"wish_card\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WishCard/WishCard/lists/model/wish_card.html', '1467035348');
INSERT INTO `wp_visit_log` VALUES ('209', '1', 'WishCard', 'Wap', 'card_show', '1', '118.132.208.72', 'Google', '{\"id\":\"1\",\"model\":\"wish_card\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WishCard/Wap/card_show/id/1/model/wish_card.html', '1467035354');
INSERT INTO `wp_visit_log` VALUES ('210', '1', 'WishCard', 'Wap', 'card_type', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WishCard/Wap/card_type.html', '1467035359');
INSERT INTO `wp_visit_log` VALUES ('211', '1', 'WishCard', 'Wap', 'card_show', '1', '118.132.208.72', 'Google', '{\"id\":\"1\",\"model\":\"wish_card\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WishCard/Wap/card_show/id/1/model/wish_card.html', '1467035462');
INSERT INTO `wp_visit_log` VALUES ('212', '1', 'HelpOpen', 'HelpOpen', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/HelpOpen/HelpOpen/lists.html&mdm=17|343', '1467035483');
INSERT INTO `wp_visit_log` VALUES ('213', '1', 'Home', 'Public', 'lists', '1', '118.132.208.72', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467035488');
INSERT INTO `wp_visit_log` VALUES ('214', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467035493');
INSERT INTO `wp_visit_log` VALUES ('215', '1', 'Ask', 'Ask', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/lists.html', '1467035549');
INSERT INTO `wp_visit_log` VALUES ('216', '1', 'Home', 'Public', 'lists', '1', '118.132.208.72', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467035556');
INSERT INTO `wp_visit_log` VALUES ('217', '1', 'Home', 'Public', 'check_res', '1', '118.132.208.72', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/check_res/id/1.html', '1467035567');
INSERT INTO `wp_visit_log` VALUES ('218', '1', 'Home', 'Public', 'lists', '1', '118.132.208.72', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467035570');
INSERT INTO `wp_visit_log` VALUES ('219', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467035575');
INSERT INTO `wp_visit_log` VALUES ('220', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467035859');
INSERT INTO `wp_visit_log` VALUES ('221', '1', 'Home', 'Public', 'lists', '1', '118.132.208.72', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467035882');
INSERT INTO `wp_visit_log` VALUES ('222', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467035887');
INSERT INTO `wp_visit_log` VALUES ('223', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467035892');
INSERT INTO `wp_visit_log` VALUES ('224', '1', 'Card', 'Card', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467035898');
INSERT INTO `wp_visit_log` VALUES ('225', '1', 'Card', 'Member', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists.html', '1467035907');
INSERT INTO `wp_visit_log` VALUES ('226', '1', 'Card', 'Card', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html', '1467035914');
INSERT INTO `wp_visit_log` VALUES ('227', '1', 'Card', 'Notice', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Notice/lists.html', '1467035932');
INSERT INTO `wp_visit_log` VALUES ('228', '1', 'Card', 'Card', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html', '1467035939');
INSERT INTO `wp_visit_log` VALUES ('229', '1', 'Home', 'WeixinMessage', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/WeixinMessage/lists.html&mdm=15|44', '1467035947');
INSERT INTO `wp_visit_log` VALUES ('230', '1', 'Home', 'WeixinMessage', 'deal', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/WeixinMessage/deal/mdm/15%7C44.html', '1467035951');
INSERT INTO `wp_visit_log` VALUES ('231', '1', 'Home', 'WeixinMessage', 'collect', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/WeixinMessage/collect/mdm/15%7C44.html', '1467035955');
INSERT INTO `wp_visit_log` VALUES ('232', '1', 'Home', 'UserTag', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/UserTag/lists.html&mdm=15|362', '1467035957');
INSERT INTO `wp_visit_log` VALUES ('233', '1', 'Card', 'Card', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467035961');
INSERT INTO `wp_visit_log` VALUES ('234', '1', 'WeiSite', 'WeiSite', 'index', '0', '118.132.208.72', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467036786');
INSERT INTO `wp_visit_log` VALUES ('235', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.208.72', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467036815');
INSERT INTO `wp_visit_log` VALUES ('236', '1', 'WeiSite', 'WeiSite', 'index', '0', '118.132.208.72', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467036828');
INSERT INTO `wp_visit_log` VALUES ('237', '1', 'Guess', 'Guess', 'index', '3', '118.132.208.72', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html', '1467036865');
INSERT INTO `wp_visit_log` VALUES ('238', '1', 'Home', 'Public', 'lists', '1', '118.132.208.72', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467037158');
INSERT INTO `wp_visit_log` VALUES ('239', '1', 'Home', 'Public', 'add', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/add.html', '1467037165');
INSERT INTO `wp_visit_log` VALUES ('240', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.208.72', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467045171');
INSERT INTO `wp_visit_log` VALUES ('241', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.208.72', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467045176');
INSERT INTO `wp_visit_log` VALUES ('242', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.208.72', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467045188');
INSERT INTO `wp_visit_log` VALUES ('243', '1', 'WeiSite', 'WeiSite', 'index', '0', '118.132.208.72', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467095178');
INSERT INTO `wp_visit_log` VALUES ('244', '1', 'Guess', 'Guess', 'index', '3', '118.132.208.72', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html', '1467095329');
INSERT INTO `wp_visit_log` VALUES ('245', '1', 'Guess', 'Guess', 'index', '3', '118.132.208.72', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html', '1467095342');
INSERT INTO `wp_visit_log` VALUES ('246', '1', 'Guess', 'Guess', 'index', '3', '118.132.208.72', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html', '1467095354');
INSERT INTO `wp_visit_log` VALUES ('247', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467100326');
INSERT INTO `wp_visit_log` VALUES ('248', '1', 'Payment', 'Payment', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Payment/Payment/lists.html', '1467100340');
INSERT INTO `wp_visit_log` VALUES ('249', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467100351');
INSERT INTO `wp_visit_log` VALUES ('250', '1', 'Comment', 'Comment', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Comment/Comment/lists.html', '1467100582');
INSERT INTO `wp_visit_log` VALUES ('251', '1', 'Comment', 'Comment', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Comment/Comment/config.html', '1467100585');
INSERT INTO `wp_visit_log` VALUES ('252', '1', 'Comment', 'Comment', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Comment/Comment/lists.html', '1467100590');
INSERT INTO `wp_visit_log` VALUES ('253', '1', 'Comment', 'Comment', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Comment/Comment/config.html', '1467100599');
INSERT INTO `wp_visit_log` VALUES ('254', '1', 'Comment', 'Comment', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Comment/Comment/lists.html', '1467100601');
INSERT INTO `wp_visit_log` VALUES ('255', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467100602');
INSERT INTO `wp_visit_log` VALUES ('256', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467101096');
INSERT INTO `wp_visit_log` VALUES ('257', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html', '1467101099');
INSERT INTO `wp_visit_log` VALUES ('258', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html', '1467101198');
INSERT INTO `wp_visit_log` VALUES ('259', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/CreditConfig/lists.html&mdm=15|42', '1467101337');
INSERT INTO `wp_visit_log` VALUES ('260', '1', 'Home', 'CreditConfig', 'edit', '1', '118.132.208.72', 'Google', '{\"id\":\"11\",\"model\":\"14\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/edit/id/11/model/14/mdm/15|42.html', '1467101343');
INSERT INTO `wp_visit_log` VALUES ('261', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.208.72', 'Google', '{\"model\":\"credit_config\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists/model/credit_config.html', '1467101352');
INSERT INTO `wp_visit_log` VALUES ('262', '1', 'Home', 'Public', 'lists', '1', '118.132.208.72', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467101367');
INSERT INTO `wp_visit_log` VALUES ('263', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467101371');
INSERT INTO `wp_visit_log` VALUES ('264', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467101391');
INSERT INTO `wp_visit_log` VALUES ('265', '1', 'WeiSite', 'WeiSite', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/config.html&mdm=31', '1467101394');
INSERT INTO `wp_visit_log` VALUES ('266', '1', 'Vote', 'Vote', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/lists.html&mdm=17', '1467101399');
INSERT INTO `wp_visit_log` VALUES ('267', '1', 'Home', 'Public', 'lists', '1', '118.132.208.72', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467101408');
INSERT INTO `wp_visit_log` VALUES ('268', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467101412');
INSERT INTO `wp_visit_log` VALUES ('269', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467101940');
INSERT INTO `wp_visit_log` VALUES ('270', '1', 'Home', 'Public', 'lists', '1', '118.132.208.72', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467102774');
INSERT INTO `wp_visit_log` VALUES ('271', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467102777');
INSERT INTO `wp_visit_log` VALUES ('272', '1', 'SingIn', 'SingIn', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/SingIn/SingIn/lists.html', '1467102780');
INSERT INTO `wp_visit_log` VALUES ('273', '1', 'SingIn', 'SingIn', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/SingIn/SingIn/config.html', '1467102789');
INSERT INTO `wp_visit_log` VALUES ('274', '1', 'Home', 'Public', 'lists', '1', '118.132.208.72', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467105170');
INSERT INTO `wp_visit_log` VALUES ('275', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467105175');
INSERT INTO `wp_visit_log` VALUES ('276', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html', '1467105181');
INSERT INTO `wp_visit_log` VALUES ('277', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html', '1467105193');
INSERT INTO `wp_visit_log` VALUES ('278', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467171714');
INSERT INTO `wp_visit_log` VALUES ('279', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html', '1467171717');
INSERT INTO `wp_visit_log` VALUES ('280', '1', 'QrAdmin', 'QrAdmin', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/QrAdmin/QrAdmin/lists.html&mdm=15|363', '1467171724');
INSERT INTO `wp_visit_log` VALUES ('281', '1', 'Home', 'Public', 'lists', '1', '118.132.208.72', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467171728');
INSERT INTO `wp_visit_log` VALUES ('282', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467171732');
INSERT INTO `wp_visit_log` VALUES ('283', '1', 'RedBag', 'RedBag', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/RedBag/RedBag/lists.html', '1467171743');
INSERT INTO `wp_visit_log` VALUES ('284', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467171746');
INSERT INTO `wp_visit_log` VALUES ('285', '1', 'Card', 'Card', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html', '1467171753');
INSERT INTO `wp_visit_log` VALUES ('286', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467171754');
INSERT INTO `wp_visit_log` VALUES ('287', '1', 'Card', 'Card', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html', '1467171759');
INSERT INTO `wp_visit_log` VALUES ('288', '1', 'Card', 'Member', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists.html', '1467171764');
INSERT INTO `wp_visit_log` VALUES ('289', '1', 'Card', 'Notice', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Notice/lists.html', '1467171770');
INSERT INTO `wp_visit_log` VALUES ('290', '1', 'Card', 'Coupons', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Coupons/lists.html', '1467171772');
INSERT INTO `wp_visit_log` VALUES ('291', '1', 'Home', 'Material', 'material_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/material_lists.html&mdm=60', '1467171779');
INSERT INTO `wp_visit_log` VALUES ('292', '1', 'Home', 'Material', 'picture_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/picture_lists/mdm/60.html', '1467171781');
INSERT INTO `wp_visit_log` VALUES ('293', '1', 'Home', 'Material', 'picture_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/picture_lists/mdm/60.html', '1467171792');
INSERT INTO `wp_visit_log` VALUES ('294', '1', 'Home', 'Material', 'voice_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/voice_lists/mdm/60.html', '1467171804');
INSERT INTO `wp_visit_log` VALUES ('295', '1', 'Home', 'Material', 'voice_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/voice_lists/mdm/60.html', '1467171813');
INSERT INTO `wp_visit_log` VALUES ('296', '1', 'Home', 'Material', 'voice_edit', '1', '118.132.208.72', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/voice_edit/id/1/mdm/60.html', '1467171824');
INSERT INTO `wp_visit_log` VALUES ('297', '1', 'Home', 'Material', 'voice_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/voice_lists/mdm/60.html', '1467171827');
INSERT INTO `wp_visit_log` VALUES ('298', '1', 'Home', 'Material', 'voice_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/voice_lists/mdm/60.html', '1467171829');
INSERT INTO `wp_visit_log` VALUES ('299', '1', 'Home', 'Material', 'video_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/video_lists/mdm/60.html', '1467171837');
INSERT INTO `wp_visit_log` VALUES ('300', '1', 'Home', 'Material', 'voice_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/voice_lists/mdm/60.html', '1467171839');
INSERT INTO `wp_visit_log` VALUES ('301', '1', 'Home', 'Material', 'voice_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/voice_lists/mdm/60.html', '1467171850');
INSERT INTO `wp_visit_log` VALUES ('302', '1', 'Home', 'Material', 'text_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/text_lists/mdm/60.html', '1467171853');
INSERT INTO `wp_visit_log` VALUES ('303', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467171866');
INSERT INTO `wp_visit_log` VALUES ('304', '1', 'Servicer', 'Servicer', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Servicer/Servicer/lists.html&mdm=45|338', '1467171870');
INSERT INTO `wp_visit_log` VALUES ('305', '1', 'Leaflets', 'Leaflets', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Leaflets/Leaflets/config.html&mdm=45|49', '1467171876');
INSERT INTO `wp_visit_log` VALUES ('306', '1', 'Home', 'Message', 'add', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/Message/add.html&mdm=45|50', '1467171879');
INSERT INTO `wp_visit_log` VALUES ('307', '1', 'Home', 'Material', 'material_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/material_lists.html', '1467171893');
INSERT INTO `wp_visit_log` VALUES ('308', '1', 'Home', 'Material', 'picture_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/picture_lists.html', '1467171895');
INSERT INTO `wp_visit_log` VALUES ('309', '1', 'Home', 'Material', 'material_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/material_lists.html', '1467171903');
INSERT INTO `wp_visit_log` VALUES ('310', '1', 'Home', 'Material', 'material_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/material_lists.html', '1467171910');
INSERT INTO `wp_visit_log` VALUES ('311', '1', 'Home', 'Material', 'material_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/material_lists.html', '1467171921');
INSERT INTO `wp_visit_log` VALUES ('312', '1', 'Home', 'Material', 'add_material', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/add_material.html', '1467171933');
INSERT INTO `wp_visit_log` VALUES ('313', '1', 'Home', 'Material', 'material_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/material_lists.html', '1467172116');
INSERT INTO `wp_visit_log` VALUES ('314', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467172124');
INSERT INTO `wp_visit_log` VALUES ('315', '1', 'Home', 'Message', 'add', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/Message/add.html&mdm=45|50', '1467172127');
INSERT INTO `wp_visit_log` VALUES ('316', '1', 'Home', 'Message', 'add', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/Message/add.html&mdm=45|50', '1467172156');
INSERT INTO `wp_visit_log` VALUES ('317', '1', 'Home', 'Material', 'material_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/material_lists.html&mdm=60', '1467172216');
INSERT INTO `wp_visit_log` VALUES ('318', '1', 'Home', 'Material', 'add_material', '1', '118.132.208.72', 'Google', '{\"group_id\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/add_material/group_id/2/mdm/60.html', '1467172230');
INSERT INTO `wp_visit_log` VALUES ('319', '1', 'Home', 'Material', 'material_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/material_lists.html', '1467172293');
INSERT INTO `wp_visit_log` VALUES ('320', '1', 'Home', 'Message', 'add', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/Message/add.html&mdm=45|50', '1467172315');
INSERT INTO `wp_visit_log` VALUES ('321', '1', 'Home', 'Public', 'lists', '1', '118.132.208.72', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467172377');
INSERT INTO `wp_visit_log` VALUES ('322', '1', 'Weiba', 'Weiba', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Weiba/Weiba/lists.html&mdm=358', '1467172419');
INSERT INTO `wp_visit_log` VALUES ('323', '1', 'Coupon', 'Coupon', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Coupon/lists.html&mdm=356', '1467172427');
INSERT INTO `wp_visit_log` VALUES ('324', '1', 'Home', 'Material', 'material_lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/material_lists.html&mdm=60', '1467172430');
INSERT INTO `wp_visit_log` VALUES ('325', '1', 'Home', 'Public', 'lists', '1', '118.132.208.72', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467172433');
INSERT INTO `wp_visit_log` VALUES ('326', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467172437');
INSERT INTO `wp_visit_log` VALUES ('327', '1', 'BusinessCard', 'BusinessCard', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/BusinessCard/BusinessCard/lists.html', '1467172457');
INSERT INTO `wp_visit_log` VALUES ('328', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467172462');
INSERT INTO `wp_visit_log` VALUES ('329', '1', 'CardVouchers', 'CardVouchers', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CardVouchers/CardVouchers/lists.html', '1467172479');
INSERT INTO `wp_visit_log` VALUES ('330', '1', 'CardVouchers', 'CardVouchers', 'add', '1', '118.132.208.72', 'Google', '{\"model\":\"29\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CardVouchers/CardVouchers/add/model/29.html', '1467172493');
INSERT INTO `wp_visit_log` VALUES ('331', '1', 'CardVouchers', 'CardVouchers', 'lists', '1', '118.132.208.72', 'Google', '{\"model\":\"29\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CardVouchers/CardVouchers/lists/model/29.html', '1467172542');
INSERT INTO `wp_visit_log` VALUES ('332', '1', 'CardVouchers', 'Wap', 'index', '1', '118.132.208.72', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CardVouchers/Wap/index/id/1.html', '1467172546');
INSERT INTO `wp_visit_log` VALUES ('333', '1', 'RealPrize', 'RealPrize', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/RealPrize/RealPrize/lists.html&mdm=356|29', '1467172729');
INSERT INTO `wp_visit_log` VALUES ('334', '1', 'RedBag', 'RedBag', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/RedBag/RedBag/lists.html&mdm=356|28', '1467172731');
INSERT INTO `wp_visit_log` VALUES ('335', '1', 'Coupon', 'Coupon', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Coupon/lists.html&mdm=356|27', '1467172734');
INSERT INTO `wp_visit_log` VALUES ('336', '1', 'Home', 'Public', 'lists', '1', '118.132.208.72', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467172740');
INSERT INTO `wp_visit_log` VALUES ('337', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467172743');
INSERT INTO `wp_visit_log` VALUES ('338', '1', 'Home', 'Public', 'add', '1', '118.132.208.72', 'Google', '{\"from\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/add/from/4.html', '1467172751');
INSERT INTO `wp_visit_log` VALUES ('339', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467172754');
INSERT INTO `wp_visit_log` VALUES ('340', '1', 'HelpOpen', 'HelpOpen', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/HelpOpen/HelpOpen/lists.html', '1467172760');
INSERT INTO `wp_visit_log` VALUES ('341', '1', 'Ask', 'Ask', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/lists.html&mdm=17|353', '1467173004');
INSERT INTO `wp_visit_log` VALUES ('342', '1', 'Ask', 'Ask', 'add', '1', '118.132.208.72', 'Google', '{\"model\":\"24\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/add/model/24/mdm/17%7C353.html', '1467173010');
INSERT INTO `wp_visit_log` VALUES ('343', '1', 'Home', 'Public', 'lists', '1', '118.132.208.72', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467173015');
INSERT INTO `wp_visit_log` VALUES ('344', '1', 'Home', 'Index', 'main', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467173019');
INSERT INTO `wp_visit_log` VALUES ('345', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467173053');
INSERT INTO `wp_visit_log` VALUES ('346', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467173057');
INSERT INTO `wp_visit_log` VALUES ('347', '1', 'UserCenter', 'UserCenter', 'detail', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/detail/uid/3.html', '1467173064');
INSERT INTO `wp_visit_log` VALUES ('348', '1', 'UserCenter', 'UserCenter', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/config.html', '1467173068');
INSERT INTO `wp_visit_log` VALUES ('349', '1', 'UserCenter', 'UserCenter', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/config.html', '1467173108');
INSERT INTO `wp_visit_log` VALUES ('350', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html', '1467173115');
INSERT INTO `wp_visit_log` VALUES ('351', '1', 'UserCenter', 'UserCenter', 'detail', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/detail/uid/10.html', '1467173120');
INSERT INTO `wp_visit_log` VALUES ('352', '1', 'UserCenter', 'UserCenter', 'config', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/config.html', '1467173126');
INSERT INTO `wp_visit_log` VALUES ('353', '1', 'UserCenter', 'UserCenter', 'detail', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/detail/uid/10.html', '1467173128');
INSERT INTO `wp_visit_log` VALUES ('354', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html', '1467173129');
INSERT INTO `wp_visit_log` VALUES ('355', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html', '1467174121');
INSERT INTO `wp_visit_log` VALUES ('356', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html', '1467174203');
INSERT INTO `wp_visit_log` VALUES ('357', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html', '1467174216');
INSERT INTO `wp_visit_log` VALUES ('358', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html', '1467174283');
INSERT INTO `wp_visit_log` VALUES ('359', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.208.72', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html', '1467174358');
INSERT INTO `wp_visit_log` VALUES ('360', '1', 'Home', 'Index', 'main', '1', '118.132.120.53', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467260611');
INSERT INTO `wp_visit_log` VALUES ('361', '1', 'Guess', 'Guess', 'lists', '1', '118.132.120.53', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/lists.html', '1467260617');
INSERT INTO `wp_visit_log` VALUES ('362', '1', 'Guess', 'Guess', 'index', '1', '118.132.120.53', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html', '1467260741');
INSERT INTO `wp_visit_log` VALUES ('363', '1', 'Guess', 'Guess', 'index', '10', '219.233.70.10', 'other', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html', '1467350153');
INSERT INTO `wp_visit_log` VALUES ('364', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467632108');
INSERT INTO `wp_visit_log` VALUES ('472', '1', 'WeiSite', 'WeiSite', 'index', '0', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgsyEDncCLibJPRbvIwNPGsNA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgsyEDncCLibJPRbvIwNPGsNA.html&openid=oYMvgsyEDncCLibJPRbvIwNPGsNA', '1467640000');
INSERT INTO `wp_visit_log` VALUES ('473', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467640006');
INSERT INTO `wp_visit_log` VALUES ('474', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists.html', '1467640069');
INSERT INTO `wp_visit_log` VALUES ('475', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467640079');
INSERT INTO `wp_visit_log` VALUES ('476', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists.html', '1467640091');
INSERT INTO `wp_visit_log` VALUES ('477', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467640115');
INSERT INTO `wp_visit_log` VALUES ('478', '1', 'Home', 'Public', 'lists', '1', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467640118');
INSERT INTO `wp_visit_log` VALUES ('479', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467640122');
INSERT INTO `wp_visit_log` VALUES ('480', '1', 'Vote', 'Vote', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/lists.html', '1467640129');
INSERT INTO `wp_visit_log` VALUES ('481', '1', 'Vote', 'Vote', 'index', '6', '118.132.31.56', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/index/id/1.html', '1467640153');
INSERT INTO `wp_visit_log` VALUES ('482', '1', 'Vote', 'Vote', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"1\",\"model\":\"95\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/edit/id/1/model/95.html', '1467640163');
INSERT INTO `wp_visit_log` VALUES ('483', '1', 'Vote', 'Vote', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"vote\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/lists/model/vote.html', '1467640175');
INSERT INTO `wp_visit_log` VALUES ('484', '1', 'Vote', 'Vote', 'index', '6', '118.132.31.56', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/index/id/1.html', '1467640180');
INSERT INTO `wp_visit_log` VALUES ('485', '1', 'Vote', 'Vote', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"1\",\"model\":\"vote\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/edit/id/1/model/vote.html', '1467640187');
INSERT INTO `wp_visit_log` VALUES ('486', '1', 'Vote', 'Vote', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"vote\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/lists/model/vote.html', '1467640191');
INSERT INTO `wp_visit_log` VALUES ('487', '1', 'Vote', 'Vote', 'add', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/add.html', '1467640194');
INSERT INTO `wp_visit_log` VALUES ('488', '1', 'Vote', 'Vote', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"vote\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/lists/model/vote.html', '1467640244');
INSERT INTO `wp_visit_log` VALUES ('489', '1', 'Vote', 'Vote', 'index', '6', '118.132.31.56', 'Google', '{\"id\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/index/id/2.html', '1467640258');
INSERT INTO `wp_visit_log` VALUES ('490', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467640270');
INSERT INTO `wp_visit_log` VALUES ('491', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/CreditConfig/lists.html&mdm=15|42', '1467640273');
INSERT INTO `wp_visit_log` VALUES ('492', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467640277');
INSERT INTO `wp_visit_log` VALUES ('493', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/CreditConfig/lists.html&mdm=15|42', '1467640287');
INSERT INTO `wp_visit_log` VALUES ('494', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467640288');
INSERT INTO `wp_visit_log` VALUES ('495', '1', 'Vote', 'Vote', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"vote\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/lists/model/vote.html', '1467640289');
INSERT INTO `wp_visit_log` VALUES ('496', '1', 'Vote', 'Vote', 'index', '1', '118.132.31.56', 'Google', '{\"id\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/index/id/2.html', '1467640294');
INSERT INTO `wp_visit_log` VALUES ('497', '1', 'WeiSite', 'WeiSite', 'index', '6', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467640357');
INSERT INTO `wp_visit_log` VALUES ('498', '1', 'Vote', 'Vote', 'index', '6', '118.132.31.56', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/index/id/1.html', '1467640365');
INSERT INTO `wp_visit_log` VALUES ('499', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467640562');
INSERT INTO `wp_visit_log` VALUES ('500', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467640566');
INSERT INTO `wp_visit_log` VALUES ('501', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467640569');
INSERT INTO `wp_visit_log` VALUES ('502', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists.html', '1467640573');
INSERT INTO `wp_visit_log` VALUES ('503', '1', 'Card', 'Member', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"173\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/add/model/173.html', '1467640580');
INSERT INTO `wp_visit_log` VALUES ('504', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"173\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists/model/173.html', '1467640617');
INSERT INTO `wp_visit_log` VALUES ('505', '1', 'Card', 'Member', 'edit', '1', '118.132.31.56', 'Google', '{\"model\":\"173\",\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/edit/model/173/id/1.html', '1467640624');
INSERT INTO `wp_visit_log` VALUES ('506', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists.html', '1467640631');
INSERT INTO `wp_visit_log` VALUES ('507', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists.html', '1467640663');
INSERT INTO `wp_visit_log` VALUES ('508', '1', 'Card', 'Member', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"173\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/add/model/173.html', '1467640666');
INSERT INTO `wp_visit_log` VALUES ('509', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"173\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists/model/173.html', '1467640689');
INSERT INTO `wp_visit_log` VALUES ('510', '1', 'Card', 'Member', 'edit', '1', '118.132.31.56', 'Google', '{\"model\":\"173\",\"id\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/edit/model/173/id/2.html', '1467640732');
INSERT INTO `wp_visit_log` VALUES ('511', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"173\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists/model/173.html', '1467640747');
INSERT INTO `wp_visit_log` VALUES ('512', '1', 'Card', 'Member', 'edit', '1', '118.132.31.56', 'Google', '{\"model\":\"173\",\"id\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/edit/model/173/id/2.html', '1467640754');
INSERT INTO `wp_visit_log` VALUES ('513', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"173\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists/model/173.html', '1467640763');
INSERT INTO `wp_visit_log` VALUES ('514', '1', 'Card', 'Member', 'edit', '1', '118.132.31.56', 'Google', '{\"model\":\"173\",\"id\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/edit/model/173/id/2.html', '1467640771');
INSERT INTO `wp_visit_log` VALUES ('515', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"173\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists/model/173.html', '1467640787');
INSERT INTO `wp_visit_log` VALUES ('516', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html', '1467641540');
INSERT INTO `wp_visit_log` VALUES ('517', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists.html', '1467641557');
INSERT INTO `wp_visit_log` VALUES ('518', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html', '1467641566');
INSERT INTO `wp_visit_log` VALUES ('519', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html', '1467641575');
INSERT INTO `wp_visit_log` VALUES ('520', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467681532');
INSERT INTO `wp_visit_log` VALUES ('521', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467681541');
INSERT INTO `wp_visit_log` VALUES ('522', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467681545');
INSERT INTO `wp_visit_log` VALUES ('523', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists.html', '1467681613');
INSERT INTO `wp_visit_log` VALUES ('524', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467683254');
INSERT INTO `wp_visit_log` VALUES ('525', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists.html&mdm=45|47', '1467683257');
INSERT INTO `wp_visit_log` VALUES ('526', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"8\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/8.html', '1467683261');
INSERT INTO `wp_visit_log` VALUES ('527', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467683280');
INSERT INTO `wp_visit_log` VALUES ('528', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467683285');
INSERT INTO `wp_visit_log` VALUES ('529', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"8\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/8.html', '1467683303');
INSERT INTO `wp_visit_log` VALUES ('530', '1', 'Home', 'Public', 'lists', '1', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467683652');
INSERT INTO `wp_visit_log` VALUES ('531', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467683773');
INSERT INTO `wp_visit_log` VALUES ('532', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html', '1467683778');
INSERT INTO `wp_visit_log` VALUES ('533', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists.html', '1467683785');
INSERT INTO `wp_visit_log` VALUES ('534', '1', 'Card', 'Notice', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Notice/lists.html', '1467683788');
INSERT INTO `wp_visit_log` VALUES ('535', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html', '1467683804');
INSERT INTO `wp_visit_log` VALUES ('536', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html', '1467683845');
INSERT INTO `wp_visit_log` VALUES ('537', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467684549');
INSERT INTO `wp_visit_log` VALUES ('538', '1', 'Home', 'Public', 'lists', '1', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467684552');
INSERT INTO `wp_visit_log` VALUES ('539', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467684557');
INSERT INTO `wp_visit_log` VALUES ('540', '1', 'SingIn', 'SingIn', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/SingIn/SingIn/lists.html', '1467684564');
INSERT INTO `wp_visit_log` VALUES ('541', '1', 'SingIn', 'SingIn', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/SingIn/SingIn/config.html', '1467684569');
INSERT INTO `wp_visit_log` VALUES ('542', '1', 'SingIn', 'SingIn', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/SingIn/SingIn/config.html', '1467684599');
INSERT INTO `wp_visit_log` VALUES ('543', '1', 'Home', 'Public', 'lists', '1', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467686090');
INSERT INTO `wp_visit_log` VALUES ('544', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467686098');
INSERT INTO `wp_visit_log` VALUES ('545', '1', 'SingIn', 'SingIn', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/SingIn/SingIn/lists.html', '1467686101');
INSERT INTO `wp_visit_log` VALUES ('546', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467686103');
INSERT INTO `wp_visit_log` VALUES ('547', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists.html&mdm=45|47', '1467686106');
INSERT INTO `wp_visit_log` VALUES ('548', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"8\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/8.html', '1467686109');
INSERT INTO `wp_visit_log` VALUES ('549', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467686149');
INSERT INTO `wp_visit_log` VALUES ('550', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"8\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/8.html', '1467686155');
INSERT INTO `wp_visit_log` VALUES ('551', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467686178');
INSERT INTO `wp_visit_log` VALUES ('552', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467686183');
INSERT INTO `wp_visit_log` VALUES ('553', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"8\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/8.html', '1467686788');
INSERT INTO `wp_visit_log` VALUES ('554', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467686795');
INSERT INTO `wp_visit_log` VALUES ('555', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467686803');
INSERT INTO `wp_visit_log` VALUES ('556', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467688238');
INSERT INTO `wp_visit_log` VALUES ('557', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467688246');
INSERT INTO `wp_visit_log` VALUES ('558', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467688249');
INSERT INTO `wp_visit_log` VALUES ('559', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467688266');
INSERT INTO `wp_visit_log` VALUES ('560', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists.html', '1467688309');
INSERT INTO `wp_visit_log` VALUES ('561', '1', 'Card', 'Notice', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Notice/lists.html', '1467688313');
INSERT INTO `wp_visit_log` VALUES ('562', '1', 'Card', 'Coupons', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Coupons/lists.html', '1467688317');
INSERT INTO `wp_visit_log` VALUES ('563', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467688349');
INSERT INTO `wp_visit_log` VALUES ('564', '1', 'SingIn', 'SingIn', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/SingIn/SingIn/lists.html', '1467688357');
INSERT INTO `wp_visit_log` VALUES ('565', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html', '1467688368');
INSERT INTO `wp_visit_log` VALUES ('566', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/CreditConfig/lists.html&mdm=15|42', '1467690350');
INSERT INTO `wp_visit_log` VALUES ('567', '1', 'Home', 'CreditConfig', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"9\",\"model\":\"14\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/edit/id/9/model/14/mdm/15|42.html', '1467690356');
INSERT INTO `wp_visit_log` VALUES ('568', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"credit_config\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists/model/credit_config.html', '1467690369');
INSERT INTO `wp_visit_log` VALUES ('569', '1', 'Home', 'Public', 'lists', '1', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467691946');
INSERT INTO `wp_visit_log` VALUES ('570', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467691951');
INSERT INTO `wp_visit_log` VALUES ('571', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467691955');
INSERT INTO `wp_visit_log` VALUES ('572', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467691959');
INSERT INTO `wp_visit_log` VALUES ('573', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/CreditConfig/lists.html&mdm=15|42', '1467691962');
INSERT INTO `wp_visit_log` VALUES ('574', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467691964');
INSERT INTO `wp_visit_log` VALUES ('575', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467692319');
INSERT INTO `wp_visit_log` VALUES ('576', '1', 'Home', 'Public', 'lists', '1', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467693256');
INSERT INTO `wp_visit_log` VALUES ('577', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467693382');
INSERT INTO `wp_visit_log` VALUES ('578', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467699753');
INSERT INTO `wp_visit_log` VALUES ('579', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467699758');
INSERT INTO `wp_visit_log` VALUES ('580', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467699760');
INSERT INTO `wp_visit_log` VALUES ('581', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467699809');
INSERT INTO `wp_visit_log` VALUES ('582', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467699848');
INSERT INTO `wp_visit_log` VALUES ('583', '1', 'Card', 'CardPrivilege', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardPrivilege/lists/mdm/15%7C342.html', '1467699857');
INSERT INTO `wp_visit_log` VALUES ('584', '1', 'Card', 'CardLevel', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardLevel/lists/mdm/15%7C342.html', '1467699863');
INSERT INTO `wp_visit_log` VALUES ('585', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists/mdm/15%7C342.html', '1467699867');
INSERT INTO `wp_visit_log` VALUES ('586', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists/mdm/15%7C342.html', '1467699895');
INSERT INTO `wp_visit_log` VALUES ('587', '1', 'Card', 'Notice', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Notice/lists/mdm/15%7C342.html', '1467699897');
INSERT INTO `wp_visit_log` VALUES ('588', '1', 'Card', 'Notice', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"172\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Notice/add/model/172/mdm/15%7C342.html', '1467699910');
INSERT INTO `wp_visit_log` VALUES ('589', '1', 'Card', 'Notice', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"172\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Notice/lists/model/172/mdm/15%7C342.html', '1467699936');
INSERT INTO `wp_visit_log` VALUES ('590', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config/mdm/15%7C342.html', '1467699940');
INSERT INTO `wp_visit_log` VALUES ('591', '1', 'Card', 'CardLevel', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardLevel/lists/mdm/15%7C342.html', '1467699943');
INSERT INTO `wp_visit_log` VALUES ('592', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config/mdm/15%7C342.html', '1467699948');
INSERT INTO `wp_visit_log` VALUES ('593', '1', 'Card', 'CardLevel', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardLevel/lists/mdm/15%7C342.html', '1467699950');
INSERT INTO `wp_visit_log` VALUES ('594', '1', 'Card', 'CardLevel', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"167\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardLevel/add/model/167/mdm/15%7C342.html', '1467699953');
INSERT INTO `wp_visit_log` VALUES ('595', '1', 'Card', 'CardLevel', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"167\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardLevel/lists/model/167/mdm/15%7C342.html', '1467699989');
INSERT INTO `wp_visit_log` VALUES ('596', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config/mdm/15%7C342.html', '1467699992');
INSERT INTO `wp_visit_log` VALUES ('597', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config/mdm/15%7C342.html', '1467700001');
INSERT INTO `wp_visit_log` VALUES ('598', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists/mdm/15%7C342.html', '1467700319');
INSERT INTO `wp_visit_log` VALUES ('599', '1', 'Card', 'ShopMember', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/ShopMember/lists/mdm/15%7C342.html', '1467700338');
INSERT INTO `wp_visit_log` VALUES ('600', '1', 'Card', 'MemberTransition', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/MemberTransition/lists/mdm/15%7C342.html', '1467700341');
INSERT INTO `wp_visit_log` VALUES ('601', '1', 'Card', 'MemberMarketing', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/MemberMarketing/lists/mdm/15%7C342.html', '1467700350');
INSERT INTO `wp_visit_log` VALUES ('602', '1', 'Card', 'Custom', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/lists.html&mdm=15|342', '1467700357');
INSERT INTO `wp_visit_log` VALUES ('603', '1', 'Card', 'Custom', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"185\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/add/model/185/mdm/15%7C342.html', '1467700364');
INSERT INTO `wp_visit_log` VALUES ('604', '1', 'Card', 'Custom', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"185\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/lists/model/185/mdm/15%7C342.html', '1467700442');
INSERT INTO `wp_visit_log` VALUES ('605', '1', 'Card', 'Custom', 'lists', '1', '118.132.31.56', 'Google', '{\"type\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/lists/mdm/15%7C342/type/2.html', '1467700487');
INSERT INTO `wp_visit_log` VALUES ('606', '1', 'Card', 'Custom', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"185\",\"type\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/add/model/185/mdm/15%7C342/type/2.html', '1467700493');
INSERT INTO `wp_visit_log` VALUES ('607', '1', 'Card', 'Custom', 'lists', '1', '118.132.31.56', 'Google', '{\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/lists/mdm/15%7C342/type/0.html', '1467700768');
INSERT INTO `wp_visit_log` VALUES ('608', '1', 'Card', 'Custom', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"1\",\"model\":\"185\",\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/edit/id/1/model/185/mdm/15|342/type/0.html', '1467700776');
INSERT INTO `wp_visit_log` VALUES ('609', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467700781');
INSERT INTO `wp_visit_log` VALUES ('610', '1', 'Card', 'MemberMarketing', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/MemberMarketing/lists/mdm/15%7C342.html', '1467700785');
INSERT INTO `wp_visit_log` VALUES ('611', '1', 'Card', 'Score', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Score/lists.html&mdm=15|342', '1467700789');
INSERT INTO `wp_visit_log` VALUES ('612', '1', 'Card', 'MemberMarketing', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/MemberMarketing/lists/mdm/15%7C342.html', '1467700799');
INSERT INTO `wp_visit_log` VALUES ('613', '1', 'Card', 'Custom', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/lists.html&mdm=15|342', '1467700894');
INSERT INTO `wp_visit_log` VALUES ('614', '1', 'Card', 'Custom', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"1\",\"model\":\"185\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/edit/id/1/model/185/mdm/15|342.html', '1467700902');
INSERT INTO `wp_visit_log` VALUES ('615', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/CreditConfig/lists.html&mdm=15|42', '1467700951');
INSERT INTO `wp_visit_log` VALUES ('616', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467700955');
INSERT INTO `wp_visit_log` VALUES ('617', '1', 'Card', 'Custom', 'lists', '1', '118.132.31.56', 'Google', '{\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/lists/mdm/15%7C342/type/0.html', '1467700974');
INSERT INTO `wp_visit_log` VALUES ('618', '1', 'Card', 'Custom', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"1\",\"model\":\"185\",\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/edit/id/1/model/185/mdm/15|342/type/0.html', '1467700978');
INSERT INTO `wp_visit_log` VALUES ('619', '1', 'Card', 'Custom', 'lists', '1', '118.132.31.56', 'Google', '{\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/lists/mdm/15%7C342/type/0.html', '1467701214');
INSERT INTO `wp_visit_log` VALUES ('620', '1', 'Card', 'Custom', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"185\",\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/add/model/185/mdm/15%7C342/type/0.html', '1467701295');
INSERT INTO `wp_visit_log` VALUES ('621', '1', 'Card', 'Custom', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"185\",\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/lists/model/185/mdm/15%7C342/type/0.html', '1467701334');
INSERT INTO `wp_visit_log` VALUES ('622', '1', 'Card', 'Custom', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"185\",\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/add/model/185/mdm/15%7C342/type/0.html', '1467701553');
INSERT INTO `wp_visit_log` VALUES ('623', '1', 'Card', 'Custom', 'lists', '1', '118.132.31.56', 'Google', '{\"type\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/lists/mdm/15%7C342/type/1.html', '1467701556');
INSERT INTO `wp_visit_log` VALUES ('624', '1', 'Card', 'Custom', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"185\",\"type\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/add/model/185/mdm/15%7C342/type/1.html', '1467701559');
INSERT INTO `wp_visit_log` VALUES ('625', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467702268');
INSERT INTO `wp_visit_log` VALUES ('626', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467702283');
INSERT INTO `wp_visit_log` VALUES ('627', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists/mdm/15%7C342.html', '1467702287');
INSERT INTO `wp_visit_log` VALUES ('628', '1', 'Card', 'ShopMember', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/ShopMember/lists/mdm/15%7C342.html', '1467702290');
INSERT INTO `wp_visit_log` VALUES ('629', '1', 'Card', 'MemberTransition', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/MemberTransition/lists/mdm/15%7C342.html', '1467702292');
INSERT INTO `wp_visit_log` VALUES ('630', '1', 'Card', 'MemberTransition', 'score_lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/MemberTransition/score_lists.html&mdm=15|342', '1467702298');
INSERT INTO `wp_visit_log` VALUES ('631', '1', 'Card', 'MemberTransition', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/MemberTransition/lists/mdm/15%7C342.html', '1467702310');
INSERT INTO `wp_visit_log` VALUES ('632', '1', 'Card', 'MemberMarketing', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/MemberMarketing/lists/mdm/15%7C342.html', '1467702315');
INSERT INTO `wp_visit_log` VALUES ('633', '1', 'Card', 'Notice', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Notice/lists/mdm/15%7C342.html', '1467702318');
INSERT INTO `wp_visit_log` VALUES ('634', '1', 'Card', 'Notice', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Notice/lists/mdm/15%7C342.html', '1467702322');
INSERT INTO `wp_visit_log` VALUES ('635', '1', 'Card', 'Custom', 'lists', '1', '118.132.31.56', 'Google', '{\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/lists/mdm/15%7C342/type/0.html', '1467703288');
INSERT INTO `wp_visit_log` VALUES ('636', '1', 'Card', 'Custom', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"2\",\"model\":\"185\",\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/edit/id/2/model/185/mdm/15|342/type/0.html', '1467703292');
INSERT INTO `wp_visit_log` VALUES ('637', '1', 'Card', 'Custom', 'lists', '1', '118.132.31.56', 'Google', '{\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/lists/mdm/15%7C342/type/0.html', '1467703340');
INSERT INTO `wp_visit_log` VALUES ('638', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists/mdm/15%7C342.html', '1467703346');
INSERT INTO `wp_visit_log` VALUES ('639', '1', 'Card', 'Member', 'edit', '1', '118.132.31.56', 'Google', '{\"model\":\"173\",\"id\":\"5\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/edit/model/173/id/5.html', '1467703354');
INSERT INTO `wp_visit_log` VALUES ('640', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"173\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists/model/173.html', '1467703365');
INSERT INTO `wp_visit_log` VALUES ('641', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html', '1467703369');
INSERT INTO `wp_visit_log` VALUES ('642', '1', 'Card', 'CardLevel', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardLevel/lists.html', '1467703370');
INSERT INTO `wp_visit_log` VALUES ('643', '1', 'Card', 'CardLevel', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"1\",\"model\":\"167\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardLevel/edit/id/1/model/167.html', '1467703374');
INSERT INTO `wp_visit_log` VALUES ('644', '1', 'Card', 'CardLevel', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"167\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardLevel/lists/model/167.html', '1467703380');
INSERT INTO `wp_visit_log` VALUES ('645', '1', 'Card', 'CardPrivilege', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardPrivilege/lists.html', '1467703386');
INSERT INTO `wp_visit_log` VALUES ('646', '1', 'Card', 'Custom', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"2\",\"model\":\"185\",\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/edit/id/2/model/185/mdm/15|342/type/0.html', '1467703399');
INSERT INTO `wp_visit_log` VALUES ('647', '1', 'Card', 'Custom', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"185\",\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/lists/model/185/mdm/15%7C342/type/0.html', '1467703413');
INSERT INTO `wp_visit_log` VALUES ('648', '1', 'Card', 'Custom', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"2\",\"model\":\"185\",\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/edit/id/2/model/185/mdm/15|342/type/0.html', '1467703475');
INSERT INTO `wp_visit_log` VALUES ('649', '1', 'Card', 'Custom', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"185\",\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/lists/model/185/mdm/15%7C342/type/0.html', '1467703486');
INSERT INTO `wp_visit_log` VALUES ('650', '1', 'Card', 'Custom', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"2\",\"model\":\"185\",\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/edit/id/2/model/185/mdm/15|342/type/0.html', '1467703490');
INSERT INTO `wp_visit_log` VALUES ('651', '1', 'Card', 'CardPrivilege', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"166\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardPrivilege/add/model/166.html', '1467703508');
INSERT INTO `wp_visit_log` VALUES ('652', '1', 'Card', 'CardPrivilege', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"166\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardPrivilege/lists/model/166.html', '1467703542');
INSERT INTO `wp_visit_log` VALUES ('653', '1', 'Card', 'Custom', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"185\",\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/lists/model/185/mdm/15%7C342/type/0.html', '1467704280');
INSERT INTO `wp_visit_log` VALUES ('654', '1', 'Card', 'Custom', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"2\",\"model\":\"185\",\"type\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Custom/edit/id/2/model/185/mdm/15|342/type/0.html', '1467704555');
INSERT INTO `wp_visit_log` VALUES ('655', '1', 'Card', 'Notice', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Notice/lists.html', '1467704781');
INSERT INTO `wp_visit_log` VALUES ('656', '1', 'Card', 'Notice', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"172\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Notice/add/model/172.html', '1467704793');
INSERT INTO `wp_visit_log` VALUES ('657', '1', 'Card', 'Notice', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"172\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Notice/lists/model/172.html', '1467704813');
INSERT INTO `wp_visit_log` VALUES ('658', '1', 'Card', 'Notice', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"2\",\"model\":\"172\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Notice/edit/id/2/model/172.html', '1467705021');
INSERT INTO `wp_visit_log` VALUES ('659', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html', '1467705102');
INSERT INTO `wp_visit_log` VALUES ('660', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/CreditConfig/lists.html&mdm=15|42', '1467705277');
INSERT INTO `wp_visit_log` VALUES ('661', '1', 'Home', 'CreditConfig', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"45\",\"model\":\"14\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/edit/id/45/model/14/mdm/15|42.html', '1467705283');
INSERT INTO `wp_visit_log` VALUES ('662', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists.html', '1467705287');
INSERT INTO `wp_visit_log` VALUES ('663', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists.html', '1467705427');
INSERT INTO `wp_visit_log` VALUES ('664', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists.html', '1467705438');
INSERT INTO `wp_visit_log` VALUES ('665', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists.html', '1467705454');
INSERT INTO `wp_visit_log` VALUES ('666', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists.html', '1467705546');
INSERT INTO `wp_visit_log` VALUES ('667', '1', 'Home', 'CreditData', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467705561');
INSERT INTO `wp_visit_log` VALUES ('668', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists.html', '1467705622');
INSERT INTO `wp_visit_log` VALUES ('669', '1', 'Home', 'CreditConfig', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"32\",\"model\":\"14\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/edit/id/32/model/14.html', '1467705632');
INSERT INTO `wp_visit_log` VALUES ('670', '1', 'Home', 'CreditConfig', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditConfig/lists.html', '1467705635');
INSERT INTO `wp_visit_log` VALUES ('671', '1', 'Coupon', 'Wap', 'lists', '3', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467706057');
INSERT INTO `wp_visit_log` VALUES ('672', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467706059');
INSERT INTO `wp_visit_log` VALUES ('673', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists/mdm/15%7C342.html', '1467706064');
INSERT INTO `wp_visit_log` VALUES ('674', '1', 'Card', 'MemberMarketing', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/MemberMarketing/lists/mdm/15%7C342.html', '1467706066');
INSERT INTO `wp_visit_log` VALUES ('675', '1', 'Coupon', 'Coupon', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Coupon/lists.html&mdm=15|342', '1467706070');
INSERT INTO `wp_visit_log` VALUES ('676', '1', 'Coupon', 'Coupon', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"152\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Coupon/add/model/152/mdm/15%7C342.html', '1467706081');
INSERT INTO `wp_visit_log` VALUES ('677', '1', 'Coupon', 'Shop', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"coupon_shop\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Shop/add/model/coupon_shop.html', '1467706111');
INSERT INTO `wp_visit_log` VALUES ('678', '1', 'Coupon', 'Coupon', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"152\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Coupon/lists/model/152/mdm/15%7C342.html', '1467706133');
INSERT INTO `wp_visit_log` VALUES ('679', '1', 'Coupon', 'Wap', 'index', '1', '118.132.31.56', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/index/id/1.html', '1467706137');
INSERT INTO `wp_visit_log` VALUES ('680', '1', 'Coupon', 'Wap', 'lists', '3', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467706153');
INSERT INTO `wp_visit_log` VALUES ('681', '1', 'Coupon', 'Wap', 'lists', '8', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467706168');
INSERT INTO `wp_visit_log` VALUES ('682', '1', 'Coupon', 'Wap', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467706191');
INSERT INTO `wp_visit_log` VALUES ('683', '1', 'Coupon', 'Wap', 'lists', '-433', '118.132.31.56', 'Safari', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467706198');
INSERT INTO `wp_visit_log` VALUES ('684', '1', 'Coupon', 'Wap', 'index', '1', '118.132.31.56', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/index/id/1.html', '1467706282');
INSERT INTO `wp_visit_log` VALUES ('685', '1', 'Coupon', 'Wap', 'lists', '-437', '118.132.31.56', 'Safari', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467706396');
INSERT INTO `wp_visit_log` VALUES ('686', '1', 'UserCenter', 'Wap', 'bind_prize_info', '-439', '118.132.31.56', 'Safari', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/Wap/bind_prize_info.html', '1467706399');
INSERT INTO `wp_visit_log` VALUES ('687', '1', 'Coupon', 'Wap', 'lists', '-437', '118.132.31.56', 'Safari', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467706401');
INSERT INTO `wp_visit_log` VALUES ('688', '1', 'UserCenter', 'Wap', 'bind_prize_info', '-444', '118.132.31.56', 'Safari', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/Wap/bind_prize_info.html', '1467706619');
INSERT INTO `wp_visit_log` VALUES ('689', '1', 'Coupon', 'Wap', 'lists', '-437', '118.132.31.56', 'Safari', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467706643');
INSERT INTO `wp_visit_log` VALUES ('690', '1', 'Coupon', 'Wap', 'lists', '-445', '118.132.31.56', 'Safari', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467706771');
INSERT INTO `wp_visit_log` VALUES ('691', '1', 'Coupon', 'Wap', 'lists', '-446', '118.132.31.56', 'Safari', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467706849');
INSERT INTO `wp_visit_log` VALUES ('692', '1', 'Coupon', 'Wap', 'lists', '-447', '118.132.31.56', 'Safari', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467706933');
INSERT INTO `wp_visit_log` VALUES ('693', '1', 'Coupon', 'Wap', 'lists', '-448', '118.132.31.56', 'Safari', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467706983');
INSERT INTO `wp_visit_log` VALUES ('694', '1', 'Coupon', 'Wap', 'lists', '-449', '118.132.31.56', 'Safari', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467707139');
INSERT INTO `wp_visit_log` VALUES ('695', '1', 'Coupon', 'Wap', 'lists', '-450', '118.132.31.56', 'Safari', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467707315');
INSERT INTO `wp_visit_log` VALUES ('696', '1', 'Coupon', 'Wap', 'lists', '8', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467707565');
INSERT INTO `wp_visit_log` VALUES ('697', '1', 'Coupon', 'Wap', 'lists', '3', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467707570');
INSERT INTO `wp_visit_log` VALUES ('698', '1', 'Coupon', 'Wap', 'set_sn_code', '8', '118.132.31.56', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/set_sn_code/id/1/publicid/1.html', '1467707578');
INSERT INTO `wp_visit_log` VALUES ('699', '1', 'Coupon', 'Wap', 'personal', '8', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html', '1467707660');
INSERT INTO `wp_visit_log` VALUES ('700', '1', 'Coupon', 'Wap', 'lists', '3', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467707740');
INSERT INTO `wp_visit_log` VALUES ('701', '1', 'Coupon', 'Wap', 'show', '3', '118.132.31.56', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/show/id/1.html', '1467707753');
INSERT INTO `wp_visit_log` VALUES ('702', '1', 'Coupon', 'Wap', 'coupon_detail', '3', '118.132.31.56', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/coupon_detail/id/1.html', '1467707775');
INSERT INTO `wp_visit_log` VALUES ('703', '1', 'Coupon', 'Wap', 'personal', '3', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html', '1467708181');
INSERT INTO `wp_visit_log` VALUES ('704', '1', 'Coupon', 'Wap', 'personal', '3', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html', '1467708186');
INSERT INTO `wp_visit_log` VALUES ('705', '1', 'Coupon', 'Wap', 'show', '3', '118.132.31.56', 'Google', '{\"id\":\"1\",\"sn_id\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/show/id/1/sn_id/2.html', '1467708188');
INSERT INTO `wp_visit_log` VALUES ('706', '1', 'Coupon', 'Wap', 'personal', '3', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html', '1467708190');
INSERT INTO `wp_visit_log` VALUES ('707', '1', 'Coupon', 'Wap', 'personal', '3', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html', '1467732190');
INSERT INTO `wp_visit_log` VALUES ('708', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467769301');
INSERT INTO `wp_visit_log` VALUES ('709', '1', 'WeiSite', 'WeiSite', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/config.html&mdm=31', '1467769731');
INSERT INTO `wp_visit_log` VALUES ('710', '1', 'WeiSite', 'Template', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/lists.html&mdm=31|34', '1467769737');
INSERT INTO `wp_visit_log` VALUES ('711', '1', 'WeiSite', 'Template', 'detail', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/detail.html&mdm=31|34', '1467769756');
INSERT INTO `wp_visit_log` VALUES ('712', '1', 'WeiSite', 'Cms', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Cms/lists.html&mdm=31|34', '1467769774');
INSERT INTO `wp_visit_log` VALUES ('713', '1', 'WeiSite', 'Cms', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"36\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Cms/add/model/36/mdm/31%7C34.html', '1467769786');
INSERT INTO `wp_visit_log` VALUES ('714', '1', 'WeiSite', 'Cms', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"36\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Cms/lists/model/36/mdm/31%7C34.html', '1467770529');
INSERT INTO `wp_visit_log` VALUES ('715', '1', 'WeiSite', 'Cms', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"36\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Cms/add/model/36/mdm/31%7C34.html', '1467770560');
INSERT INTO `wp_visit_log` VALUES ('716', '1', 'WeiSite', 'Cms', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"36\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Cms/lists/model/36/mdm/31%7C34.html', '1467770590');
INSERT INTO `wp_visit_log` VALUES ('717', '1', 'WeiSite', 'Cms', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"36\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Cms/add/model/36/mdm/31%7C34.html', '1467770602');
INSERT INTO `wp_visit_log` VALUES ('718', '1', 'WeiSite', 'Cms', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"36\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Cms/lists/model/36/mdm/31%7C34.html', '1467770629');
INSERT INTO `wp_visit_log` VALUES ('719', '1', 'WeiSite', 'Cms', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"1\",\"model\":\"36\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Cms/edit/id/1/model/36/mdm/31|34.html', '1467770645');
INSERT INTO `wp_visit_log` VALUES ('720', '1', 'WeiSite', 'Template', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/lists.html&mdm=31|34', '1467770658');
INSERT INTO `wp_visit_log` VALUES ('721', '1', 'WeiSite', 'WeiSite', 'index', '0', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467770719');
INSERT INTO `wp_visit_log` VALUES ('722', '1', 'WeiSite', 'WeiSite', 'lists', '3', '118.132.31.56', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467770722');
INSERT INTO `wp_visit_log` VALUES ('723', '1', 'WeiSite', 'WeiSite', 'lists', '3', '118.132.31.56', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467770733');
INSERT INTO `wp_visit_log` VALUES ('724', '1', 'WeiSite', 'Template', 'detail', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/detail.html&mdm=31|34', '1467770742');
INSERT INTO `wp_visit_log` VALUES ('725', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467770747');
INSERT INTO `wp_visit_log` VALUES ('726', '1', 'WeiSite', 'WeiSite', 'lists', '3', '118.132.31.56', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467770749');
INSERT INTO `wp_visit_log` VALUES ('727', '1', 'WeiSite', 'Template', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/lists/mdm/31%7C34.html', '1467770762');
INSERT INTO `wp_visit_log` VALUES ('728', '1', 'WeiSite', 'Template', 'detail', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/detail.html&mdm=31|34', '1467770767');
INSERT INTO `wp_visit_log` VALUES ('729', '1', 'WeiSite', 'WeiSite', 'preview_cms', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/preview_cms/mdm/31%7C34.html', '1467770771');
INSERT INTO `wp_visit_log` VALUES ('730', '1', 'WeiSite', 'WeiSite', 'lists', '1', '118.132.31.56', 'Google', '{\"from\":\"preview\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/publicid/1/from/preview.html', '1467770773');
INSERT INTO `wp_visit_log` VALUES ('731', '1', 'WeiSite', 'Template', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/lists/mdm/31%7C34.html', '1467770778');
INSERT INTO `wp_visit_log` VALUES ('732', '1', 'WeiSite', 'Template', 'detail', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/detail.html&mdm=31|34', '1467770783');
INSERT INTO `wp_visit_log` VALUES ('733', '1', 'WeiSite', 'Template', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/lists/mdm/31%7C34.html', '1467770804');
INSERT INTO `wp_visit_log` VALUES ('734', '1', 'WeiSite', 'Template', 'detail', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/detail.html&mdm=31|34', '1467770807');
INSERT INTO `wp_visit_log` VALUES ('735', '1', 'WeiSite', 'Cms', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Cms/lists/mdm/31%7C34.html', '1467770810');
INSERT INTO `wp_visit_log` VALUES ('736', '1', 'WeiSite', 'WeiSite', 'preview_cms', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/preview_cms/mdm/31%7C34.html', '1467770815');
INSERT INTO `wp_visit_log` VALUES ('737', '1', 'WeiSite', 'WeiSite', 'lists', '1', '118.132.31.56', 'Google', '{\"from\":\"preview\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/publicid/1/from/preview.html', '1467770815');
INSERT INTO `wp_visit_log` VALUES ('738', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467770819');
INSERT INTO `wp_visit_log` VALUES ('739', '1', 'WeiSite', 'WeiSite', 'lists', '3', '118.132.31.56', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467770820');
INSERT INTO `wp_visit_log` VALUES ('740', '1', 'WeiSite', 'WeiSite', 'lists', '3', '118.132.31.56', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467770826');
INSERT INTO `wp_visit_log` VALUES ('741', '1', 'WeiSite', 'Template', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/lists/mdm/31%7C34.html', '1467770948');
INSERT INTO `wp_visit_log` VALUES ('742', '1', 'WeiSite', 'WeiSite', 'lists', '3', '118.132.31.56', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467770971');
INSERT INTO `wp_visit_log` VALUES ('743', '1', 'WeiSite', 'Template', 'detail', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/detail/mdm/31%7C34.html', '1467770994');
INSERT INTO `wp_visit_log` VALUES ('744', '1', 'WeiSite', 'Template', 'footer', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/footer.html&mdm=31|35', '1467770999');
INSERT INTO `wp_visit_log` VALUES ('745', '1', 'WeiSite', 'Footer', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Footer/lists/mdm/31%7C35.html', '1467771007');
INSERT INTO `wp_visit_log` VALUES ('746', '1', 'WeiSite', 'Template', 'index', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/index.html&mdm=31|33', '1467771015');
INSERT INTO `wp_visit_log` VALUES ('747', '1', 'WeiSite', 'Slideshow', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Slideshow/lists/mdm/31%7C33.html', '1467771032');
INSERT INTO `wp_visit_log` VALUES ('748', '1', 'WeiSite', 'Slideshow', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"1\",\"model\":\"102\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Slideshow/edit/id/1/model/102/mdm/31|33.html', '1467771036');
INSERT INTO `wp_visit_log` VALUES ('749', '1', 'WeiSite', 'Template', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/lists.html&mdm=31|34', '1467771044');
INSERT INTO `wp_visit_log` VALUES ('750', '1', 'WeiSite', 'Cms', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Cms/lists/mdm/31%7C34.html', '1467771048');
INSERT INTO `wp_visit_log` VALUES ('751', '1', 'WeiSite', 'Cms', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"3\",\"model\":\"36\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Cms/edit/id/3/model/36/mdm/31|34.html', '1467771060');
INSERT INTO `wp_visit_log` VALUES ('752', '1', 'WeiSite', 'WeiSite', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/config.html&mdm=31|32', '1467771083');
INSERT INTO `wp_visit_log` VALUES ('753', '1', 'WeiSite', 'Template', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/lists.html&mdm=31|34', '1467771094');
INSERT INTO `wp_visit_log` VALUES ('754', '1', 'WeiSite', 'WeiSite', 'lists', '1', '118.132.31.56', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467771232');
INSERT INTO `wp_visit_log` VALUES ('755', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467771248');
INSERT INTO `wp_visit_log` VALUES ('756', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467771250');
INSERT INTO `wp_visit_log` VALUES ('757', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists.html&mdm=45|47', '1467771254');
INSERT INTO `wp_visit_log` VALUES ('758', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"8\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/8.html', '1467771257');
INSERT INTO `wp_visit_log` VALUES ('759', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467771276');
INSERT INTO `wp_visit_log` VALUES ('760', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"8\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/8.html', '1467771280');
INSERT INTO `wp_visit_log` VALUES ('761', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467771289');
INSERT INTO `wp_visit_log` VALUES ('762', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467771294');
INSERT INTO `wp_visit_log` VALUES ('763', '1', 'WeiSite', 'WeiSite', 'lists', '1', '118.132.31.56', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467771353');
INSERT INTO `wp_visit_log` VALUES ('764', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"8\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/8.html', '1467771367');
INSERT INTO `wp_visit_log` VALUES ('765', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467771525');
INSERT INTO `wp_visit_log` VALUES ('766', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467771530');
INSERT INTO `wp_visit_log` VALUES ('767', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"8\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/8.html', '1467771547');
INSERT INTO `wp_visit_log` VALUES ('768', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467771552');
INSERT INTO `wp_visit_log` VALUES ('769', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467771557');
INSERT INTO `wp_visit_log` VALUES ('770', '1', 'UserCenter', 'Wap', 'userCenter', '1', '118.132.31.56', 'Google', '{\"from\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/Wap/userCenter/from/1.html', '1467771621');
INSERT INTO `wp_visit_log` VALUES ('771', '1', 'BusinessCard', 'Wap', 'choose_template', '1', '118.132.31.56', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/BusinessCard/Wap/choose_template/id/1.html', '1467771721');
INSERT INTO `wp_visit_log` VALUES ('772', '1', 'BusinessCard', 'Wap', 'choose_template', '1', '118.132.31.56', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/BusinessCard/Wap/choose_template/id/1.html', '1467771742');
INSERT INTO `wp_visit_log` VALUES ('773', '1', 'Home', 'Public', 'lists', '1', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467771804');
INSERT INTO `wp_visit_log` VALUES ('774', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467771830');
INSERT INTO `wp_visit_log` VALUES ('775', '1', 'BusinessCard', 'BusinessCard', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/BusinessCard/BusinessCard/lists.html', '1467771838');
INSERT INTO `wp_visit_log` VALUES ('776', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467771970');
INSERT INTO `wp_visit_log` VALUES ('777', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists.html&mdm=45|47', '1467771973');
INSERT INTO `wp_visit_log` VALUES ('778', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"8\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/8.html', '1467771977');
INSERT INTO `wp_visit_log` VALUES ('779', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467771985');
INSERT INTO `wp_visit_log` VALUES ('780', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"9\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/9.html', '1467771989');
INSERT INTO `wp_visit_log` VALUES ('781', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467772001');
INSERT INTO `wp_visit_log` VALUES ('782', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467772006');
INSERT INTO `wp_visit_log` VALUES ('783', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467772120');
INSERT INTO `wp_visit_log` VALUES ('784', '1', 'UserCenter', 'UserCenter', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/config.html', '1467772123');
INSERT INTO `wp_visit_log` VALUES ('785', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html', '1467772169');
INSERT INTO `wp_visit_log` VALUES ('786', '1', 'UserCenter', 'UserCenter', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/config.html', '1467772175');
INSERT INTO `wp_visit_log` VALUES ('787', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html', '1467772185');
INSERT INTO `wp_visit_log` VALUES ('788', '1', 'UserCenter', 'UserCenter', 'detail', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/detail/uid/6.html', '1467772193');
INSERT INTO `wp_visit_log` VALUES ('789', '1', 'UserCenter', 'UserCenter', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/config.html', '1467772196');
INSERT INTO `wp_visit_log` VALUES ('790', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html', '1467772199');
INSERT INTO `wp_visit_log` VALUES ('791', '1', 'UserCenter', 'UserCenter', 'detail', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/detail/uid/3.html', '1467772203');
INSERT INTO `wp_visit_log` VALUES ('792', '1', 'Home', 'WeixinMessage', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/WeixinMessage/lists.html&mdm=15|44', '1467772209');
INSERT INTO `wp_visit_log` VALUES ('793', '1', 'Home', 'UserTag', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/UserTag/lists.html&mdm=15|362', '1467772212');
INSERT INTO `wp_visit_log` VALUES ('794', '1', 'QrAdmin', 'QrAdmin', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/QrAdmin/QrAdmin/lists.html&mdm=15|363', '1467772215');
INSERT INTO `wp_visit_log` VALUES ('795', '1', 'Home', 'AuthGroup', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/AuthGroup/lists.html&mdm=15|41', '1467772224');
INSERT INTO `wp_visit_log` VALUES ('796', '1', 'Coupon', 'Coupon', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Coupon/lists.html&mdm=356', '1467772227');
INSERT INTO `wp_visit_log` VALUES ('797', '1', 'Coupon', 'Shop', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Shop/lists.html', '1467772234');
INSERT INTO `wp_visit_log` VALUES ('798', '1', 'RealPrize', 'RealPrize', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/RealPrize/RealPrize/lists.html&mdm=356|29', '1467772247');
INSERT INTO `wp_visit_log` VALUES ('799', '1', 'RealPrize', 'RealPrize', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"64\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/RealPrize/RealPrize/add/model/64/mdm/356%7C29.html', '1467772263');
INSERT INTO `wp_visit_log` VALUES ('800', '1', 'RealPrize', 'RealPrize', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"real_prize\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/RealPrize/RealPrize/lists/model/real_prize.html', '1467772357');
INSERT INTO `wp_visit_log` VALUES ('801', '1', 'RealPrize', 'RealPrize', 'index', '1', '118.132.31.56', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/RealPrize/RealPrize/index/id/1.html', '1467772362');
INSERT INTO `wp_visit_log` VALUES ('802', '1', 'CardVouchers', 'CardVouchers', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CardVouchers/CardVouchers/lists.html&mdm=356|357', '1467772377');
INSERT INTO `wp_visit_log` VALUES ('803', '1', 'CardVouchers', 'Wap', 'index', '1', '118.132.31.56', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CardVouchers/Wap/index/id/1.html', '1467772385');
INSERT INTO `wp_visit_log` VALUES ('804', '1', 'Weiba', 'Weiba', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Weiba/Weiba/lists.html&mdm=358', '1467772398');
INSERT INTO `wp_visit_log` VALUES ('805', '1', 'Coupon', 'Coupon', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Coupon/lists.html&mdm=356', '1467772411');
INSERT INTO `wp_visit_log` VALUES ('806', '1', 'Home', 'Material', 'material_lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/material_lists.html&mdm=60', '1467772414');
INSERT INTO `wp_visit_log` VALUES ('807', '1', 'Coupon', 'Coupon', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Coupon/lists.html&mdm=356', '1467772421');
INSERT INTO `wp_visit_log` VALUES ('808', '1', 'Home', 'Public', 'lists', '1', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467772426');
INSERT INTO `wp_visit_log` VALUES ('809', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467772430');
INSERT INTO `wp_visit_log` VALUES ('810', '1', 'Home', 'Material', 'material_lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/material_lists.html&mdm=60', '1467772435');
INSERT INTO `wp_visit_log` VALUES ('811', '1', 'Coupon', 'Coupon', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Coupon/lists.html&mdm=356', '1467772439');
INSERT INTO `wp_visit_log` VALUES ('812', '1', 'RealPrize', 'RealPrize', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/RealPrize/RealPrize/lists.html&mdm=356|29', '1467772621');
INSERT INTO `wp_visit_log` VALUES ('813', '1', 'WeiSite', 'WeiSite', 'index', '0', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467772653');
INSERT INTO `wp_visit_log` VALUES ('814', '1', 'WeiSite', 'WeiSite', 'lists', '3', '118.132.31.56', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467772658');
INSERT INTO `wp_visit_log` VALUES ('815', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467772660');
INSERT INTO `wp_visit_log` VALUES ('816', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467772663');
INSERT INTO `wp_visit_log` VALUES ('817', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467772719');
INSERT INTO `wp_visit_log` VALUES ('818', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467772722');
INSERT INTO `wp_visit_log` VALUES ('819', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467772834');
INSERT INTO `wp_visit_log` VALUES ('820', '1', 'Card', 'CardPrivilege', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardPrivilege/lists/mdm/15%7C342.html', '1467773056');
INSERT INTO `wp_visit_log` VALUES ('821', '1', 'Card', 'CardLevel', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardLevel/lists/mdm/15%7C342.html', '1467773058');
INSERT INTO `wp_visit_log` VALUES ('822', '1', 'Card', 'CardLevel', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"1\",\"model\":\"167\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardLevel/edit/id/1/model/167/mdm/15|342.html', '1467773062');
INSERT INTO `wp_visit_log` VALUES ('823', '1', 'Card', 'CardLevel', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"167\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardLevel/lists/model/167/mdm/15%7C342.html', '1467773073');
INSERT INTO `wp_visit_log` VALUES ('824', '1', 'WeiSite', 'WeiSite', 'index', '0', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467782008');
INSERT INTO `wp_visit_log` VALUES ('825', '1', 'Home', 'Public', 'lists', '1', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467794596');
INSERT INTO `wp_visit_log` VALUES ('826', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467794600');
INSERT INTO `wp_visit_log` VALUES ('827', '1', 'Ask', 'Ask', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/lists.html', '1467794613');
INSERT INTO `wp_visit_log` VALUES ('828', '1', 'Ask', 'Ask', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"24\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/add/model/24.html', '1467794720');
INSERT INTO `wp_visit_log` VALUES ('829', '1', 'Ask', 'Ask', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"24\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/lists/model/24.html', '1467794948');
INSERT INTO `wp_visit_log` VALUES ('830', '1', 'Ask', 'Ask', 'index', '1', '118.132.31.56', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/index/id/1.html', '1467794951');
INSERT INTO `wp_visit_log` VALUES ('831', '1', 'Home', 'Public', 'lists', '1', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467795254');
INSERT INTO `wp_visit_log` VALUES ('832', '1', 'Home', 'Public', 'step_0', '1', '118.132.31.56', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/step_0/id/1.html', '1467795258');
INSERT INTO `wp_visit_log` VALUES ('833', '1', 'Home', 'Public', 'add', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/add.html', '1467795266');
INSERT INTO `wp_visit_log` VALUES ('834', '1', 'Coupon', 'Wap', 'personal', '3', '118.132.31.56', 'Safari', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html', '1467795291');
INSERT INTO `wp_visit_log` VALUES ('835', '1', 'UserCenter', 'Wap', 'userCenter', '1', '118.132.31.56', 'Google', '{\"from\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/Wap/userCenter/from/1.html', '1467795334');
INSERT INTO `wp_visit_log` VALUES ('836', '1', 'UserCenter', 'Wap', 'bind_prize_info', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/Wap/bind_prize_info.html', '1467795337');
INSERT INTO `wp_visit_log` VALUES ('837', '1', 'UserCenter', 'Wap', 'userCenter', '1', '118.132.31.56', 'Google', '{\"from\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/Wap/userCenter/from/1.html', '1467795339');
INSERT INTO `wp_visit_log` VALUES ('838', '1', 'Coupon', 'Wap', 'personal', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html', '1467795345');
INSERT INTO `wp_visit_log` VALUES ('839', '1', 'UserCenter', 'Wap', 'userCenter', '1', '118.132.31.56', 'Google', '{\"from\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/Wap/userCenter/from/1.html', '1467795346');
INSERT INTO `wp_visit_log` VALUES ('840', '1', 'Coupon', 'Wap', 'personal', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html', '1467795348');
INSERT INTO `wp_visit_log` VALUES ('841', '1', 'Coupon', 'Wap', 'personal', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html', '1467795352');
INSERT INTO `wp_visit_log` VALUES ('842', '1', 'Coupon', 'Wap', 'personal', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html', '1467795355');
INSERT INTO `wp_visit_log` VALUES ('843', '1', 'Coupon', 'Wap', 'personal', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html', '1467795359');
INSERT INTO `wp_visit_log` VALUES ('844', '1', 'Home', 'Public', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists.html', '1467795582');
INSERT INTO `wp_visit_log` VALUES ('845', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467795587');
INSERT INTO `wp_visit_log` VALUES ('846', '1', 'WeiSite', 'WeiSite', 'index', '1', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467795820');
INSERT INTO `wp_visit_log` VALUES ('847', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467795826');
INSERT INTO `wp_visit_log` VALUES ('848', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467796198');
INSERT INTO `wp_visit_log` VALUES ('849', '1', 'WeiSite', 'WeiSite', 'index', '1', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467796247');
INSERT INTO `wp_visit_log` VALUES ('850', '1', 'WeiSite', 'WeiSite', 'index', '1', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467796504');
INSERT INTO `wp_visit_log` VALUES ('851', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467796512');
INSERT INTO `wp_visit_log` VALUES ('852', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467796595');
INSERT INTO `wp_visit_log` VALUES ('853', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467796753');
INSERT INTO `wp_visit_log` VALUES ('854', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467796792');
INSERT INTO `wp_visit_log` VALUES ('855', '1', 'WeiSite', 'WeiSite', 'index', '1', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467796858');
INSERT INTO `wp_visit_log` VALUES ('856', '1', 'WeiSite', 'WeiSite', 'index', '1', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467797390');
INSERT INTO `wp_visit_log` VALUES ('857', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467797402');
INSERT INTO `wp_visit_log` VALUES ('858', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467797475');
INSERT INTO `wp_visit_log` VALUES ('859', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467797574');
INSERT INTO `wp_visit_log` VALUES ('860', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467797815');
INSERT INTO `wp_visit_log` VALUES ('861', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467798113');
INSERT INTO `wp_visit_log` VALUES ('862', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467798201');
INSERT INTO `wp_visit_log` VALUES ('863', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467798208');
INSERT INTO `wp_visit_log` VALUES ('864', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467798384');
INSERT INTO `wp_visit_log` VALUES ('865', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467798387');
INSERT INTO `wp_visit_log` VALUES ('866', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467798393');
INSERT INTO `wp_visit_log` VALUES ('867', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467798400');
INSERT INTO `wp_visit_log` VALUES ('868', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467798407');
INSERT INTO `wp_visit_log` VALUES ('869', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467798480');
INSERT INTO `wp_visit_log` VALUES ('870', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467798490');
INSERT INTO `wp_visit_log` VALUES ('871', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467798492');
INSERT INTO `wp_visit_log` VALUES ('872', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467798584');
INSERT INTO `wp_visit_log` VALUES ('873', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467798946');
INSERT INTO `wp_visit_log` VALUES ('874', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467798992');
INSERT INTO `wp_visit_log` VALUES ('875', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467798996');
INSERT INTO `wp_visit_log` VALUES ('876', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Safari', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467799011');
INSERT INTO `wp_visit_log` VALUES ('877', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467799051');
INSERT INTO `wp_visit_log` VALUES ('878', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467799081');
INSERT INTO `wp_visit_log` VALUES ('879', '1', 'WeiSite', 'WeiSite', 'index', '0', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\",\"from\":\"timeline\",\"isappinstalled\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html&from=timeline&isappinstalled=0', '1467800582');
INSERT INTO `wp_visit_log` VALUES ('880', '1', 'Ask', 'Ask', 'index', '1', '118.132.31.56', 'Google', '{\"id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/index/id/1.html', '1467811057');
INSERT INTO `wp_visit_log` VALUES ('881', '1', 'Ask', 'Ask', 'show', '0', '118.132.31.56', 'Google', '{\"ask_id\":\"1\",\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/show/ask_id/1/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467811109');
INSERT INTO `wp_visit_log` VALUES ('882', '1', 'Ask', 'Ask', 'percent', '3', '118.132.31.56', 'Google', '{\"ask_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/percent/ask_id/1.html', '1467811114');
INSERT INTO `wp_visit_log` VALUES ('883', '1', 'Ask', 'Answer', 'lists', '1', '118.132.31.56', 'Google', '{\"ask_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Answer/lists/ask_id/1.html', '1467811128');
INSERT INTO `wp_visit_log` VALUES ('884', '1', 'Ask', 'Ask', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"24\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/lists/model/24.html', '1467811131');
INSERT INTO `wp_visit_log` VALUES ('885', '1', 'Ask', 'Ask', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"1\",\"model\":\"24\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/edit/id/1/model/24.html', '1467811134');
INSERT INTO `wp_visit_log` VALUES ('886', '1', 'Ask', 'Ask', 'show', '3', '118.132.31.56', 'Google', '{\"ask_id\":\"1\",\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/show/ask_id/1/token/gh_89d5cf544493.html', '1467811143');
INSERT INTO `wp_visit_log` VALUES ('887', '1', 'Ask', 'Ask', 'percent', '3', '118.132.31.56', 'Google', '{\"ask_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/percent/ask_id/1.html', '1467811146');
INSERT INTO `wp_visit_log` VALUES ('888', '1', 'Ask', 'Ask', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"24\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/lists/model/24.html', '1467811150');
INSERT INTO `wp_visit_log` VALUES ('889', '1', 'Ask', 'Ask', 'add', '1', '118.132.31.56', 'Google', '{\"model\":\"24\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/add/model/24.html', '1467811155');
INSERT INTO `wp_visit_log` VALUES ('890', '1', 'DeveloperTool', 'DeveloperTool', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/DeveloperTool/DeveloperTool/lists.html', '1467811401');
INSERT INTO `wp_visit_log` VALUES ('891', '1', 'Coupon', 'Wap', 'personal', '3', '118.132.31.56', 'Safari', '{\"use\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html&use=1', '1467815678');
INSERT INTO `wp_visit_log` VALUES ('892', '1', 'Coupon', 'Wap', 'personal', '3', '118.132.31.56', 'Safari', '{\"use\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html&use=1', '1467815735');
INSERT INTO `wp_visit_log` VALUES ('893', '1', 'WeiSite', 'WeiSite', 'index', '0', '61.160.23.246', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467816130');
INSERT INTO `wp_visit_log` VALUES ('894', '1', 'WeiSite', 'WeiSite', 'lists', '3', '61.160.23.246', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467816134');
INSERT INTO `wp_visit_log` VALUES ('895', '1', 'WeiSite', 'WeiSite', 'lists', '3', '61.160.23.246', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467816139');
INSERT INTO `wp_visit_log` VALUES ('896', '1', 'WeiSite', 'WeiSite', 'index', '3', '61.160.23.246', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467816144');
INSERT INTO `wp_visit_log` VALUES ('897', '1', 'WeiSite', 'WeiSite', 'index', '3', '61.160.23.246', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467816148');
INSERT INTO `wp_visit_log` VALUES ('898', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467816547');
INSERT INTO `wp_visit_log` VALUES ('899', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467816549');
INSERT INTO `wp_visit_log` VALUES ('900', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists.html&mdm=45|47', '1467816553');
INSERT INTO `wp_visit_log` VALUES ('901', '1', 'CustomMenu', 'CustomMenu', 'add', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/add.html', '1467816557');
INSERT INTO `wp_visit_log` VALUES ('902', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"34\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/34.html', '1467816588');
INSERT INTO `wp_visit_log` VALUES ('903', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"10\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/10.html', '1467816595');
INSERT INTO `wp_visit_log` VALUES ('904', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467816603');
INSERT INTO `wp_visit_log` VALUES ('905', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"10\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/10.html', '1467816610');
INSERT INTO `wp_visit_log` VALUES ('906', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467816615');
INSERT INTO `wp_visit_log` VALUES ('907', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467816622');
INSERT INTO `wp_visit_log` VALUES ('908', '1', 'CustomMenu', 'CustomMenu', 'edit', '1', '118.132.31.56', 'Google', '{\"id\":\"10\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/edit/id/10.html', '1467816649');
INSERT INTO `wp_visit_log` VALUES ('909', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467816655');
INSERT INTO `wp_visit_log` VALUES ('910', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', '{\"model\":\"custom_menu\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists/model/custom_menu.html', '1467816662');
INSERT INTO `wp_visit_log` VALUES ('911', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467816697');
INSERT INTO `wp_visit_log` VALUES ('912', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467816700');
INSERT INTO `wp_visit_log` VALUES ('913', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists/mdm/15%7C342.html', '1467816714');
INSERT INTO `wp_visit_log` VALUES ('914', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config/mdm/15%7C342.html', '1467816753');
INSERT INTO `wp_visit_log` VALUES ('915', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config/mdm/15%7C342.html', '1467816808');
INSERT INTO `wp_visit_log` VALUES ('916', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467816823');
INSERT INTO `wp_visit_log` VALUES ('917', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists.html&mdm=45|47', '1467816828');
INSERT INTO `wp_visit_log` VALUES ('918', '1', 'CustomMenu', 'CustomMenu', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/CustomMenu/CustomMenu/lists.html&mdm=45|47', '1467816847');
INSERT INTO `wp_visit_log` VALUES ('919', '1', 'WeiSite', 'WeiSite', 'index', '0', '60.190.139.148', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467857225');
INSERT INTO `wp_visit_log` VALUES ('920', '1', 'Coupon', 'Wap', 'lists', '3', '118.132.31.56', 'Safari', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/lists.html', '1467857469');
INSERT INTO `wp_visit_log` VALUES ('921', '1', 'Home', 'Index', 'main', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Index/main/publicid/1.html', '1467857794');
INSERT INTO `wp_visit_log` VALUES ('922', '1', 'Wecome', 'Wecome', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467857804');
INSERT INTO `wp_visit_log` VALUES ('923', '1', 'UserCenter', 'UserCenter', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467857808');
INSERT INTO `wp_visit_log` VALUES ('924', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467857811');
INSERT INTO `wp_visit_log` VALUES ('925', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467858028');
INSERT INTO `wp_visit_log` VALUES ('926', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config/mdm/15%7C342.html', '1467858443');
INSERT INTO `wp_visit_log` VALUES ('927', '1', 'Card', 'Member', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Member/lists/mdm/15%7C342.html', '1467858448');
INSERT INTO `wp_visit_log` VALUES ('928', '1', 'Card', 'ShopMember', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/ShopMember/lists/mdm/15%7C342.html', '1467858451');
INSERT INTO `wp_visit_log` VALUES ('929', '1', 'Card', 'ShopMember', 'import', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/ShopMember/import/mdm/15%7C342.html', '1467858455');
INSERT INTO `wp_visit_log` VALUES ('930', '1', 'Card', 'MemberTransition', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/MemberTransition/lists/mdm/15%7C342.html', '1467858458');
INSERT INTO `wp_visit_log` VALUES ('931', '1', 'Card', 'MemberMarketing', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/MemberMarketing/lists/mdm/15%7C342.html', '1467858465');
INSERT INTO `wp_visit_log` VALUES ('932', '1', 'Card', 'Notice', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Notice/lists/mdm/15%7C342.html', '1467858468');
INSERT INTO `wp_visit_log` VALUES ('933', '1', 'Card', 'Notice', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Notice/lists/mdm/15%7C342.html', '1467858472');
INSERT INTO `wp_visit_log` VALUES ('934', '1', 'Card', 'Notice', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Notice/lists/mdm/15%7C342.html', '1467858479');
INSERT INTO `wp_visit_log` VALUES ('935', '1', 'Card', 'Card', 'config', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config/mdm/15%7C342.html', '1467858485');
INSERT INTO `wp_visit_log` VALUES ('936', '1', 'Card', 'CardPrivilege', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardPrivilege/lists/mdm/15%7C342.html', '1467858492');
INSERT INTO `wp_visit_log` VALUES ('937', '1', 'Card', 'CardLevel', 'lists', '1', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/CardLevel/lists/mdm/15%7C342.html', '1467858497');
INSERT INTO `wp_visit_log` VALUES ('938', '1', 'Coupon', 'Wap', 'personal', '3', '60.190.139.148', 'Google', '{\"use\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html&use=1', '1467879601');
INSERT INTO `wp_visit_log` VALUES ('939', '1', 'Coupon', 'Wap', 'personal', '3', '60.190.139.148', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html', '1467879607');
INSERT INTO `wp_visit_log` VALUES ('940', '1', 'Coupon', 'Wap', 'personal', '3', '60.190.139.148', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html', '1467879612');
INSERT INTO `wp_visit_log` VALUES ('941', '1', 'WeiSite', 'WeiSite', 'index', '0', '60.190.139.155', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467879830');
INSERT INTO `wp_visit_log` VALUES ('942', '1', 'Home', 'Public', 'lists', '11', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467898011');
INSERT INTO `wp_visit_log` VALUES ('943', '1', 'Home', 'Public', 'add', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/add.html', '1467898015');
INSERT INTO `wp_visit_log` VALUES ('944', '1', 'Home', 'Public', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists.html', '1467898032');
INSERT INTO `wp_visit_log` VALUES ('945', '1', 'Home', 'Public', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists.html', '1467898036');
INSERT INTO `wp_visit_log` VALUES ('946', '1', 'Wecome', 'Wecome', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467898042');
INSERT INTO `wp_visit_log` VALUES ('947', '1', 'Home', 'Public', 'lists', '11', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467898047');
INSERT INTO `wp_visit_log` VALUES ('948', '1', 'Wecome', 'Wecome', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467898048');
INSERT INTO `wp_visit_log` VALUES ('949', '1', 'Home', 'Public', 'lists', '11', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467898051');
INSERT INTO `wp_visit_log` VALUES ('950', '1', 'Wecome', 'Wecome', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467898053');
INSERT INTO `wp_visit_log` VALUES ('951', '1', 'UserCenter', 'UserCenter', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467898055');
INSERT INTO `wp_visit_log` VALUES ('952', '1', 'Card', 'Card', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/config.html&mdm=15|342', '1467898059');
INSERT INTO `wp_visit_log` VALUES ('953', '1', 'Vote', 'Vote', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/lists.html&mdm=17', '1467898062');
INSERT INTO `wp_visit_log` VALUES ('954', '1', 'WeiSite', 'WeiSite', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/config.html&mdm=31', '1467898067');
INSERT INTO `wp_visit_log` VALUES ('955', '1', 'Wecome', 'Wecome', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467898077');
INSERT INTO `wp_visit_log` VALUES ('956', '1', 'Home', 'Message', 'add', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/Message/add.html&mdm=45|50', '1467898080');
INSERT INTO `wp_visit_log` VALUES ('957', '1', 'Home', 'Message', 'add', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/Message/add.html&mdm=45|50', '1467898181');
INSERT INTO `wp_visit_log` VALUES ('958', '1', 'Home', 'Message', 'add', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/Message/add.html&mdm=45|50', '1467898200');
INSERT INTO `wp_visit_log` VALUES ('959', '1', 'WeiSite', 'WeiSite', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/config.html&mdm=31', '1467898320');
INSERT INTO `wp_visit_log` VALUES ('960', '1', 'WeiSite', 'Template', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/lists.html&mdm=31|34', '1467898324');
INSERT INTO `wp_visit_log` VALUES ('961', '1', 'WeiSite', 'Cms', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Cms/lists/mdm/31%7C34.html', '1467898334');
INSERT INTO `wp_visit_log` VALUES ('962', '1', 'WeiSite', 'WeiSite', 'index', '0', '61.147.72.28', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467898360');
INSERT INTO `wp_visit_log` VALUES ('963', '1', 'WeiSite', 'WeiSite', 'lists', '3', '61.147.72.28', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467898362');
INSERT INTO `wp_visit_log` VALUES ('964', '1', 'WeiSite', 'WeiSite', 'lists', '3', '61.147.72.28', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467898370');
INSERT INTO `wp_visit_log` VALUES ('965', '1', 'WeiSite', 'Cms', 'add', '11', '118.132.31.56', 'Google', '{\"model\":\"36\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Cms/add/model/36/mdm/31%7C34.html', '1467898478');
INSERT INTO `wp_visit_log` VALUES ('966', '1', 'WeiSite', 'Cms', 'lists', '11', '118.132.31.56', 'Google', '{\"model\":\"36\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Cms/lists/model/36/mdm/31%7C34.html', '1467898524');
INSERT INTO `wp_visit_log` VALUES ('967', '1', 'WeiSite', 'WeiSite', 'index', '3', '61.147.72.28', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467898535');
INSERT INTO `wp_visit_log` VALUES ('968', '1', 'WeiSite', 'WeiSite', 'lists', '3', '61.147.72.28', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467898538');
INSERT INTO `wp_visit_log` VALUES ('969', '1', 'WeiSite', 'WeiSite', 'detail', '3', '61.147.72.28', 'Google', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/detail/id/4.html', '1467898541');
INSERT INTO `wp_visit_log` VALUES ('970', '1', 'WeiSite', 'WeiSite', 'detail', '11', '118.132.31.56', 'Google', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/detail/id/4.html', '1467898566');
INSERT INTO `wp_visit_log` VALUES ('971', '1', 'WeiSite', 'WeiSite', 'detail', '3', '118.132.31.56', 'Safari', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/detail/id/4.html', '1467898574');
INSERT INTO `wp_visit_log` VALUES ('972', '1', 'Home', 'Public', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists.html', '1467901673');
INSERT INTO `wp_visit_log` VALUES ('973', '1', 'WeiSite', 'WeiSite', 'index', '0', '61.147.72.28', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467904936');
INSERT INTO `wp_visit_log` VALUES ('974', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467904942');
INSERT INTO `wp_visit_log` VALUES ('975', '1', 'WeiSite', 'WeiSite', 'lists', '3', '61.147.72.28', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467904944');
INSERT INTO `wp_visit_log` VALUES ('976', '1', 'WeiSite', 'WeiSite', 'detail', '3', '61.147.72.28', 'Google', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/detail/id/4.html', '1467904947');
INSERT INTO `wp_visit_log` VALUES ('977', '1', 'WeiSite', 'WeiSite', 'lists', '3', '61.147.72.28', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467904960');
INSERT INTO `wp_visit_log` VALUES ('978', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467904963');
INSERT INTO `wp_visit_log` VALUES ('979', '1', 'Coupon', 'Wap', 'personal', '8', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Coupon/Wap/personal.html', '1467911837');
INSERT INTO `wp_visit_log` VALUES ('980', '1', 'WeiSite', 'WeiSite', 'index', '0', '61.147.72.28', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467915611');
INSERT INTO `wp_visit_log` VALUES ('981', '1', 'WeiSite', 'WeiSite', 'index', '3', '118.132.31.56', 'Google', '{\"token\":\"gh_89d5cf544493\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493.html', '1467915617');
INSERT INTO `wp_visit_log` VALUES ('982', '1', 'Home', 'Public', 'lists', '11', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467943503');
INSERT INTO `wp_visit_log` VALUES ('983', '1', 'Home', 'Public', 'lists', '11', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467943512');
INSERT INTO `wp_visit_log` VALUES ('984', '1', 'UserCenter', 'Wap', 'bind_prize_info', '-938', '118.132.31.56', 'Safari', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/Wap/bind_prize_info.html', '1467943580');
INSERT INTO `wp_visit_log` VALUES ('985', '1', 'WeiSite', 'WeiSite', 'detail', '-941', '118.132.31.56', 'Safari', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/detail/id/4.html', '1467943589');
INSERT INTO `wp_visit_log` VALUES ('986', '1', 'WeiSite', 'WeiSite', 'detail', '11', '118.132.31.56', 'Google', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/detail/id/4.html', '1467943595');
INSERT INTO `wp_visit_log` VALUES ('987', '1', 'WeiSite', 'WeiSite', 'index', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index.html', '1467943606');
INSERT INTO `wp_visit_log` VALUES ('988', '1', 'WeiSite', 'WeiSite', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/config.html&mdm=31', '1467943621');
INSERT INTO `wp_visit_log` VALUES ('989', '1', 'Home', 'Material', 'material_lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Material/material_lists.html&mdm=60', '1467943628');
INSERT INTO `wp_visit_log` VALUES ('990', '1', 'Vote', 'Vote', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/lists.html&mdm=17', '1467943631');
INSERT INTO `wp_visit_log` VALUES ('991', '1', 'Home', 'Public', 'lists', '11', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467943657');
INSERT INTO `wp_visit_log` VALUES ('992', '1', 'Home', 'Public', 'lists', '11', '118.132.31.56', 'Google', '{\"from\":\"2\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/Public/lists/from/2.html', '1467943672');
INSERT INTO `wp_visit_log` VALUES ('993', '1', 'WeiSite', 'WeiSite', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/config.html&mdm=31', '1467943767');
INSERT INTO `wp_visit_log` VALUES ('994', '1', 'Wecome', 'Wecome', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467943770');
INSERT INTO `wp_visit_log` VALUES ('995', '1', 'UserCenter', 'UserCenter', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467943778');
INSERT INTO `wp_visit_log` VALUES ('996', '1', 'UserCenter', 'UserCenter', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html', '1467943793');
INSERT INTO `wp_visit_log` VALUES ('997', '1', 'UserCenter', 'UserCenter', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/config.html', '1467943801');
INSERT INTO `wp_visit_log` VALUES ('998', '1', 'UserCenter', 'UserCenter', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/config.html', '1467943814');
INSERT INTO `wp_visit_log` VALUES ('999', '1', 'Home', 'CreditConfig', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/CreditConfig/lists.html&mdm=15|42', '1467943820');
INSERT INTO `wp_visit_log` VALUES ('1000', '1', 'Home', 'CreditData', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467943825');
INSERT INTO `wp_visit_log` VALUES ('1001', '1', 'UserCenter', 'UserCenter', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15|16', '1467943831');
INSERT INTO `wp_visit_log` VALUES ('1002', '1', 'Home', 'CreditData', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists/uid/10.html', '1467943834');
INSERT INTO `wp_visit_log` VALUES ('1003', '1', 'UserCenter', 'UserCenter', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15|16', '1467943836');
INSERT INTO `wp_visit_log` VALUES ('1004', '1', 'UserCenter', 'UserCenter', 'detail', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/detail/uid/10.html', '1467943838');
INSERT INTO `wp_visit_log` VALUES ('1005', '1', 'UserCenter', 'UserCenter', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15|16', '1467943844');
INSERT INTO `wp_visit_log` VALUES ('1006', '1', 'Home', 'CreditConfig', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/CreditConfig/lists.html&mdm=15|42', '1467943850');
INSERT INTO `wp_visit_log` VALUES ('1007', '1', 'Home', 'AuthGroup', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/AuthGroup/lists.html&mdm=15|41', '1467943859');
INSERT INTO `wp_visit_log` VALUES ('1008', '1', 'UserCenter', 'UserCenter', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15|16', '1467943863');
INSERT INTO `wp_visit_log` VALUES ('1009', '1', 'Vote', 'Vote', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/lists.html&mdm=17', '1467944336');
INSERT INTO `wp_visit_log` VALUES ('1010', '1', 'WeiSite', 'WeiSite', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/config.html&mdm=31', '1467944339');
INSERT INTO `wp_visit_log` VALUES ('1011', '1', 'WeiSite', 'Template', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/lists.html&mdm=31|34', '1467944342');
INSERT INTO `wp_visit_log` VALUES ('1012', '1', 'WeiSite', 'Cms', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Cms/lists/mdm/31%7C34.html', '1467944344');
INSERT INTO `wp_visit_log` VALUES ('1013', '1', 'WeiSite', 'Cms', 'edit', '11', '118.132.31.56', 'Google', '{\"id\":\"4\",\"model\":\"36\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Cms/edit/id/4/model/36/mdm/31|34.html', '1467944357');
INSERT INTO `wp_visit_log` VALUES ('1014', '1', 'Vote', 'Vote', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/lists.html&mdm=17', '1467944497');
INSERT INTO `wp_visit_log` VALUES ('1015', '1', 'Wecome', 'Wecome', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Wecome/Wecome/config.html&mdm=45', '1467944501');
INSERT INTO `wp_visit_log` VALUES ('1016', '1', 'Leaflets', 'Leaflets', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Leaflets/Leaflets/config.html&mdm=45|49', '1467944505');
INSERT INTO `wp_visit_log` VALUES ('1017', '1', 'Leaflets', 'Leaflets', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Leaflets/Leaflets/config.html&mdm=45|49', '1467944562');
INSERT INTO `wp_visit_log` VALUES ('1018', '1', 'WeiSite', 'WeiSite', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/config.html&mdm=31', '1467944831');
INSERT INTO `wp_visit_log` VALUES ('1019', '1', 'WeiSite', 'Template', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/lists.html&mdm=31|34', '1467944833');
INSERT INTO `wp_visit_log` VALUES ('1020', '1', 'WeiSite', 'Template', 'detail', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/Template/detail/mdm/31%7C34.html', '1467944836');
INSERT INTO `wp_visit_log` VALUES ('1021', '1', 'WeiSite', 'WeiSite', 'detail', '-944', '118.132.31.56', 'Safari', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/detail/id/4.html', '1467944979');
INSERT INTO `wp_visit_log` VALUES ('1022', '1', 'WeiSite', 'WeiSite', 'detail', '-944', '118.132.31.56', 'Safari', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/detail/id/4.html', '1467945029');
INSERT INTO `wp_visit_log` VALUES ('1023', '1', 'UserCenter', 'Wap', 'bind_prize_info', '-938', '118.132.31.56', 'Safari', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/Wap/bind_prize_info.html', '1467945383');
INSERT INTO `wp_visit_log` VALUES ('1024', '1', 'WeiSite', 'WeiSite', 'detail', '-949', '118.132.31.56', 'Safari', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/detail/id/4.html', '1467945429');
INSERT INTO `wp_visit_log` VALUES ('1025', '1', 'WeiSite', 'WeiSite', 'detail', '-950', '118.132.31.56', 'Safari', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/detail/id/4.html', '1467945592');
INSERT INTO `wp_visit_log` VALUES ('1026', '1', 'WeiSite', 'WeiSite', 'detail', '-951', '118.132.31.56', 'Safari', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/detail/id/4.html', '1467945615');
INSERT INTO `wp_visit_log` VALUES ('1027', '1', 'WeiSite', 'WeiSite', 'detail', '-953', '118.132.31.56', 'Safari', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/detail/id/4.html', '1467945646');
INSERT INTO `wp_visit_log` VALUES ('1028', '1', 'WeiSite', 'WeiSite', 'detail', '-954', '118.132.31.56', 'Safari', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/detail/id/4.html', '1467945782');
INSERT INTO `wp_visit_log` VALUES ('1029', '1', 'WeiSite', 'WeiSite', 'index', '0', '61.147.72.28', 'Google', '{\"token\":\"gh_89d5cf544493\",\"openid\":\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467945914');
INSERT INTO `wp_visit_log` VALUES ('1030', '1', 'WeiSite', 'WeiSite', 'lists', '3', '61.147.72.28', 'Google', '{\"cate_id\":\"1\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html', '1467945916');
INSERT INTO `wp_visit_log` VALUES ('1031', '1', 'WeiSite', 'WeiSite', 'detail', '3', '61.147.72.28', 'Google', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/detail/id/4.html', '1467945919');
INSERT INTO `wp_visit_log` VALUES ('1032', '1', 'WeiSite', 'WeiSite', 'detail', '3', '61.147.72.28', 'Google', '{\"id\":\"4\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/detail/id/4.html', '1467945947');
INSERT INTO `wp_visit_log` VALUES ('1033', '1', 'UserCenter', 'UserCenter', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/lists.html&mdm=15', '1467947477');
INSERT INTO `wp_visit_log` VALUES ('1034', '1', 'UserCenter', 'UserCenter', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/config.html', '1467947479');
INSERT INTO `wp_visit_log` VALUES ('1035', '1', 'UserCenter', 'UserCenter', 'config', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/UserCenter/UserCenter/config.html', '1467947487');
INSERT INTO `wp_visit_log` VALUES ('1036', '1', 'Home', 'CreditConfig', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/home/CreditConfig/lists.html&mdm=15|42', '1467947681');
INSERT INTO `wp_visit_log` VALUES ('1037', '1', 'Home', 'CreditData', 'lists', '11', '118.132.31.56', 'Google', 'null', 'http://jasongan.cn/php/weiphp3/index.php?s=/Home/CreditData/lists.html', '1467947687');
INSERT INTO `wp_visit_log` VALUES ('1038', '1', 'WeiSite', 'WeiSite', 'detail', '-981', '61.147.72.28', 'Google', '{\"id\":\"4\",\"from\":\"singlemessage\",\"isappinstalled\":\"0\"}', 'http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/detail/id/4.html&from=singlemessage&isappinstalled=0', '1467947800');

-- -----------------------------
-- Table structure for `wp_vote`
-- -----------------------------
DROP TABLE IF EXISTS `wp_vote`;
;

-- -----------------------------
-- Records of `wp_vote`
-- -----------------------------
INSERT INTO `wp_vote` VALUES ('1', '吉他之神', '吉他之神', '只能选一个哦', '94', '0', '1467005700', '1467032400', '1', '1', '1467640172', '1467034840', 'gh_89d5cf544493', 'default');
INSERT INTO `wp_vote` VALUES ('2', '哈哈哈', '哈哈哈', '问问', '11', '0', '1467611100', '1469972700', '0', '1', '1467640241', '1467640241', 'gh_89d5cf544493', 'default');

-- -----------------------------
-- Table structure for `wp_vote_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_vote_log`;
;

-- -----------------------------
-- Records of `wp_vote_log`
-- -----------------------------
INSERT INTO `wp_vote_log` VALUES ('1', '1', '3', 'gh_89d5cf544493', '1', '1467034876');
INSERT INTO `wp_vote_log` VALUES ('2', '2', '6', 'gh_89d5cf544493', '3', '1467640260');

-- -----------------------------
-- Table structure for `wp_vote_option`
-- -----------------------------
DROP TABLE IF EXISTS `wp_vote_option`;
;

-- -----------------------------
-- Records of `wp_vote_option`
-- -----------------------------
INSERT INTO `wp_vote_option` VALUES ('1', '1', '何桑', '10', '0', '1');
INSERT INTO `wp_vote_option` VALUES ('2', '1', '阿追', '9', '0', '2');
INSERT INTO `wp_vote_option` VALUES ('3', '2', '和桑', '0', '0', '1');
INSERT INTO `wp_vote_option` VALUES ('4', '2', 'ss', '0', '0', '2');

-- -----------------------------
-- Table structure for `wp_weiba`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weiba`;
;

-- -----------------------------
-- Records of `wp_weiba`
-- -----------------------------
INSERT INTO `wp_weiba` VALUES ('1', '1', '阿拉比卡', '1', '1467019749', '10', '有问题请联系阿追', '0', '0', '0', '1', '103', '0', '1', '0', '有问题请联系阿追', '', '', '2', '2016-06-28', '', 'gh_89d5cf544493');

-- -----------------------------
-- Table structure for `wp_weiba_apply`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weiba_apply`;
;


-- -----------------------------
-- Table structure for `wp_weiba_blacklist`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weiba_blacklist`;
;


-- -----------------------------
-- Table structure for `wp_weiba_category`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weiba_category`;
;

-- -----------------------------
-- Records of `wp_weiba_category`
-- -----------------------------
INSERT INTO `wp_weiba_category` VALUES ('1', '咖啡知识', 'gh_89d5cf544493');
INSERT INTO `wp_weiba_category` VALUES ('2', '咖啡兼职', 'gh_89d5cf544493');

-- -----------------------------
-- Table structure for `wp_weiba_event`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weiba_event`;
;


-- -----------------------------
-- Table structure for `wp_weiba_event_attr`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weiba_event_attr`;
;


-- -----------------------------
-- Table structure for `wp_weiba_event_user`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weiba_event_user`;
;


-- -----------------------------
-- Table structure for `wp_weiba_favorite`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weiba_favorite`;
;


-- -----------------------------
-- Table structure for `wp_weiba_follow`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weiba_follow`;
;


-- -----------------------------
-- Table structure for `wp_weiba_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weiba_log`;
;


-- -----------------------------
-- Table structure for `wp_weiba_post`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weiba_post`;
;

-- -----------------------------
-- Records of `wp_weiba_post`
-- -----------------------------
INSERT INTO `wp_weiba_post` VALUES ('1', '1', '1', 'test', '<section label=\"Copyright © 2015 playhudong All Rights Reserved.\" style=\"\r\nmargin:1em auto;\r\npadding: 1em 2em;\r\nborder-style: none;\" id=\"shifu_c_001\"><span style=\"\r\nfloat: left;\r\nmargin-left: 19px;\r\nmargin-top: -9px;\r\noverflow: hidden;\r\ndisplay:block;\"><img style=\"\r\nvertical-align: top;\r\ndisplay:inline-block;\" src=\"http://1251001145.cdn.myqcloud.com/1251001145/style/images/card-3.gif\"/><section class=\"color\" style=\"\r\nmin-height: 30px;\r\ncolor: #fff;\r\ndisplay: inline-block;\r\ntext-align: center;\r\nbackground: #999999;\r\nfont-size: 15px;\r\npadding: 7px 5px;\r\nmin-width: 30px;\"><span style=\"font-size:15px;\"> 01 </span></section></span><section style=\"\r\npadding: 16px;\r\npadding-top: 28px;\r\nborder: 2px solid #999999;\r\nwidth: 100%;\r\nfont-size: 14px;\r\nline-height: 1.4;\">星期一天气晴我离开你／不带任何行李／除了一本陪我放逐的日记／今天天晴／心情很低／突然决定离开你</section></section><p><br/></p>', '1467019816', '1', '6', '3', '1467020811', '0', '0', '0', '0', '0', '0', '1', '', '0', '1', '0', '1', '21', '', '', '0', '0', '0', '0', 'gh_89d5cf544493');
INSERT INTO `wp_weiba_post` VALUES ('2', '1', '3', '敏明吗了', '拆吧哈哈哈看看LOL', '1467044985', '1', '5', '3', '1467095297', '0', '0', '0', '0', '0', '0', '1', '', '0', '1', '0', '0', '', '', '', '0', '0', '0', '0', 'gh_89d5cf544493');

-- -----------------------------
-- Table structure for `wp_weiba_post_digg`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weiba_post_digg`;
;

-- -----------------------------
-- Records of `wp_weiba_post_digg`
-- -----------------------------
INSERT INTO `wp_weiba_post_digg` VALUES ('1', '3', '0', '1467020802');

-- -----------------------------
-- Table structure for `wp_weiba_post_share_logs`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weiba_post_share_logs`;
;


-- -----------------------------
-- Table structure for `wp_weiba_reply`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weiba_reply`;
;

-- -----------------------------
-- Records of `wp_weiba_reply`
-- -----------------------------
INSERT INTO `wp_weiba_reply` VALUES ('1', '1', '1', '1', '3', '0', '0', '1467020811', '这个不错哦哈哈', '0', '0', '0', '0', '0');

-- -----------------------------
-- Table structure for `wp_weiba_reply_digg`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weiba_reply_digg`;
;


-- -----------------------------
-- Table structure for `wp_weiba_tag`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weiba_tag`;
;


-- -----------------------------
-- Table structure for `wp_weisite_category`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weisite_category`;
;

-- -----------------------------
-- Records of `wp_weisite_category`
-- -----------------------------
INSERT INTO `wp_weisite_category` VALUES ('1', '音乐精选', '108', '', '1', 'gh_89d5cf544493', '0', '0', '');
INSERT INTO `wp_weisite_category` VALUES ('2', '乐器交易', '110', '', '1', 'gh_89d5cf544493', '1', '0', '');

-- -----------------------------
-- Table structure for `wp_weisite_cms`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weisite_cms`;
;


-- -----------------------------
-- Table structure for `wp_weisite_footer`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weisite_footer`;
;


-- -----------------------------
-- Table structure for `wp_weisite_slideshow`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weisite_slideshow`;
;

-- -----------------------------
-- Records of `wp_weisite_slideshow`
-- -----------------------------
INSERT INTO `wp_weisite_slideshow` VALUES ('1', '悦慢玩意', '107', '', '1', '0', 'gh_89d5cf544493', '0');

-- -----------------------------
-- Table structure for `wp_weixin_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weixin_log`;
;

-- -----------------------------
-- Records of `wp_weixin_log`
-- -----------------------------
INSERT INTO `wp_weixin_log` VALUES ('1', '1467005441', '2016-06-27 13:30:41', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:78:\"invalid credential, access_token is invalid or not latest hint: [5xUk0441vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('2', '1467019454', '2016-06-27 17:24:14', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467019454\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微社区\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467019454</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微社区]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('3', '1467019454', '2016-06-27 17:24:14', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[快来微社区参与我们的讨论吧，<a href=\'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Weiba/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html\'>点击这里进入</a>]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467019454</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('4', '1467019861', '2016-06-27 17:31:01', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467019861\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467019861</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('5', '1467019861', '2016-06-27 17:31:01', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得2积分\r\n\r\n当前总积分102\r\n\r\n2016-06-27 17:31:01\r\n\r\n您今天是第1位签到\r\n\r\n签到排行榜：\r\n\r\n第1名  匿名  17:31:01\n]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467019861</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('6', '1467019884', '2016-06-27 17:31:24', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467019884\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467019884</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7', '1467019885', '2016-06-27 17:31:25', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[亲，今天已经签到过了，请明天再来哦，谢谢！]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467019884</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('8', '1467020479', '2016-06-27 17:41:19', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467020479\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"竞猜\";s:5:\"MsgId\";s:19:\"6300804980283783946\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467020479</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[竞猜]]></Content>\n<MsgId>6300804980283783946</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('9', '1467020496', '2016-06-27 17:41:36', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467020496\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官网\";s:5:\"MsgId\";s:19:\"6300805053298227979\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467020496</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6300805053298227979</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('10', '1467020496', '2016-06-27 17:41:36', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467020496</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('11', '1467020664', '2016-06-27 17:44:24', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467020664\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:15:\"欧洲杯竞猜\";s:5:\"MsgId\";s:19:\"6300805774852733747\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467020664</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[欧洲杯竞猜]]></Content>\n<MsgId>6300805774852733747</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('12', '1467020740', '2016-06-27 17:45:40', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467020739\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微社区\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467020739</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微社区]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('13', '1467020740', '2016-06-27 17:45:40', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[快来微社区参与我们的讨论吧，<a href=\'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Weiba/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html\'>点击这里进入</a>]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467020740</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('14', '1467020861', '2016-06-27 17:47:41', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467020861\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:15:\"欧洲杯竞猜\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467020861</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[欧洲杯竞猜]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('15', '1467021062', '2016-06-27 17:51:02', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467021062\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:15:\"欧洲杯竞猜\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467021062</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[欧洲杯竞猜]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('16', '1467021062', '2016-06-27 17:51:02', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467021062</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('17', '1467021091', '2016-06-27 17:51:31', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467021091\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"竞猜\";s:5:\"MsgId\";s:19:\"6300807608803769269\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467021091</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[竞猜]]></Content>\n<MsgId>6300807608803769269</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('18', '1467021263', '2016-06-27 17:54:23', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467021263\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:77:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html\";s:6:\"MenuId\";s:9:\"416529395\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467021263</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html]]></EventKey>\n<MenuId>416529395</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('19', '1467021263', '2016-06-27 17:54:23', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467021263</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('20', '1467021279', '2016-06-27 17:54:39', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467021279\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467021279</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('21', '1467021279', '2016-06-27 17:54:39', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢咖啡会员卡]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/cover.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/show/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467021279</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('22', '1467021322', '2016-06-27 17:55:22', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467021322\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微社区\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467021322</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微社区]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('23', '1467021322', '2016-06-27 17:55:22', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[快来微社区参与我们的讨论吧，<a href=\'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Weiba/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html\'>点击这里进入</a>]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467021322</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('24', '1467034864', '2016-06-27 21:41:04', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467034864\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:12:\"吉他之神\";s:5:\"MsgId\";s:19:\"6300866763388339772\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467034864</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[吉他之神]]></Content>\n<MsgId>6300866763388339772</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('25', '1467034864', '2016-06-27 21:41:04', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[吉他之神]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Public/static/icon/colors/1187295.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/show/id/1/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467034864</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('26', '1467035972', '2016-06-27 21:59:32', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467035971\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467035971</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('27', '1467035972', '2016-06-27 21:59:32', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢咖啡会员卡]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/cover.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/show/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467035971</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('28', '1467036775', '2016-06-27 22:12:55', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467036775\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官网\";s:5:\"MsgId\";s:19:\"6300874971070842968\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467036775</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6300874971070842968</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('29', '1467036776', '2016-06-27 22:12:56', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢城欢迎您]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Uploads/Picture/2016-06-27/57712693cc6b4.jpg]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467036775</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('30', '1467036864', '2016-06-27 22:14:24', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467036864\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:77:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html\";s:6:\"MenuId\";s:9:\"416529395\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467036864</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html]]></EventKey>\n<MenuId>416529395</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('31', '1467036864', '2016-06-27 22:14:24', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467036864</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('32', '1467036880', '2016-06-27 22:14:40', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467036880\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467036880</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('33', '1467036880', '2016-06-27 22:14:40', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢咖啡会员卡]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/cover.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/show/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467036880</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('34', '1467036889', '2016-06-27 22:14:49', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467036888\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微社区\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467036888</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微社区]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('35', '1467036889', '2016-06-27 22:14:49', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[快来微社区参与我们的讨论吧，<a href=\'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Weiba/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html\'>点击这里进入</a>]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467036889</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('36', '1467044828', '2016-06-28 00:27:08', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467044828\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:15:\"欧洲杯竞猜\";s:5:\"MsgId\";s:19:\"6300909558442479144\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467044828</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[欧洲杯竞猜]]></Content>\n<MsgId>6300909558442479144</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('37', '1467044829', '2016-06-28 00:27:09', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467044828</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('38', '1467044854', '2016-06-28 00:27:34', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467044853\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微社区\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467044853</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微社区]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('39', '1467044854', '2016-06-28 00:27:34', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[快来微社区参与我们的讨论吧，<a href=\'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Weiba/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html\'>点击这里进入</a>]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467044854</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('40', '1467045129', '2016-06-28 00:32:09', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467045129\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467045129</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('41', '1467045129', '2016-06-28 00:32:09', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分103\r\n\r\n2016-06-28 00:32:09\r\n\r\n您今天是第1位签到\r\n\r\n签到排行榜：\r\n\r\n第1名  匿名  00:32:09\n]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467045129</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('42', '1467045167', '2016-06-28 00:32:47', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467045167\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官网\";s:5:\"MsgId\";s:19:\"6300911014436392595\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467045167</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6300911014436392595</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('43', '1467045168', '2016-06-28 00:32:48', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢城欢迎您]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Uploads/Picture/2016-06-27/57712693cc6b4.jpg]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467045167</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('44', '1467045180', '2016-06-28 00:33:00', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [_2hFNa0180vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('45', '1467045187', '2016-06-28 00:33:07', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [nLMGka0187vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('46', '1467094526', '2016-06-28 14:15:26', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467094525\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467094525</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('47', '1467094527', '2016-06-28 14:15:27', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[亲，今天已经签到过了，请明天再来哦，谢谢！]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467094525</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('48', '1467095188', '2016-06-28 14:26:28', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467095188\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467095188</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('49', '1467095188', '2016-06-28 14:26:28', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢咖啡会员卡]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/cover.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/show/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467095188</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('50', '1467095258', '2016-06-28 14:27:38', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467095258\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微社区\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467095258</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微社区]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('51', '1467095258', '2016-06-28 14:27:38', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[快来微社区参与我们的讨论吧，<a href=\'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Weiba/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html\'>点击这里进入</a>]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467095258</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('52', '1467095327', '2016-06-28 14:28:47', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467095327\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:77:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html\";s:6:\"MenuId\";s:9:\"416529395\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467095327</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html]]></EventKey>\n<MenuId>416529395</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('53', '1467095327', '2016-06-28 14:28:47', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467095327</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('54', '1467095341', '2016-06-28 14:29:01', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467095340\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:77:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html\";s:6:\"MenuId\";s:9:\"416529395\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467095340</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html]]></EventKey>\n<MenuId>416529395</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('55', '1467095341', '2016-06-28 14:29:01', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467095341</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('56', '1467095353', '2016-06-28 14:29:13', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467095353\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:77:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html\";s:6:\"MenuId\";s:9:\"416529395\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467095353</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html]]></EventKey>\n<MenuId>416529395</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('57', '1467095353', '2016-06-28 14:29:13', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467095353</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('58', '1467100309', '2016-06-28 15:51:49', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [0afVza0309vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('59', '1467102741', '2016-06-28 16:32:21', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467102741\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467102741</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('60', '1467102742', '2016-06-28 16:32:22', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分104\r\n\r\n2016-06-28 16:32:22\r\n\r\n您今天是第1位签到\r\n\r\n签到排行榜：\r\n\r\n第1名  匿名  16:32:22\n]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467102741</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('61', '1467102976', '2016-06-28 16:36:16', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467102976\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467102976</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('62', '1467103114', '2016-06-28 16:38:34', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467103114\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467103114</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('63', '1467103114', '2016-06-28 16:38:34', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分105\r\n\r\n2016-06-28 16:38:34\r\n\r\n您今天是第1位签到\r\n\r\n签到排行榜：\r\n\r\n第1名  匿名  16:38:34\n]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467103114</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('64', '1467103227', '2016-06-28 16:40:27', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467103227\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467103227</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('65', '1467103227', '2016-06-28 16:40:27', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分106\r\n\r\n2016-06-28 16:40:27\r\n\r\n您今天是第1位签到\r\n\r\n签到排行榜：\r\n\r\n第1名  Jason  16:40:27\n]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467103227</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('66', '1467103285', '2016-06-28 16:41:25', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467103284\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467103284</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('67', '1467103285', '2016-06-28 16:41:25', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分107\r\n\r\n2016-06-28 16:41:25\r\n\r\n您今天是第1位签到\r\n\r\n签到排行榜：\r\n\r\n第1名  匿名  16:41:25\n]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467103285</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('68', '1467103317', '2016-06-28 16:41:57', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467103316\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467103316</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('69', '1467103317', '2016-06-28 16:41:57', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分108\r\n\r\n2016-06-28 16:41:57\r\n\r\n您今天是第1位签到\r\n\r\n签到排行榜：\r\n\r\n第1名  匿名  16:41:57\n]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467103317</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('70', '1467103513', '2016-06-28 16:45:13', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467103513\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467103513</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('71', '1467103513', '2016-06-28 16:45:13', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分109\r\n\r\n2016-06-28 16:45:13\r\n\r\n您今天是第1位签到\r\n\r\n签到排行榜：\r\n\r\n第1名  匿名  16:45:13\n]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467103513</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('72', '1467103609', '2016-06-28 16:46:49', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467103609\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467103609</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('73', '1467103620', '2016-06-28 16:47:00', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467103620\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467103620</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('74', '1467103620', '2016-06-28 16:47:00', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[亲，今天已经签到过了，请明天再来哦，谢谢！]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467103620</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('75', '1467103631', '2016-06-28 16:47:11', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467103631\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467103631</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('76', '1467103804', '2016-06-28 16:50:04', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467103804\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467103804</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('77', '1467103804', '2016-06-28 16:50:04', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467103804</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('78', '1467103842', '2016-06-28 16:50:42', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467103842\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467103842</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('79', '1467103842', '2016-06-28 16:50:42', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467103842</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('80', '1467103906', '2016-06-28 16:51:46', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467103906\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467103906</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('81', '1467103906', '2016-06-28 16:51:46', '<?xml version=\"1.0\"?>\n<xml><Content><item><![CDATA[in]]></item><item><item>3</item></item></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467103906</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('82', '1467104104', '2016-06-28 16:55:04', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467104104\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467104104</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('83', '1467104104', '2016-06-28 16:55:04', '<?xml version=\"1.0\"?>\n<xml><Content>3</Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467104104</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('84', '1467104215', '2016-06-28 16:56:55', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467104215\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467104215</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('85', '1467104215', '2016-06-28 16:56:55', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467104215</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('86', '1467104467', '2016-06-28 17:01:07', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467104467\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467104467</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('87', '1467104467', '2016-06-28 17:01:07', '<?xml version=\"1.0\"?>\n<xml><Content>3</Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467104467</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('88', '1467104623', '2016-06-28 17:03:43', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467104623\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467104623</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('89', '1467104623', '2016-06-28 17:03:43', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467104623</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('90', '1467104752', '2016-06-28 17:05:52', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467104752\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467104752</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('91', '1467104752', '2016-06-28 17:05:52', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467104752</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('92', '1467104834', '2016-06-28 17:07:14', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467104834\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467104834</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('93', '1467104834', '2016-06-28 17:07:14', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[阿追(J)]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467104834</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('94', '1467104878', '2016-06-28 17:07:58', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467104878\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467104878</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('95', '1467104878', '2016-06-28 17:07:58', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[Yangpu]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467104878</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('96', '1467104993', '2016-06-28 17:09:53', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467104993\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467104993</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('97', '1467104993', '2016-06-28 17:09:53', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分122\r\n\r\n2016-06-28 17:09:53\r\n\r\n您今天是第1位签到\r\n\r\n签到排行榜：\r\n\r\n第1名  阿追(J)  17:09:53\n]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467104993</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('98', '1467105032', '2016-06-28 17:10:32', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs7n2HMHKM-9uQTocr3Ausvo\";s:10:\"CreateTime\";s:10:\"1467105031\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs7n2HMHKM-9uQTocr3Ausvo]]></FromUserName>\n<CreateTime>1467105031</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('99', '1467105032', '2016-06-28 17:10:32', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分101\r\n\r\n2016-06-28 17:10:32\r\n\r\n您今天是第2位签到\r\n\r\n签到排行榜：\r\n\r\n第1名  阿追(J)  17:09:53\n第2名  \"%E4%B8%BB%E6%B2%BB%E5%8C%BB%E5%B8%88\"  17:10:32\n]]></Content><ToUserName><![CDATA[oYMvgs7n2HMHKM-9uQTocr3Ausvo]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467105032</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('100', '1467105124', '2016-06-28 17:12:04', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs7n2HMHKM-9uQTocr3Ausvo\";s:10:\"CreateTime\";s:10:\"1467105124\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs7n2HMHKM-9uQTocr3Ausvo]]></FromUserName>\n<CreateTime>1467105124</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('101', '1467105124', '2016-06-28 17:12:04', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分102\r\n\r\n2016-06-28 17:12:04\r\n\r\n您今天是第2位签到\r\n\r\n签到排行榜：\r\n\r\n第1名  阿追(J)  17:09:53\n第2名  \"%E4%B8%BB%E6%B2%BB%E5%8C%BB%E5%B8%88\"  17:12:04\n]]></Content><ToUserName><![CDATA[oYMvgs7n2HMHKM-9uQTocr3Ausvo]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467105124</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('102', '1467133254', '2016-06-29 01:00:54', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467133253\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467133253</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('103', '1467133254', '2016-06-29 01:00:54', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分123\r\n\r\n2016-06-29 01:00:54\r\n\r\n您今天是第1位签到\r\n\r\n签到排行榜：\r\n\r\n第1名  \"%E9%98%BF%E8%BF%BD%28J%29\"  01:00:54\n]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467133253</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('104', '1467166024', '2016-06-29 10:07:04', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [rHMtAa0024vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('105', '1467166063', '2016-06-29 10:07:43', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [T8m_na0063vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('106', '1467166067', '2016-06-29 10:07:47', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [liUAGa0066vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('107', '1467166073', '2016-06-29 10:07:53', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [c8efpa0073vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('108', '1467166080', '2016-06-29 10:08:00', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:79:\"invalid credential, access_token is invalid or not latest hint: [mSyr30079vr21]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('109', '1467166084', '2016-06-29 10:08:04', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [ZvsoRa0084vr21]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('110', '1467166090', '2016-06-29 10:08:10', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [yfr1za0090vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('111', '1467166092', '2016-06-29 10:08:12', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [7DUefA0092vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('112', '1467166095', '2016-06-29 10:08:15', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [uSIQUa0095vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('113', '1467166100', '2016-06-29 10:08:20', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [6ofdfA0099vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('114', '1467166106', '2016-06-29 10:08:26', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [npMxMa0106vr21]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('115', '1467166109', '2016-06-29 10:08:29', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:79:\"invalid credential, access_token is invalid or not latest hint: [Y6fI50109vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('116', '1467166117', '2016-06-29 10:08:37', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:79:\"invalid credential, access_token is invalid or not latest hint: [.S_v40116vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('117', '1467166123', '2016-06-29 10:08:43', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:78:\"invalid credential, access_token is invalid or not latest hint: [6fvT0123vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('118', '1467166131', '2016-06-29 10:08:51', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [itHEIa0131vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('119', '1467166139', '2016-06-29 10:08:59', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [QqyTaA0139vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('120', '1467166158', '2016-06-29 10:09:18', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [5e_VwA0158vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('121', '1467166162', '2016-06-29 10:09:22', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [GlDCJA0162vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('122', '1467166168', '2016-06-29 10:09:28', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:79:\"invalid credential, access_token is invalid or not latest hint: [gwyB90168vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('123', '1467166179', '2016-06-29 10:09:39', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [rlSoka0179vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('124', '1467166185', '2016-06-29 10:09:45', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [DfBLxa0184vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('125', '1467166189', '2016-06-29 10:09:49', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:76:\"invalid credential, access_token is invalid or not latest hint: [L60189vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('126', '1467166213', '2016-06-29 10:10:13', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [2YNz.a0213vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('127', '1467166218', '2016-06-29 10:10:18', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [l3ubaA0218vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('128', '1467166222', '2016-06-29 10:10:22', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [DzQbWA0222vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('129', '1467171695', '2016-06-29 11:41:35', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [TwmQra0695vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('130', '1467174254', '2016-06-29 12:24:14', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467174254\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467174254</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('131', '1467174313', '2016-06-29 12:25:13', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467174312\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467174312</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('132', '1467174337', '2016-06-29 12:25:37', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467174337\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467174337</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('133', '1467174338', '2016-06-29 12:25:38', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[亲，今天已经签到过了，请明天再来哦，谢谢！]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467174337</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('134', '1467174391', '2016-06-29 12:26:31', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467174391\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:77:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html\";s:6:\"MenuId\";s:9:\"416529395\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467174391</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html]]></EventKey>\n<MenuId>416529395</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('135', '1467174392', '2016-06-29 12:26:32', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467174391</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('136', '1467191394', '2016-06-29 17:09:54', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467191393\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:77:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html\";s:6:\"MenuId\";s:9:\"416529395\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467191393</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html]]></EventKey>\n<MenuId>416529395</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('137', '1467191394', '2016-06-29 17:09:54', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467191393</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('138', '1467191425', '2016-06-29 17:10:25', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467191425\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467191425</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('139', '1467191425', '2016-06-29 17:10:25', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢咖啡会员卡]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/cover.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/show/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467191425</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('140', '1467252928', '2016-06-30 10:15:28', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [HwuFwA0928vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('141', '1467252953', '2016-06-30 10:15:53', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [SyFjSA0953vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('142', '1467253008', '2016-06-30 10:16:48', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [8zmVqa0008vr21]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('143', '1467253012', '2016-06-30 10:16:52', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [5YZgXa0012vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('144', '1467253017', '2016-06-30 10:16:57', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [8ilz8a0017vr21]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('145', '1467253021', '2016-06-30 10:17:01', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [18Wdza0021vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('146', '1467253027', '2016-06-30 10:17:07', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [Px0Jxa0027vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('147', '1467253030', '2016-06-30 10:17:10', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [n0N6UA0030vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('148', '1467253032', '2016-06-30 10:17:12', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:78:\"invalid credential, access_token is invalid or not latest hint: [aNxw0032vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('149', '1467253041', '2016-06-30 10:17:21', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [AOWj.A0041vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('150', '1467253043', '2016-06-30 10:17:23', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [EzxaMa0043vr21]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('151', '1467253045', '2016-06-30 10:17:25', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [UzPfBa0045vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('152', '1467253046', '2016-06-30 10:17:26', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [gs2nba0046vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('153', '1467253047', '2016-06-30 10:17:27', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [WW1lpa0047vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('154', '1467253052', '2016-06-30 10:17:32', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [7Ge7QA0052vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('155', '1467253053', '2016-06-30 10:17:33', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [gLW2.a0053vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('156', '1467253053', '2016-06-30 10:17:33', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [lMedaA0053vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('157', '1467253057', '2016-06-30 10:17:37', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [V7ZsLA0057vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('158', '1467253059', '2016-06-30 10:17:39', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:77:\"invalid credential, access_token is invalid or not latest hint: [.2K0058vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('159', '1467253062', '2016-06-30 10:17:42', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [UryVfa0062vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('160', '1467253063', '2016-06-30 10:17:43', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [2pvsbA0063vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('161', '1467253067', '2016-06-30 10:17:47', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [K73zaa0067vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('162', '1467253072', '2016-06-30 10:17:52', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [dlclOa0072vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('163', '1467253074', '2016-06-30 10:17:54', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [e78Fca0074vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('164', '1467253076', '2016-06-30 10:17:56', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [zuEUbA0076vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('165', '1467253083', '2016-06-30 10:18:03', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [IBAoRA0083vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('166', '1467253084', '2016-06-30 10:18:04', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [GYt_1a0084vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('167', '1467253086', '2016-06-30 10:18:06', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:78:\"invalid credential, access_token is invalid or not latest hint: [HUeX0086vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('168', '1467253087', '2016-06-30 10:18:07', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [7zEYJa0087vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('169', '1467253088', '2016-06-30 10:18:08', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [OT_RrA0088vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('170', '1467253094', '2016-06-30 10:18:14', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [MxCUfa0094vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('171', '1467253102', '2016-06-30 10:18:22', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [mV1.qa0102vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('172', '1467253108', '2016-06-30 10:18:28', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:75:\"invalid credential, access_token is invalid or not latest hint: [20107vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('173', '1467253110', '2016-06-30 10:18:30', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [DRpSaa0110vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('174', '1467253117', '2016-06-30 10:18:37', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [hbTEWa0117vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('175', '1467253122', '2016-06-30 10:18:42', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [Q8ZCta0122vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('176', '1467253125', '2016-06-30 10:18:45', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [dcYLPA0125vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('177', '1467260600', '2016-06-30 12:23:20', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [zaYBMA0600vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('178', '1467260805', '2016-06-30 12:26:45', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467260805\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:77:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html\";s:6:\"MenuId\";s:9:\"416529395\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467260805</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html]]></EventKey>\n<MenuId>416529395</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('179', '1467260805', '2016-06-30 12:26:45', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467260805</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('180', '1467260871', '2016-06-30 12:27:51', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467260871\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:77:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html\";s:6:\"MenuId\";s:9:\"416529395\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467260871</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html]]></EventKey>\n<MenuId>416529395</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('181', '1467260871', '2016-06-30 12:27:51', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467260871</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('182', '1467350118', '2016-07-01 13:15:18', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs8VZHuvdA9ErlGyNuDxw_ds\";s:10:\"CreateTime\";s:10:\"1467350118\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微社区\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs8VZHuvdA9ErlGyNuDxw_ds]]></FromUserName>\n<CreateTime>1467350118</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微社区]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('183', '1467350119', '2016-07-01 13:15:19', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[快来微社区参与我们的讨论吧，<a href=\'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Weiba/Wap/index/token/gh_89d5cf544493/openid/oYMvgs8VZHuvdA9ErlGyNuDxw_ds.html\'>点击这里进入</a>]]></Content><ToUserName><![CDATA[oYMvgs8VZHuvdA9ErlGyNuDxw_ds]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467350118</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('184', '1467350142', '2016-07-01 13:15:42', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs8VZHuvdA9ErlGyNuDxw_ds\";s:10:\"CreateTime\";s:10:\"1467350142\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs8VZHuvdA9ErlGyNuDxw_ds]]></FromUserName>\n<CreateTime>1467350142</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('185', '1467350143', '2016-07-01 13:15:43', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢咖啡会员卡]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/cover.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/show/token/gh_89d5cf544493/openid/oYMvgs8VZHuvdA9ErlGyNuDxw_ds.html&openid=oYMvgs8VZHuvdA9ErlGyNuDxw_ds]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs8VZHuvdA9ErlGyNuDxw_ds]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467350142</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('186', '1467350150', '2016-07-01 13:15:50', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs8VZHuvdA9ErlGyNuDxw_ds\";s:10:\"CreateTime\";s:10:\"1467350150\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:77:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html\";s:6:\"MenuId\";s:9:\"416529395\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs8VZHuvdA9ErlGyNuDxw_ds]]></FromUserName>\n<CreateTime>1467350150</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html]]></EventKey>\n<MenuId>416529395</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('187', '1467350150', '2016-07-01 13:15:50', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs8VZHuvdA9ErlGyNuDxw_ds]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467350150</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('188', '1467362776', '2016-07-01 16:46:16', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467362775\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467362775</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('189', '1467362777', '2016-07-01 16:46:17', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分129\r\n\r\n2016-07-01 16:46:17\r\n\r\n您今天是第1位签到\r\n\r\n签到排行榜：\r\n\r\n第1名  \"%E9%98%BF%E8%BF%BD%28J%29\"  16:46:17\n]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467362776</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('190', '1467548424', '2016-07-03 20:20:24', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467548424\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微社区\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467548424</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微社区]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('191', '1467548425', '2016-07-03 20:20:25', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[快来微社区参与我们的讨论吧，<a href=\'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Weiba/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html\'>点击这里进入</a>]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467548424</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('192', '1467548444', '2016-07-03 20:20:44', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467548443\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微社区\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467548443</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微社区]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('193', '1467548444', '2016-07-03 20:20:44', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[快来微社区参与我们的讨论吧，<a href=\'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Weiba/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html\'>点击这里进入</a>]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467548444</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('194', '1467548461', '2016-07-03 20:21:01', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467548460\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467548460</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('195', '1467548461', '2016-07-03 20:21:01', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分130\r\n\r\n2016-07-03 20:21:01\r\n\r\n您今天是第1位签到\r\n\r\n签到排行榜：\r\n\r\n第1名  \"%E9%98%BF%E8%BF%BD%28J%29\"  20:21:01\n]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467548461</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('196', '1467548473', '2016-07-03 20:21:13', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467548473\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:77:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html\";s:6:\"MenuId\";s:9:\"416529395\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467548473</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Guess/Guess/index/id/1.html]]></EventKey>\n<MenuId>416529395</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('197', '1467548473', '2016-07-03 20:21:13', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467548473</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('198', '1467548541', '2016-07-03 20:22:21', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs8VZHuvdA9ErlGyNuDxw_ds\";s:10:\"CreateTime\";s:10:\"1467548540\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微社区\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs8VZHuvdA9ErlGyNuDxw_ds]]></FromUserName>\n<CreateTime>1467548540</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微社区]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('199', '1467548541', '2016-07-03 20:22:21', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[快来微社区参与我们的讨论吧，<a href=\'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Weiba/Wap/index/token/gh_89d5cf544493/openid/oYMvgs8VZHuvdA9ErlGyNuDxw_ds.html\'>点击这里进入</a>]]></Content><ToUserName><![CDATA[oYMvgs8VZHuvdA9ErlGyNuDxw_ds]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467548541</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('200', '1467549335', '2016-07-03 20:35:35', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467549335\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微社区\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467549335</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微社区]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('201', '1467549335', '2016-07-03 20:35:35', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[快来微社区参与我们的讨论吧，<a href=\'http://jasongan.cn/php/weiphp3/index.php?s=/addon/Weiba/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html\'>点击这里进入</a>]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467549335</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('202', '1467632079', '2016-07-04 19:34:39', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [80LnIa0079vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('203', '1467632949', '2016-07-04 19:49:09', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467632949\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:19:\"custom_sucai_text_2\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467632949</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[custom_sucai_text_2]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('204', '1467633179', '2016-07-04 19:52:59', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633179\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:80:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html\";s:6:\"MenuId\";s:9:\"416629219\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633179</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html]]></EventKey>\n<MenuId>416629219</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('205', '1467633179', '2016-07-04 19:52:59', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633179</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('206', '1467633182', '2016-07-04 19:53:02', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [uQOSoA0182vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('207', '1467633274', '2016-07-04 19:54:34', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633274\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:80:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html\";s:6:\"MenuId\";s:9:\"416629219\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633274</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html]]></EventKey>\n<MenuId>416629219</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('208', '1467633274', '2016-07-04 19:54:34', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633274</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('209', '1467633275', '2016-07-04 19:54:35', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [l0bp6a0275vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('210', '1467633278', '2016-07-04 19:54:38', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633278\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:80:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html\";s:6:\"MenuId\";s:9:\"416629219\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633278</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html]]></EventKey>\n<MenuId>416629219</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('211', '1467633278', '2016-07-04 19:54:38', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633278</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('212', '1467633279', '2016-07-04 19:54:39', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [pf0cca0279vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('213', '1467633292', '2016-07-04 19:54:52', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633292\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:80:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html\";s:6:\"MenuId\";s:9:\"416629219\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633292</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html]]></EventKey>\n<MenuId>416629219</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('214', '1467633292', '2016-07-04 19:54:52', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633292</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('215', '1467633293', '2016-07-04 19:54:53', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [RkiGpA0293vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('216', '1467633299', '2016-07-04 19:54:59', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633299\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:80:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html\";s:6:\"MenuId\";s:9:\"416629219\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633299</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html]]></EventKey>\n<MenuId>416629219</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('217', '1467633299', '2016-07-04 19:54:59', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633299</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('218', '1467633300', '2016-07-04 19:55:00', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [v5WDNa0300vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('219', '1467633319', '2016-07-04 19:55:19', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633318\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:80:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html\";s:6:\"MenuId\";s:9:\"416629219\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633318</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html]]></EventKey>\n<MenuId>416629219</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('220', '1467633319', '2016-07-04 19:55:19', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633319</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('221', '1467633320', '2016-07-04 19:55:20', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [HRJeIa0320vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('222', '1467633350', '2016-07-04 19:55:50', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633350\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:80:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html\";s:6:\"MenuId\";s:9:\"416629219\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633350</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html]]></EventKey>\n<MenuId>416629219</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('223', '1467633350', '2016-07-04 19:55:50', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633350</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('224', '1467633351', '2016-07-04 19:55:51', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [ite2ha0351vr21]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('225', '1467633368', '2016-07-04 19:56:08', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633368\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:80:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html\";s:6:\"MenuId\";s:9:\"416629219\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633368</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html]]></EventKey>\n<MenuId>416629219</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('226', '1467633368', '2016-07-04 19:56:08', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633368</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('227', '1467633371', '2016-07-04 19:56:11', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [i14Kqa0371vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('228', '1467633388', '2016-07-04 19:56:28', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633388\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:80:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html\";s:6:\"MenuId\";s:9:\"416629219\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633388</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html]]></EventKey>\n<MenuId>416629219</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('229', '1467633388', '2016-07-04 19:56:28', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633388</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('230', '1467633389', '2016-07-04 19:56:29', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [.Cn7Xa0389vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('231', '1467633476', '2016-07-04 19:57:56', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633475\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:80:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html\";s:6:\"MenuId\";s:9:\"416629219\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633475</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/publicid/1.html]]></EventKey>\n<MenuId>416629219</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('232', '1467633476', '2016-07-04 19:57:56', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633475</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('233', '1467633478', '2016-07-04 19:57:58', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [_OXAxa0478vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('234', '1467633495', '2016-07-04 19:58:15', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633494\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416629343\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633494</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416629343</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('235', '1467633495', '2016-07-04 19:58:15', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633495</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('236', '1467633502', '2016-07-04 19:58:22', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633502\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416629343\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633502</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416629343</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('237', '1467633502', '2016-07-04 19:58:22', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633502</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('238', '1467633584', '2016-07-04 19:59:44', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633584\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416629343\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633584</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416629343</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('239', '1467633585', '2016-07-04 19:59:45', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633584</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('240', '1467633594', '2016-07-04 19:59:54', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633593\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416629343\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633593</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416629343</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('241', '1467633594', '2016-07-04 19:59:54', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633594</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('242', '1467633604', '2016-07-04 20:00:04', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633604\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633604</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('243', '1467633604', '2016-07-04 20:00:04', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分131\r\n\r\n2016-07-04 20:00:04\r\n\r\n您今天是第1位签到]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633604</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('244', '1467633681', '2016-07-04 20:01:21', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633681\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微网站\";s:5:\"MsgId\";s:19:\"6303438662819726011\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633681</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微网站]]></Content>\n<MsgId>6303438662819726011</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('245', '1467633681', '2016-07-04 20:01:21', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633681</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('246', '1467633686', '2016-07-04 20:01:26', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467633686\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官网\";s:5:\"MsgId\";s:19:\"6303438684294562495\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467633686</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6303438684294562495</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('247', '1467633686', '2016-07-04 20:01:26', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢城欢迎您]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Uploads/Picture/2016-06-27/57712693cc6b4.jpg]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633686</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('248', '1467633833', '2016-07-04 20:03:53', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs7n2HMHKM-9uQTocr3Ausvo\";s:10:\"CreateTime\";s:10:\"1467633833\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官网\";s:5:\"MsgId\";s:19:\"6303439315654755055\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs7n2HMHKM-9uQTocr3Ausvo]]></FromUserName>\n<CreateTime>1467633833</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6303439315654755055</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('249', '1467633833', '2016-07-04 20:03:53', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢城欢迎您]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Uploads/Picture/2016-06-27/57712693cc6b4.jpg]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs7n2HMHKM-9uQTocr3Ausvo.html&openid=oYMvgs7n2HMHKM-9uQTocr3Ausvo]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs7n2HMHKM-9uQTocr3Ausvo]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467633833</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('250', '1467633886', '2016-07-04 20:04:46', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [bAj_cA0886vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('251', '1467638430', '2016-07-04 21:20:30', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467638430\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"会员卡\";s:5:\"MsgId\";s:19:\"6303459059619416339\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467638430</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[会员卡]]></Content>\n<MsgId>6303459059619416339</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('252', '1467638430', '2016-07-04 21:20:30', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢咖啡会员卡]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/cover.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/show/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467638430</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('253', '1467639974', '2016-07-04 21:46:14', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgsyEDncCLibJPRbvIwNPGsNA\";s:10:\"CreateTime\";s:10:\"1467639974\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgsyEDncCLibJPRbvIwNPGsNA]]></FromUserName>\n<CreateTime>1467639974</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('254', '1467639974', '2016-07-04 21:46:14', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分101\r\n\r\n2016-07-04 21:46:14\r\n\r\n您今天是第2位签到]]></Content><ToUserName><![CDATA[oYMvgsyEDncCLibJPRbvIwNPGsNA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467639974</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('255', '1467639996', '2016-07-04 21:46:36', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgsyEDncCLibJPRbvIwNPGsNA\";s:10:\"CreateTime\";s:10:\"1467639995\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官网\";s:5:\"MsgId\";s:19:\"6303465781243235244\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgsyEDncCLibJPRbvIwNPGsNA]]></FromUserName>\n<CreateTime>1467639995</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6303465781243235244</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('256', '1467639996', '2016-07-04 21:46:36', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢城欢迎您]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Uploads/Picture/2016-06-27/57712693cc6b4.jpg]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgsyEDncCLibJPRbvIwNPGsNA.html&openid=oYMvgsyEDncCLibJPRbvIwNPGsNA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgsyEDncCLibJPRbvIwNPGsNA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467639995</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('257', '1467640008', '2016-07-04 21:46:48', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [D2m8VA0008vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('258', '1467640148', '2016-07-04 21:49:08', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgsyEDncCLibJPRbvIwNPGsNA\";s:10:\"CreateTime\";s:10:\"1467640147\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:12:\"吉他之神\";s:5:\"MsgId\";s:19:\"6303466434078264304\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgsyEDncCLibJPRbvIwNPGsNA]]></FromUserName>\n<CreateTime>1467640147</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[吉他之神]]></Content>\n<MsgId>6303466434078264304</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('259', '1467640148', '2016-07-04 21:49:08', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[吉他之神]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Public/static/icon/colors/1187295.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/show/id/1/token/gh_89d5cf544493/openid/oYMvgsyEDncCLibJPRbvIwNPGsNA.html&openid=oYMvgsyEDncCLibJPRbvIwNPGsNA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgsyEDncCLibJPRbvIwNPGsNA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467640148</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('260', '1467640253', '2016-07-04 21:50:53', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgsyEDncCLibJPRbvIwNPGsNA\";s:10:\"CreateTime\";s:10:\"1467640253\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"哈哈哈\";s:5:\"MsgId\";s:19:\"6303466889344797722\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgsyEDncCLibJPRbvIwNPGsNA]]></FromUserName>\n<CreateTime>1467640253</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[哈哈哈]]></Content>\n<MsgId>6303466889344797722</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('261', '1467640253', '2016-07-04 21:50:53', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[哈哈哈]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Public/static/icon/colors/1187212.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Vote/Vote/show/id/2/token/gh_89d5cf544493/openid/oYMvgsyEDncCLibJPRbvIwNPGsNA.html&openid=oYMvgsyEDncCLibJPRbvIwNPGsNA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgsyEDncCLibJPRbvIwNPGsNA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467640253</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('262', '1467641305', '2016-07-04 22:08:25', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs8VZHuvdA9ErlGyNuDxw_ds\";s:10:\"CreateTime\";s:10:\"1467641305\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416629343\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs8VZHuvdA9ErlGyNuDxw_ds]]></FromUserName>\n<CreateTime>1467641305</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416629343</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('263', '1467641305', '2016-07-04 22:08:25', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs8VZHuvdA9ErlGyNuDxw_ds]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467641305</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('264', '1467641312', '2016-07-04 22:08:32', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs8VZHuvdA9ErlGyNuDxw_ds\";s:10:\"CreateTime\";s:10:\"1467641312\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416629343\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs8VZHuvdA9ErlGyNuDxw_ds]]></FromUserName>\n<CreateTime>1467641312</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416629343</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('265', '1467641312', '2016-07-04 22:08:32', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs8VZHuvdA9ErlGyNuDxw_ds]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467641312</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('266', '1467641581', '2016-07-04 22:13:01', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467641581\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"会员卡\";s:5:\"MsgId\";s:19:\"6303472593061367329\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467641581</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[会员卡]]></Content>\n<MsgId>6303472593061367329</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('267', '1467641581', '2016-07-04 22:13:01', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[咖啡会员卡]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/cover.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/show/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467641581</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('268', '1467681499', '2016-07-05 09:18:19', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [feH5Xa0499vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('269', '1467683292', '2016-07-05 09:48:12', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467683292\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416629343\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467683292</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416629343</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('270', '1467683292', '2016-07-05 09:48:12', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467683292</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('271', '1467683298', '2016-07-05 09:48:18', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467683298\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416629343\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467683298</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416629343</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('272', '1467683299', '2016-07-05 09:48:19', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467683298</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('273', '1467683415', '2016-07-05 09:50:15', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467683415\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416629343\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467683415</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416629343</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('274', '1467683415', '2016-07-05 09:50:15', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467683415</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('275', '1467683560', '2016-07-05 09:52:40', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467683560\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416629343\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467683560</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416629343</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('276', '1467683561', '2016-07-05 09:52:41', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467683560</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('277', '1467683718', '2016-07-05 09:55:18', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467683718\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416629343\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467683718</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416629343</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('278', '1467683718', '2016-07-05 09:55:18', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467683718</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('279', '1467683727', '2016-07-05 09:55:27', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467683727\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416629343\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467683727</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416629343</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('280', '1467683727', '2016-07-05 09:55:27', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467683727</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('281', '1467683733', '2016-07-05 09:55:33', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467683733\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416639834\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467683733</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416639834</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('282', '1467683733', '2016-07-05 09:55:33', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467683733</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('283', '1467683851', '2016-07-05 09:57:31', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467683851\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416639834\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467683851</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416639834</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('284', '1467683851', '2016-07-05 09:57:31', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467683851</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('285', '1467683860', '2016-07-05 09:57:40', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467683860\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467683860</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('286', '1467683860', '2016-07-05 09:57:40', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分132\r\n\r\n2016-07-05 09:57:40\r\n\r\n您今天是第1位签到]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467683860</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('287', '1467683863', '2016-07-05 09:57:43', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467683863\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416639834\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467683863</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416639834</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('288', '1467683864', '2016-07-05 09:57:44', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467683863</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('289', '1467684783', '2016-07-05 10:13:03', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs7n2HMHKM-9uQTocr3Ausvo\";s:10:\"CreateTime\";s:10:\"1467684783\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs7n2HMHKM-9uQTocr3Ausvo]]></FromUserName>\n<CreateTime>1467684783</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('290', '1467684783', '2016-07-05 10:13:03', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分103\r\n\r\n2016-07-05 10:13:03\r\n\r\n您今天是第2位签到\r\n\r\n排行榜：\r\n第1名  阿追(J)  09:57:40\n第2名  主治医师  10:13:03\n]]></Content><ToUserName><![CDATA[oYMvgs7n2HMHKM-9uQTocr3Ausvo]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467684783</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('291', '1467686059', '2016-07-05 10:34:19', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467686059\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416639834\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467686059</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416639834</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('292', '1467686059', '2016-07-05 10:34:19', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467686059</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('293', '1467686186', '2016-07-05 10:36:26', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467686185\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416639834\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467686185</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416639834</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('294', '1467686186', '2016-07-05 10:36:26', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467686185</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('295', '1467686772', '2016-07-05 10:46:12', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467686771\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416639834\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467686771</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416639834</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('296', '1467686772', '2016-07-05 10:46:12', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467686772</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('297', '1467686811', '2016-07-05 10:46:51', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467686810\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467686810</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('298', '1467686811', '2016-07-05 10:46:51', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[咖啡会员卡]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/cover.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/show/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467686811</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('299', '1467688219', '2016-07-05 11:10:19', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [gaHgpa0218vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('300', '1467688273', '2016-07-05 11:11:13', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467688273\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467688273</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('301', '1467688273', '2016-07-05 11:11:13', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/cover.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Card/show/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467688273</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('302', '1467690105', '2016-07-05 11:41:45', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467690106\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467690106</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('303', '1467690105', '2016-07-05 11:41:45', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/vip_card.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467690105</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('304', '1467690262', '2016-07-05 11:44:22', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [wecvnA0263vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('305', '1467690919', '2016-07-05 11:55:19', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs7n2HMHKM-9uQTocr3Ausvo\";s:10:\"CreateTime\";s:10:\"1467690920\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs7n2HMHKM-9uQTocr3Ausvo]]></FromUserName>\n<CreateTime>1467690920</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('306', '1467690919', '2016-07-05 11:55:19', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/vip_card.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/token/gh_89d5cf544493/openid/oYMvgs7n2HMHKM-9uQTocr3Ausvo.html&openid=oYMvgs7n2HMHKM-9uQTocr3Ausvo]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs7n2HMHKM-9uQTocr3Ausvo]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467690919</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('307', '1467691058', '2016-07-05 11:57:38', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [CZ01sA0059vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('308', '1467692609', '2016-07-05 12:23:29', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [kZYZVA0610vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('309', '1467692621', '2016-07-05 12:23:41', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [_l2IQA0622vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('310', '1467692939', '2016-07-05 12:28:59', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [ckEsIA0940vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('311', '1467693299', '2016-07-05 12:34:59', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [hL5OVa0300vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('312', '1467693367', '2016-07-05 12:36:07', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:38:\"api unauthorized hint: [QSky90368vr21]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('313', '1467699638', '2016-07-05 14:20:38', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [p3v8Ea0639vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('314', '1467699850', '2016-07-05 14:24:10', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [nFNGZa0850vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('315', '1467699983', '2016-07-05 14:26:23', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [9Mxcaa0984vr21]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('316', '1467699983', '2016-07-05 14:26:23', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [vXlP.a0984vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('317', '1467699985', '2016-07-05 14:26:25', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [kKNJ5a0985vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('318', '1467699994', '2016-07-05 14:26:34', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [kdQcwA0994vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('319', '1467700011', '2016-07-05 14:26:51', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467700011\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467700011</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('320', '1467700011', '2016-07-05 14:26:51', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢咖啡]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/vip_card.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467700011</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('321', '1467700185', '2016-07-05 14:29:45', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [L7dECa0185vr21]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('322', '1467700229', '2016-07-05 14:30:29', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [deNFqa0229vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('323', '1467700461', '2016-07-05 14:34:21', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467700462\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467700462</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('324', '1467700461', '2016-07-05 14:34:21', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢咖啡]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/vip_card.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467700461</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('325', '1467700878', '2016-07-05 14:41:18', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [qAekda0878vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('326', '1467704968', '2016-07-05 15:49:28', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467704968\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467704968</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('327', '1467704968', '2016-07-05 15:49:28', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢咖啡]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/privilege.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467704968</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('328', '1467705962', '2016-07-05 16:06:02', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [4j_SLA0962vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('329', '1467706053', '2016-07-05 16:07:33', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [yIGU_a0053vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('330', '1467708001', '2016-07-05 16:40:01', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467708001\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467708001</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('331', '1467708001', '2016-07-05 16:40:01', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[亲，今天已经签到过了，请明天再来哦，谢谢！]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467708001</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('332', '1467708010', '2016-07-05 16:40:10', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467708010\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467708010</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('333', '1467708010', '2016-07-05 16:40:10', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢咖啡]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/privilege.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467708010</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('334', '1467708233', '2016-07-05 16:43:53', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467708233\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416640845\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467708233</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416640845</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('335', '1467708233', '2016-07-05 16:43:53', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467708233</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('336', '1467708242', '2016-07-05 16:44:02', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467708242\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416640845\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467708242</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416640845</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('337', '1467708242', '2016-07-05 16:44:02', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467708242</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('338', '1467708442', '2016-07-05 16:47:22', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [evNjza0442vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('339', '1467769249', '2016-07-06 09:40:49', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [IPQ0mA0249vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('340', '1467770704', '2016-07-06 10:05:04', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467770703\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官网\";s:5:\"MsgId\";s:19:\"6304027167828589754\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467770703</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6304027167828589754</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('341', '1467770704', '2016-07-06 10:05:04', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢城欢迎您]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Uploads/Picture/2016-06-27/57712693cc6b4.jpg]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467770704</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('342', '1467770722', '2016-07-06 10:05:22', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [1d3rDA0722vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('343', '1467771304', '2016-07-06 10:15:04', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467771304\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:86:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html\";s:6:\"MenuId\";s:9:\"416660855\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467771304</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html]]></EventKey>\n<MenuId>416660855</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('344', '1467771304', '2016-07-06 10:15:04', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467771304</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('345', '1467771317', '2016-07-06 10:15:17', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [kyafoa0317vr21]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('346', '1467771533', '2016-07-06 10:18:53', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467771533\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:86:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html\";s:6:\"MenuId\";s:9:\"416660855\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467771533</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html]]></EventKey>\n<MenuId>416660855</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('347', '1467771533', '2016-07-06 10:18:53', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467771533</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('348', '1467771574', '2016-07-06 10:19:34', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467771574\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:86:\"http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html\";s:6:\"MenuId\";s:9:\"416660855\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467771574</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/1.html]]></EventKey>\n<MenuId>416660855</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('349', '1467771574', '2016-07-06 10:19:34', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467771574</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('350', '1467771905', '2016-07-06 10:25:05', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467771905\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:116:\"http://mp.weixin.qq.com/mp/homepage?__biz=MzA4NTE4MjA4MQ==&hid=1&sn=c3d023d6f2189920d764eadd35446272#wechat_redirect\";s:6:\"MenuId\";s:9:\"416660900\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467771905</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://mp.weixin.qq.com/mp/homepage?__biz=MzA4NTE4MjA4MQ==&hid=1&sn=c3d023d6f2189920d764eadd35446272#wechat_redirect]]></EventKey>\n<MenuId>416660900</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('351', '1467771905', '2016-07-06 10:25:05', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467771905</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('352', '1467771914', '2016-07-06 10:25:14', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467771914\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:34:\"http://www.cgtblog.com/wx/241.html\";s:6:\"MenuId\";s:9:\"416660900\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467771914</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://www.cgtblog.com/wx/241.html]]></EventKey>\n<MenuId>416660900</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('353', '1467771914', '2016-07-06 10:25:14', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467771914</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('354', '1467772648', '2016-07-06 10:37:28', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467772648\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微官网\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467772648</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微官网]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('355', '1467772648', '2016-07-06 10:37:28', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢城欢迎您]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Uploads/Picture/2016-06-27/57712693cc6b4.jpg]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467772648</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('356', '1467772668', '2016-07-06 10:37:48', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [MfAdna0668vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('357', '1467772675', '2016-07-06 10:37:55', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467772675\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"会员卡\";s:5:\"MsgId\";s:19:\"6304035637504097965\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467772675</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[会员卡]]></Content>\n<MsgId>6304035637504097965</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('358', '1467772675', '2016-07-06 10:37:55', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢咖啡]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/privilege.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467772675</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('359', '1467772789', '2016-07-06 10:39:49', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:38:\"api unauthorized hint: [S8he80789vr21]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('360', '1467781975', '2016-07-06 13:12:55', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467781975\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微官网\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467781975</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微官网]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('361', '1467781975', '2016-07-06 13:12:55', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢城欢迎您]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Uploads/Picture/2016-06-27/57712693cc6b4.jpg]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467781975</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('362', '1467781977', '2016-07-06 13:12:57', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467781977\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:116:\"http://mp.weixin.qq.com/mp/homepage?__biz=MzA4NTE4MjA4MQ==&hid=1&sn=c3d023d6f2189920d764eadd35446272#wechat_redirect\";s:6:\"MenuId\";s:9:\"416660980\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467781977</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://mp.weixin.qq.com/mp/homepage?__biz=MzA4NTE4MjA4MQ==&hid=1&sn=c3d023d6f2189920d764eadd35446272#wechat_redirect]]></EventKey>\n<MenuId>416660980</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('363', '1467781977', '2016-07-06 13:12:57', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467781977</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('364', '1467782004', '2016-07-06 13:13:24', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467782004\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微官网\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467782004</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微官网]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('365', '1467782004', '2016-07-06 13:13:24', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢城欢迎您]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Uploads/Picture/2016-06-27/57712693cc6b4.jpg]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467782004</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('366', '1467782019', '2016-07-06 13:13:39', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467782019\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467782019</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('367', '1467782020', '2016-07-06 13:13:40', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[恭喜您,签到成功\r\n\r\n本次签到获得1积分\r\n\r\n当前总积分134\r\n\r\n2016-07-06 13:13:40\r\n\r\n您今天是第1位签到\r\n\r\n排行榜：\r\n第1名  阿追(J)  13:13:40\n]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467782019</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('368', '1467782148', '2016-07-06 13:15:48', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs7n2HMHKM-9uQTocr3Ausvo\";s:10:\"CreateTime\";s:10:\"1467782148\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"会员卡\";s:5:\"MsgId\";s:19:\"6304076323729295227\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs7n2HMHKM-9uQTocr3Ausvo]]></FromUserName>\n<CreateTime>1467782148</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[会员卡]]></Content>\n<MsgId>6304076323729295227</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('369', '1467782148', '2016-07-06 13:15:48', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢咖啡]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/privilege.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/token/gh_89d5cf544493/openid/oYMvgs7n2HMHKM-9uQTocr3Ausvo.html&openid=oYMvgs7n2HMHKM-9uQTocr3Ausvo]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs7n2HMHKM-9uQTocr3Ausvo]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467782148</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('370', '1467793735', '2016-07-06 16:28:55', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [hXEAJA0735vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('371', '1467793743', '2016-07-06 16:29:03', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [PuUaaA0743vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('372', '1467795152', '2016-07-06 16:52:32', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [8r47NA0152vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('373', '1467795327', '2016-07-06 16:55:27', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [tbZnwA0327vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('374', '1467795350', '2016-07-06 16:55:50', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [Y4fVTA0350vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('375', '1467795353', '2016-07-06 16:55:53', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [FU2jXa0353vr21]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('376', '1467796952', '2016-07-06 17:22:32', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [0WrljA0952vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('377', '1467811099', '2016-07-06 21:18:19', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467811098\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:12:\"没有良心\";s:5:\"MsgId\";s:19:\"6304200663032521152\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467811098</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[没有良心]]></Content>\n<MsgId>6304200663032521152</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('378', '1467811099', '2016-07-06 21:18:19', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[谁是没有良心的人]]></Title><Description><![CDATA[谁是没有良心的人]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Public/static/icon/colors/1187223.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Ask/Ask/show/ask_id/1/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467811099</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('379', '1467811685', '2016-07-06 21:28:05', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [Jlb2jA0685vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('380', '1467814916', '2016-07-06 22:21:56', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [3XimIa0916vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('381', '1467816091', '2016-07-06 22:41:31', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467816090\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:116:\"http://mp.weixin.qq.com/mp/homepage?__biz=MzA4NTE4MjA4MQ==&hid=1&sn=c3d023d6f2189920d764eadd35446272#wechat_redirect\";s:6:\"MenuId\";s:9:\"416660980\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467816090</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://mp.weixin.qq.com/mp/homepage?__biz=MzA4NTE4MjA4MQ==&hid=1&sn=c3d023d6f2189920d764eadd35446272#wechat_redirect]]></EventKey>\n<MenuId>416660980</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('382', '1467816091', '2016-07-06 22:41:31', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467816091</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('383', '1467816123', '2016-07-06 22:42:03', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467816123\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微官网\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467816123</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微官网]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('384', '1467816123', '2016-07-06 22:42:03', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢城欢迎您]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Uploads/Picture/2016-06-27/57712693cc6b4.jpg]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467816123</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('385', '1467816154', '2016-07-06 22:42:34', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467816154\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467816154</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('386', '1467816154', '2016-07-06 22:42:34', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[亲，今天已经签到过了，请明天再来哦，谢谢！]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467816154</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('387', '1467816685', '2016-07-06 22:51:25', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467816684\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467816684</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('388', '1467816685', '2016-07-06 22:51:25', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢咖啡]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/privilege.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467816685</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('389', '1467816809', '2016-07-06 22:53:29', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467816809\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467816809</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('390', '1467816810', '2016-07-06 22:53:30', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[慢城会员中心]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/privilege.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467816809</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('391', '1467816879', '2016-07-06 22:54:39', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467816879\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467816879</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('392', '1467816879', '2016-07-06 22:54:39', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[亲，今天已经签到过了，请明天再来哦，谢谢！]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467816879</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('393', '1467822609', '2016-07-07 00:30:09', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467822609\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467822609</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('394', '1467822609', '2016-07-07 00:30:09', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[慢城会员中心]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/privilege.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467822609</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('395', '1467855094', '2016-07-07 09:31:34', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467855094\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467855094</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('396', '1467855095', '2016-07-07 09:31:35', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[慢城会员中心]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/privilege.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467855094</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('397', '1467856176', '2016-07-07 09:49:36', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [.2_gEa0176vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('398', '1467856196', '2016-07-07 09:49:56', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:79:\"invalid credential, access_token is invalid or not latest hint: [uaCy80196vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('399', '1467856210', '2016-07-07 09:50:10', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [2NMRka0210vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('400', '1467856495', '2016-07-07 09:54:55', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:36:\"api unauthorized hint: [F1e0495vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('401', '1467856641', '2016-07-07 09:57:21', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [vtY4xa0641vr21]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('402', '1467857045', '2016-07-07 10:04:05', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [dLyPPa0044vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('403', '1467857205', '2016-07-07 10:06:45', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467857205\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:116:\"http://mp.weixin.qq.com/mp/homepage?__biz=MzA4NTE4MjA4MQ==&hid=1&sn=c3d023d6f2189920d764eadd35446272#wechat_redirect\";s:6:\"MenuId\";s:9:\"416671476\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467857205</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://mp.weixin.qq.com/mp/homepage?__biz=MzA4NTE4MjA4MQ==&hid=1&sn=c3d023d6f2189920d764eadd35446272#wechat_redirect]]></EventKey>\n<MenuId>416671476</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('404', '1467857206', '2016-07-07 10:06:46', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467857205</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('405', '1467857221', '2016-07-07 10:07:01', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467857221\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微官网\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467857221</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微官网]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('406', '1467857221', '2016-07-07 10:07:01', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢城欢迎您]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Uploads/Picture/2016-06-27/57712693cc6b4.jpg]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467857221</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('407', '1467857233', '2016-07-07 10:07:13', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467857233\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467857233</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('408', '1467857233', '2016-07-07 10:07:13', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[慢城会员中心]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/privilege.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467857233</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('409', '1467857478', '2016-07-07 10:11:18', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:79:\"invalid credential, access_token is invalid or not latest hint: [htq830478vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('410', '1467857544', '2016-07-07 10:12:24', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgsyEDncCLibJPRbvIwNPGsNA\";s:10:\"CreateTime\";s:10:\"1467857544\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgsyEDncCLibJPRbvIwNPGsNA]]></FromUserName>\n<CreateTime>1467857544</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('411', '1467857544', '2016-07-07 10:12:24', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[慢城会员中心]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/privilege.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/token/gh_89d5cf544493/openid/oYMvgsyEDncCLibJPRbvIwNPGsNA.html&openid=oYMvgsyEDncCLibJPRbvIwNPGsNA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgsyEDncCLibJPRbvIwNPGsNA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467857544</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('412', '1467857732', '2016-07-07 10:15:32', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:79:\"invalid credential, access_token is invalid or not latest hint: [u.RP70732vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('413', '1467858119', '2016-07-07 10:21:59', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:34:\"api unauthorized hint: [h0119vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('414', '1467858289', '2016-07-07 10:24:49', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [igWlta0289vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('415', '1467858418', '2016-07-07 10:26:58', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [Ke2ncA0418vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('416', '1467879810', '2016-07-07 16:23:30', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467879810\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微官网\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467879810</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微官网]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('417', '1467879810', '2016-07-07 16:23:30', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢城欢迎您]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Uploads/Picture/2016-06-27/57712693cc6b4.jpg]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467879810</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('418', '1467879840', '2016-07-07 16:24:00', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467879840\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:6:\"签到\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467879840</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[签到]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('419', '1467879840', '2016-07-07 16:24:00', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[亲，今天已经签到过了，请明天再来哦，谢谢！]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467879840</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('420', '1467879844', '2016-07-07 16:24:04', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467879844\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467879844</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('421', '1467879845', '2016-07-07 16:24:05', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[慢城会员中心]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/privilege.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467879844</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('422', '1467897402', '2016-07-07 21:16:42', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:79:\"invalid credential, access_token is invalid or not latest hint: [zJIn30402vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('423', '1467897461', '2016-07-07 21:17:41', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [k6FQza0461vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('424', '1467897477', '2016-07-07 21:17:57', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [frXJPA0477vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('425', '1467897820', '2016-07-07 21:23:40', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:79:\"invalid credential, access_token is invalid or not latest hint: [HCve_0820vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('426', '1467897939', '2016-07-07 21:25:39', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [MV7wva0939vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('427', '1467897947', '2016-07-07 21:25:47', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [DXsuoA0947vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('428', '1467898349', '2016-07-07 21:32:29', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467898348\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:116:\"http://mp.weixin.qq.com/mp/homepage?__biz=MzA4NTE4MjA4MQ==&hid=1&sn=c3d023d6f2189920d764eadd35446272#wechat_redirect\";s:6:\"MenuId\";s:9:\"416671476\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467898348</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://mp.weixin.qq.com/mp/homepage?__biz=MzA4NTE4MjA4MQ==&hid=1&sn=c3d023d6f2189920d764eadd35446272#wechat_redirect]]></EventKey>\n<MenuId>416671476</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('429', '1467898349', '2016-07-07 21:32:29', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467898348</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('430', '1467898355', '2016-07-07 21:32:35', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467898355\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微官网\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467898355</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微官网]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('431', '1467898355', '2016-07-07 21:32:35', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢城欢迎您]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Uploads/Picture/2016-06-27/57712693cc6b4.jpg]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467898355</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('432', '1467904944', '2016-07-07 23:22:24', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [FEf7ia0944vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('433', '1467904947', '2016-07-07 23:22:27', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [QiGbna0947vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('434', '1467915580', '2016-07-08 02:19:40', 'a:7:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467915580\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:116:\"http://mp.weixin.qq.com/mp/homepage?__biz=MzA4NTE4MjA4MQ==&hid=1&sn=c3d023d6f2189920d764eadd35446272#wechat_redirect\";s:6:\"MenuId\";s:9:\"416671476\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467915580</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[http://mp.weixin.qq.com/mp/homepage?__biz=MzA4NTE4MjA4MQ==&hid=1&sn=c3d023d6f2189920d764eadd35446272#wechat_redirect]]></EventKey>\n<MenuId>416671476</MenuId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('435', '1467915581', '2016-07-08 02:19:41', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[收到您的留言, 我们会尽快回复您!]]></Content><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467915580</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('436', '1467915599', '2016-07-08 02:19:59', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467915599\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微官网\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467915599</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微官网]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('437', '1467915599', '2016-07-08 02:19:59', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[悦慢城欢迎您]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Uploads/Picture/2016-06-27/57712693cc6b4.jpg]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467915599</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('438', '1467915625', '2016-07-08 02:20:25', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_89d5cf544493\";s:12:\"FromUserName\";s:28:\"oYMvgs0F5Z8twiMk0-_2k7NqlLaA\";s:10:\"CreateTime\";s:10:\"1467915625\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"会员卡\";}', '<xml><ToUserName><![CDATA[gh_89d5cf544493]]></ToUserName>\n<FromUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></FromUserName>\n<CreateTime>1467915625</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员卡]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('439', '1467915625', '2016-07-08 02:20:25', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[慢城会员中心]]></Title><Description><![CDATA[上海市浦东新区张杨路400号]]></Description><PicUrl><![CDATA[http://jasongan.cn/php/weiphp3/Addons/Card/View/default/Public/privilege.png]]></PicUrl><Url><![CDATA[http://jasongan.cn/php/weiphp3/index.php?s=/addon/Card/Wap/index/token/gh_89d5cf544493/openid/oYMvgs0F5Z8twiMk0-_2k7NqlLaA.html&openid=oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></Url></item></Articles><ToUserName><![CDATA[oYMvgs0F5Z8twiMk0-_2k7NqlLaA]]></ToUserName><FromUserName><![CDATA[gh_89d5cf544493]]></FromUserName><CreateTime>1467915625</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('440', '1467943421', '2016-07-08 10:03:41', 'a:2:{s:7:\"errcode\";i:40001;s:6:\"errmsg\";s:80:\"invalid credential, access_token is invalid or not latest hint: [Ex4URA0421vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('441', '1467943482', '2016-07-08 10:04:42', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [cCQiJa0482vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('442', '1467943482', '2016-07-08 10:04:42', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [6JwtlA0482vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('443', '1467943487', '2016-07-08 10:04:47', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [x6Ehoa0487vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('444', '1467943488', '2016-07-08 10:04:48', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [FqcvsA0488vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('445', '1467945402', '2016-07-08 10:36:42', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [kP7QuA0402vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('446', '1467945893', '2016-07-08 10:44:53', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [SRkvTA0893vr18]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('447', '1467946193', '2016-07-08 10:49:53', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [15ytxa0193vr20]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('448', '1467946483', '2016-07-08 10:54:43', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [H2nQbA0483vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('449', '1467947595', '2016-07-08 11:13:15', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [fw7bgA0595vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('450', '1467947755', '2016-07-08 11:15:55', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [Cw0XVa0755vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('451', '1467947764', '2016-07-08 11:16:04', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [X81tCa0764vr19]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('452', '1467947770', '2016-07-08 11:16:10', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:37:\"api unauthorized hint: [ky0x0770vr23]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('453', '1467947777', '2016-07-08 11:16:17', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [Tu0c8a0777vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('454', '1467947786', '2016-07-08 11:16:26', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [vAlQMa0786vr22]\";}', 'qrcode_error');
INSERT INTO `wp_weixin_log` VALUES ('455', '1467947787', '2016-07-08 11:16:27', 'a:2:{s:7:\"errcode\";i:48001;s:6:\"errmsg\";s:39:\"api unauthorized hint: [.4dbDA0787vr20]\";}', 'qrcode_error');

-- -----------------------------
-- Table structure for `wp_weixin_message`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weixin_message`;
;

-- -----------------------------
-- Records of `wp_weixin_message`
-- -----------------------------
INSERT INTO `wp_weixin_message` VALUES ('1', 'gh_89d5cf544493', 'oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467020479', 'text', '6300804980283783946', '竞猜', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('2', 'gh_89d5cf544493', 'oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467020496', 'text', '6300805053298227979', '微官网', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('3', 'gh_89d5cf544493', 'oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467020664', 'text', '6300805774852733747', '欧洲杯竞猜', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('4', 'gh_89d5cf544493', 'oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467021091', 'text', '6300807608803769269', '竞猜', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('5', 'gh_89d5cf544493', 'oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467034864', 'text', '6300866763388339772', '吉他之神', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('6', 'gh_89d5cf544493', 'oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467036775', 'text', '6300874971070842968', '微官网', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('7', 'gh_89d5cf544493', 'oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467044828', 'text', '6300909558442479144', '欧洲杯竞猜', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('8', 'gh_89d5cf544493', 'oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467045167', 'text', '6300911014436392595', '微官网', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('9', 'gh_89d5cf544493', 'oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467632949', '', '', '收到您的留言, 我们会尽快回复您!', '', '', '', '', '', '', '', '0', '0', '1', '1', '0');
INSERT INTO `wp_weixin_message` VALUES ('10', 'gh_89d5cf544493', 'oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467633681', 'text', '6303438662819726011', '微网站', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('11', 'gh_89d5cf544493', 'oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467633686', 'text', '6303438684294562495', '微官网', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('12', 'gh_89d5cf544493', 'oYMvgs7n2HMHKM-9uQTocr3Ausvo', '1467633833', 'text', '6303439315654755055', '微官网', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('13', 'gh_89d5cf544493', 'oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467638430', 'text', '6303459059619416339', '会员卡', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('14', 'gh_89d5cf544493', 'oYMvgsyEDncCLibJPRbvIwNPGsNA', '1467639995', 'text', '6303465781243235244', '微官网', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('15', 'gh_89d5cf544493', 'oYMvgsyEDncCLibJPRbvIwNPGsNA', '1467640147', 'text', '6303466434078264304', '吉他之神', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('16', 'gh_89d5cf544493', 'oYMvgsyEDncCLibJPRbvIwNPGsNA', '1467640253', 'text', '6303466889344797722', '哈哈哈', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('17', 'gh_89d5cf544493', 'oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467641581', 'text', '6303472593061367329', '会员卡', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('18', 'gh_89d5cf544493', 'oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467770703', 'text', '6304027167828589754', '微官网', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('19', 'gh_89d5cf544493', 'oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467772675', 'text', '6304035637504097965', '会员卡', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('20', 'gh_89d5cf544493', 'oYMvgs7n2HMHKM-9uQTocr3Ausvo', '1467782148', 'text', '6304076323729295227', '会员卡', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');
INSERT INTO `wp_weixin_message` VALUES ('21', 'gh_89d5cf544493', 'oYMvgs0F5Z8twiMk0-_2k7NqlLaA', '1467811098', 'text', '6304200663032521152', '没有良心', '', '', '', '', '', '', '', '0', '0', '0', '0', '0');

-- -----------------------------
-- Table structure for `wp_wish_card`
-- -----------------------------
DROP TABLE IF EXISTS `wp_wish_card`;
;

-- -----------------------------
-- Records of `wp_wish_card`
-- -----------------------------
INSERT INTO `wp_wish_card` VALUES ('1', '阿追', '何桑', '你好', '1467035345', 'm1', 'birthday', '2', '1', 'gh_89d5cf544493');

-- -----------------------------
-- Table structure for `wp_wish_card_content`
-- -----------------------------
DROP TABLE IF EXISTS `wp_wish_card_content`;
;


-- -----------------------------
-- Table structure for `wp_wish_card_content_cate`
-- -----------------------------
DROP TABLE IF EXISTS `wp_wish_card_content_cate`;
;


-- -----------------------------
-- Table structure for `wp_xdlog`
-- -----------------------------
DROP TABLE IF EXISTS `wp_xdlog`;
;

